import React from 'react';

interface StatusBadgeProps {
  status: string;
  size?: 'sm' | 'md';
}

export function StatusBadge({ status, size = 'md' }: StatusBadgeProps) {
  const norm = (status || '').toUpperCase();

  let bg = 'bg-slate-800 text-slate-300 border-slate-700';
  let dot = 'bg-slate-400';

  if (norm === 'AVAILABLE' || norm === 'ONLINE' || norm === 'COMPLETED' || norm === 'RESOLVED') {
    bg = 'bg-emerald-950/70 text-emerald-300 border-emerald-800/80';
    dot = 'bg-emerald-400';
  } else if (norm === 'CHARGING' || norm === 'BUSY' || norm === 'ON_TRIP' || norm === 'ACTIVE') {
    bg = 'bg-cyan-950/70 text-cyan-300 border-cyan-800/80';
    dot = 'bg-cyan-400 animate-pulse';
  } else if (norm === 'RESERVED' || norm === 'IDLE' || norm === 'PENDING' || norm === 'WARNING') {
    bg = 'bg-amber-950/70 text-amber-300 border-amber-800/80';
    dot = 'bg-amber-400';
  } else if (norm === 'FAULTED' || norm === 'CRITICAL' || norm === 'CANCELLED') {
    bg = 'bg-rose-950/70 text-rose-300 border-rose-800/80';
    dot = 'bg-rose-400';
  } else if (norm === 'OFFLINE' || norm === 'MAINTENANCE') {
    bg = 'bg-slate-900 text-slate-400 border-slate-800';
    dot = 'bg-slate-500';
  }

  const padding = size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-xs font-medium';

  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border ${padding} ${bg}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${dot}`} />
      <span>{norm.replace(/_/g, ' ')}</span>
    </span>
  );
}
