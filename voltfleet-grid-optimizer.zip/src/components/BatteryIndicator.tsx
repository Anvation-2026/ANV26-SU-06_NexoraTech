import React from 'react';
import { BatteryCharging } from 'lucide-react';

interface BatteryIndicatorProps {
  soc: number;
  isCharging?: boolean;
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
}

export function BatteryIndicator({ soc, isCharging = false, size = 'md', showLabel = true }: BatteryIndicatorProps) {
  const clamped = Math.max(0, Math.min(100, Math.round(soc)));

  let colorClass = 'bg-emerald-500 text-emerald-400';
  let borderClass = 'border-emerald-500/30';
  if (clamped < 20) {
    colorClass = 'bg-rose-500 text-rose-400';
    borderClass = 'border-rose-500/30';
  } else if (clamped < 50) {
    colorClass = 'bg-amber-500 text-amber-400';
    borderClass = 'border-amber-500/30';
  }

  const heightClass = size === 'sm' ? 'h-2 w-12' : size === 'lg' ? 'h-3.5 w-24' : 'h-2.5 w-16';

  return (
    <div className="flex items-center gap-2">
      <div className={`relative flex items-center rounded-sm bg-slate-800 p-0.5 border ${borderClass} ${heightClass}`}>
        <div
          className={`h-full rounded-xs transition-all duration-500 ${colorClass.split(' ')[0]}`}
          style={{ width: `${clamped}%` }}
        />
        <div className="absolute -right-1 top-1/2 -translate-y-1/2 h-1.5 w-0.5 rounded-r-xs bg-slate-500" />
      </div>

      {showLabel && (
        <span className={`font-mono font-medium ${size === 'sm' ? 'text-xs' : 'text-sm'} text-slate-200`}>
          {clamped}%
        </span>
      )}

      {isCharging && (
        <span className="text-cyan-400 animate-pulse">
          <BatteryCharging className={size === 'sm' ? 'h-3.5 w-3.5' : 'h-4 w-4'} />
        </span>
      )}
    </div>
  );
}
