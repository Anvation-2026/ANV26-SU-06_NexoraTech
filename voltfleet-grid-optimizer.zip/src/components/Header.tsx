import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Bell,
  Settings as SettingsIcon,
  LogOut,
  Radio,
  Zap,
  User as UserIcon,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';
import { User } from '../types';
import { LiveConnectionStatus } from '../hooks/useLiveTelemetry';

interface HeaderProps {
  user: User | null;
  wsStatus: LiveConnectionStatus;
  liveGridData?: any;
  onLogout: () => void;
}

export function Header({ user, wsStatus, liveGridData, onLogout }: HeaderProps) {
  const navigate = useNavigate();
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  return (
    <header className="relative flex h-16 items-center justify-between border-b border-slate-800/80 bg-slate-950/80 px-6 backdrop-blur-md z-20">
      {/* Left side: System status & Telemetry mode */}
      <div className="flex items-center gap-4">
        {/* Live Grid Quick Ticker */}
        {liveGridData && (
          <div className="flex items-center gap-2 rounded-lg bg-slate-900 border border-slate-800 px-3 py-1 text-xs">
            <Zap className="h-3.5 w-3.5 text-amber-400" />
            <span className="text-slate-400">Grid Load:</span>
            <span className="font-mono font-bold text-slate-200">
              {liveGridData.current_grid_load_kw || 2450} kW
            </span>
            <span className="text-slate-500">/ 5,000 kW</span>
          </div>
        )}
      </div>

      {/* Right side controls */}
      <div className="flex items-center gap-3">
        {/* Settings button */}
        <button
          onClick={() => navigate('/settings')}
          className="rounded-lg p-2 text-slate-400 hover:bg-slate-900 hover:text-slate-200 border border-transparent hover:border-slate-800 transition-colors cursor-pointer"
          title="System Settings"
        >
          <SettingsIcon className="h-5 w-5" />
        </button>

        {/* Notifications */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="relative rounded-lg p-2 text-slate-400 hover:bg-slate-900 hover:text-slate-200 border border-transparent hover:border-slate-800 transition-colors cursor-pointer"
          >
            <Bell className="h-5 w-5" />
            <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-amber-500" />
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 rounded-xl border border-slate-800 bg-slate-900 p-4 shadow-2xl z-50">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-xs font-semibold text-slate-200">System Notifications</span>
                <span className="text-[10px] text-cyan-400">3 Unread</span>
              </div>
              <div className="mt-3 space-y-2.5 text-xs">
                <div className="flex items-start gap-2 rounded-lg bg-slate-800/60 p-2.5 border border-slate-800">
                  <AlertTriangle className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-slate-200">Substation Grid Utilization</p>
                    <p className="text-[11px] text-slate-400">Current load reached 78% capacity.</p>
                  </div>
                </div>
                <div className="flex items-start gap-2 rounded-lg bg-slate-800/60 p-2.5 border border-slate-800">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-slate-200">Supabase Realtime Sync</p>
                    <p className="text-[11px] text-slate-400">50 fleet assets streaming live updates.</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* User Menu */}
        <div className="relative">
          <button
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="flex items-center gap-2.5 rounded-lg border border-slate-800 bg-slate-900/80 px-3 py-1.5 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <div className="flex h-7 w-7 items-center justify-center rounded-full bg-cyan-600/30 text-cyan-400 border border-cyan-500/40 font-bold text-xs">
              {user?.full_name?.charAt(0) || 'U'}
            </div>
            <div className="hidden sm:flex flex-col text-left">
              <span className="text-xs font-semibold text-slate-200">{user?.full_name || 'Operator'}</span>
              <span className="text-[10px] text-slate-400">{user?.role || 'FLEET_MANAGER'}</span>
            </div>
          </button>

          {showUserMenu && (
            <div className="absolute right-0 mt-2 w-56 rounded-xl border border-slate-800 bg-slate-900 p-2 shadow-2xl z-50">
              <div className="px-3 py-2 border-b border-slate-800 text-xs">
                <p className="font-semibold text-slate-200">{user?.full_name}</p>
                <p className="text-[11px] text-slate-400 truncate">{user?.email}</p>
                <p className="mt-1 text-[10px] font-mono font-medium text-cyan-400">{user?.role}</p>
              </div>
              <div className="pt-1">
                <button
                  onClick={() => {
                    setShowUserMenu(false);
                    navigate('/settings');
                  }}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs text-slate-300 hover:bg-slate-800 hover:text-white cursor-pointer"
                >
                  <UserIcon className="h-3.5 w-3.5" />
                  Profile & Preferences
                </button>
                <button
                  onClick={() => {
                    setShowUserMenu(false);
                    onLogout();
                  }}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs text-rose-400 hover:bg-rose-950/40 hover:text-rose-300 cursor-pointer"
                >
                  <LogOut className="h-3.5 w-3.5" />
                  Sign Out
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
