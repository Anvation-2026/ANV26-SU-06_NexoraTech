import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  Truck,
  Activity,
  Zap,
  Gauge,
  Cpu,
  MapPin,
  MessageSquare,
  FileText,
  Settings,
  Shield,
  ChevronLeft,
  ChevronRight,
  BatteryCharging
} from 'lucide-react';
import { UserRole } from '../types';

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
  userRole?: UserRole;
}

export function Sidebar({ collapsed, onToggle, userRole }: SidebarProps) {
  const navItems = [
    { to: '/', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/fleet', label: 'Fleet Management', icon: Truck },
    { to: '/digital-twin', label: 'Live Digital Twin', icon: Activity, badge: 'REALTIME' },
    { to: '/ports', label: 'Charging Ports', icon: Zap },
    { to: '/grid', label: 'Grid Monitor', icon: Gauge },
    { to: '/optimization', label: 'SciPy Optimization', icon: Cpu, badge: 'SciPy' },
    { to: '/stations', label: 'Nearby Stations', icon: MapPin },
    { to: '/feedback', label: 'Customer Feedback', icon: MessageSquare },
    { to: '/reports', label: 'PDF Reports', icon: FileText },
    { to: '/settings', label: 'Settings', icon: Settings },
  ];

  return (
    <aside
      className={`relative flex flex-col border-r border-slate-800 bg-slate-950 transition-all duration-300 z-30 ${
        collapsed ? 'w-20' : 'w-64'
      }`}
    >
      {/* Brand Header */}
      <div className="flex h-16 items-center justify-between px-4 border-b border-slate-800/80">
        <div className="flex items-center gap-3 overflow-hidden">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-500 text-white shadow-lg shadow-cyan-500/20">
            <BatteryCharging className="h-6 w-6" />
          </div>
          {!collapsed && (
            <div className="flex flex-col truncate">
              <span className="font-bold tracking-tight text-white text-sm">GRIDVOLT</span>
              <span className="text-[10px] uppercase tracking-wider text-cyan-400 font-medium">Supabase Powered</span>
            </div>
          )}
        </div>
        <button
          onClick={onToggle}
          className="hidden lg:flex h-7 w-7 items-center justify-center rounded-lg border border-slate-800 bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </button>
      </div>

      {/* Navigation links */}
      <div className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all duration-150 ${
                  isActive
                    ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 shadow-inner'
                    : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
                }`
              }
            >
              <Icon className="h-5 w-5 shrink-0 transition-transform group-hover:scale-105" />
              {!collapsed && (
                <div className="flex flex-1 items-center justify-between truncate">
                  <span className="truncate">{item.label}</span>
                  {item.badge && (
                    <span className="ml-2 rounded-md bg-cyan-950 border border-cyan-800/60 px-1.5 py-0.5 text-[10px] font-semibold tracking-wider text-cyan-300">
                      {item.badge}
                    </span>
                  )}
                </div>
              )}
            </NavLink>
          );
        })}
      </div>

      {/* Role Footer */}
      {!collapsed && (
        <div className="p-4 border-t border-slate-800/80 bg-slate-900/40">
          <div className="flex items-center gap-2">
            <Shield className="h-4 w-4 text-cyan-400" />
            <div className="flex flex-col">
              <span className="text-xs text-slate-400">Current Role:</span>
              <span className="text-xs font-semibold text-slate-200 tracking-wide">
                {userRole || 'FLEET_MANAGER'}
              </span>
            </div>
          </div>
        </div>
      )}
    </aside>
  );
}
