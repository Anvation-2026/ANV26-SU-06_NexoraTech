import { useEffect, useState, useRef, useCallback } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { supabase } from '../services/supabase';

export type LiveConnectionStatus = 'LIVE' | 'RECONNECTING' | 'OFFLINE';

export interface TelemetryEvent {
  event: string;
  data: any;
}

export function useLiveTelemetry() {
  const queryClient = useQueryClient();
  const [status, setStatus] = useState<LiveConnectionStatus>('LIVE');
  const [lastEvent, setLastEvent] = useState<TelemetryEvent | null>(null);
  const [liveGridData, setLiveGridData] = useState<any | null>(null);
  const [liveChargers, setLiveChargers] = useState<Record<string, any>>({});
  const channelRef = useRef<any>(null);

  useEffect(() => {
    // Set up Supabase Realtime channel
    const channel = supabase
      .channel('fleet-telemetry-live')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'vehicles' },
        (payload) => {
          setLastEvent({ event: 'vehicle.updated', data: payload.new });
          queryClient.invalidateQueries({ queryKey: ['vehicles'] });
          queryClient.invalidateQueries({ queryKey: ['dashboardStats'] });
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'charging_ports' },
        (payload) => {
          const port = payload.new as any;
          if (port && port.id) {
            setLiveChargers((prev) => ({
              ...prev,
              [port.id]: port,
            }));
          }
          setLastEvent({ event: 'charger.updated', data: payload.new });
          queryClient.invalidateQueries({ queryKey: ['chargingPorts'] });
          queryClient.invalidateQueries({ queryKey: ['portsSummary'] });
          queryClient.invalidateQueries({ queryKey: ['stations'] });
        }
      )
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'grid_telemetry' },
        (payload) => {
          setLiveGridData(payload.new);
          setLastEvent({ event: 'grid.updated', data: payload.new });
          queryClient.invalidateQueries({ queryKey: ['gridCurrent'] });
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'grid_alerts' },
        (payload) => {
          setLastEvent({ event: 'grid.alert', data: payload.new });
          queryClient.invalidateQueries({ queryKey: ['gridAlerts'] });
          queryClient.invalidateQueries({ queryKey: ['dashboardStats'] });
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'charging_sessions' },
        (payload) => {
          setLastEvent({ event: 'charging_session.updated', data: payload.new });
          queryClient.invalidateQueries({ queryKey: ['chargingSessions'] });
          queryClient.invalidateQueries({ queryKey: ['dashboardStats'] });
        }
      )
      .subscribe((subscribeStatus) => {
        if (subscribeStatus === 'SUBSCRIBED') {
          setStatus('LIVE');
        } else if (subscribeStatus === 'CLOSED' || subscribeStatus === 'CHANNEL_ERROR') {
          setStatus('RECONNECTING');
        } else {
          setStatus('LIVE');
        }
      });

    channelRef.current = channel;

    // Simulation ticker: periodically cycle slight power oscillations for realism
    const simInterval = setInterval(() => {
      const now = new Date();
      const baseLoad = 1770.0 + Math.sin(now.getTime() / 60000) * 40.0;
      const chargingLoad = 680.0 + Math.cos(now.getTime() / 45000) * 30.0;
      const totalLoad = Math.round((baseLoad + chargingLoad) * 10) / 10;
      const voltage = Math.round((400.0 + (Math.random() - 0.5) * 1.8) * 10) / 10;
      const freq = Math.round((50.0 + (Math.random() - 0.5) * 0.04) * 100) / 100;
      const pf = 0.98;

      setLiveGridData((prev: any) => ({
        ...prev,
        total_capacity_kw: 5000.0,
        current_grid_load_kw: totalLoad,
        charging_load_kw: Math.round(chargingLoad * 10) / 10,
        base_load_kw: Math.round(baseLoad * 10) / 10,
        renewable_energy_kw: 950.0,
        peak_demand_kw: 3200.0,
        voltage_v: voltage,
        frequency_hz: freq,
        power_factor: pf,
        capacity_utilization_pct: Math.round((totalLoad / 5000.0) * 1000) / 10,
        is_simulated: 'SIMULATED',
        updated_at: now.toISOString(),
      }));
    }, 4000);

    return () => {
      clearInterval(simInterval);
      if (channelRef.current) {
        supabase.removeChannel(channelRef.current);
      }
    };
  }, [queryClient]);

  return {
    status,
    lastEvent,
    liveGridData,
    liveChargers,
  };
}
