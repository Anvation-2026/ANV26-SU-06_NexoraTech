import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { DashboardLayout } from './layouts/DashboardLayout';
import { LoginPage } from './pages/LoginPage';
import { DashboardPage } from './pages/DashboardPage';
import { FleetPage } from './pages/FleetPage';
import { DigitalTwinPage } from './pages/DigitalTwinPage';
import { PortsPage } from './pages/PortsPage';
import { GridPage } from './pages/GridPage';
import { OptimizationPage } from './pages/OptimizationPage';
import { StationsPage } from './pages/StationsPage';
import { FeedbackPage } from './pages/FeedbackPage';
import { ReportsPage } from './pages/ReportsPage';
import { SettingsPage } from './pages/SettingsPage';
import { User } from './types';
import { api } from './services/api';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5000,
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

export default function App() {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return null;
      }
    }
    // Default logged in operator for fast testing & seamless operations
    return {
      id: 'usr-default',
      email: 'manager@evfleet.io',
      full_name: 'Sarah Jenkins (Fleet Director)',
      role: 'FLEET_MANAGER',
      is_active: true,
      created_at: new Date().toISOString(),
    };
  });

  const handleLoginSuccess = (newUser: User, token: string) => {
    setUser(newUser);
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(newUser));
  };

  const handleLogout = async () => {
    await api.logout();
    setUser(null);
  };

  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <Routes>
          <Route
            path="/login"
            element={
              user ? <Navigate to="/" replace /> : <LoginPage onLoginSuccess={handleLoginSuccess} />
            }
          />

          {/* Protected Application Routes */}
          <Route
            path="/"
            element={
              user ? (
                <DashboardLayout user={user} onLogout={handleLogout} />
              ) : (
                <Navigate to="/login" replace />
              )
            }
          >
            <Route index element={<DashboardPage />} />
            <Route path="fleet" element={<FleetPage />} />
            <Route path="digital-twin" element={<DigitalTwinPage />} />
            <Route path="ports" element={<PortsPage />} />
            <Route path="grid" element={<GridPage />} />
            <Route path="optimization" element={<OptimizationPage />} />
            <Route path="stations" element={<StationsPage />} />
            <Route path="feedback" element={<FeedbackPage />} />
            <Route path="reports" element={<ReportsPage />} />
            <Route path="settings" element={<SettingsPage />} />
          </Route>

          {/* Fallback */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </QueryClientProvider>
  );
}
