export type UserRole = 'ADMIN' | 'FLEET_MANAGER' | 'STATION_OPERATOR' | 'VIEWER';

export interface User {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  phone?: string;
  is_active: boolean;
  created_at: string;
}

export type VehicleStatus = 'AVAILABLE' | 'ON_TRIP' | 'CHARGING' | 'IDLE' | 'MAINTENANCE' | 'OFFLINE';
export type ChargingStatus = 'DISCONNECTED' | 'CONNECTED' | 'CHARGING' | 'COMPLETE';

export interface Vehicle {
  id: string;
  vin: string;
  registration_number: string;
  make: string;
  model: string;
  year: number;
  battery_capacity: number;
  current_soc: number;
  target_soc: number;
  status: VehicleStatus;
  charging_status: ChargingStatus;
  current_location: string;
  latitude: number;
  longitude: number;
  odometer_km: number;
  max_charge_rate_kw: number;
  driver_id?: string;
  station_id?: string;
  driver?: {
    id: string;
    name: string;
    license_number: string;
    phone?: string;
    status: string;
  };
  created_at: string;
  updated_at?: string;
}

export interface ChargingPort {
  id: string;
  station_id: string;
  station_name?: string;
  station_address?: string;
  port_number: string;
  connector_type: string;
  max_power_kw: number;
  current_power_kw: number;
  status: 'AVAILABLE' | 'BUSY' | 'RESERVED' | 'FAULTED' | 'OFFLINE';
  connected_vehicle_id?: string;
  connected_vehicle_reg?: string;
  connected_vehicle_model?: string;
  connected_vehicle_soc?: number;
  vehicle_soc?: number;
  session_duration_min?: number;
  energy_delivered_kwh?: number;
  created_at: string;
}

export interface ChargingStation {
  id: string;
  name: string;
  code: string;
  address: string;
  latitude: number;
  longitude: number;
  total_ports: number;
  available_ports: number;
  busy_ports: number;
  max_station_power_kw: number;
  grid_capacity_kw: number;
  current_load_kw: number;
  status: string;
  price_per_kwh: number;
  connector_types: string;
  ports?: ChargingPort[];
  created_at: string;
}

export interface ChargingSession {
  id: string;
  port_id: string;
  port_number?: string;
  station_name?: string;
  vehicle_id: string;
  vehicle_reg: string;
  vehicle_model?: string;
  start_time: string;
  end_time?: string;
  start_soc: number;
  end_soc?: number;
  energy_delivered_kwh: number;
  peak_power_kw: number;
  cost: number;
  status: string;
}

export interface GridCurrent {
  total_capacity_kw: number;
  current_grid_load_kw: number;
  charging_load_kw: number;
  base_load_kw: number;
  renewable_energy_kw: number;
  peak_demand_kw: number;
  voltage_v: number;
  frequency_hz: number;
  power_factor: number;
  capacity_utilization_pct: number;
  is_simulated: string;
  updated_at: string;
}

export interface GridAlert {
  id: string;
  station_id?: string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  alert_type: string;
  title: string;
  message: string;
  status: string;
  created_at: string;
}

export interface ScheduleInterval {
  slot_index: number;
  timestamp: string;
  hour_label: string;
  optimized_power_kw: number;
  baseline_power_kw: number;
  electricity_price: number;
  base_grid_load_kw: number;
  total_grid_load_kw: number;
}

export interface OptimizationResult {
  vehicle_id: string;
  charging_start: string;
  charging_end: string;
  energy_required: number;
  estimated_cost: number;
  baseline_cost?: number;
  baseline_peak_load: number;
  optimized_peak_load: number;
  estimated_savings: number;
  schedule_intervals: ScheduleInterval[];
}

export interface Booking {
  id: string;
  station_id: string;
  station_name: string;
  station_address?: string;
  port_id: string;
  port_number: string;
  booking_code: string;
  booking_date: string;
  start_time: string;
  duration_minutes: number;
  status: string;
  estimated_cost: number;
  notes?: string;
  created_at: string;
}

export interface CustomerFeedback {
  id: string;
  station_id: string;
  station_name: string;
  customer_name: string;
  rating: number;
  category: string;
  comment: string;
  status: string;
  created_at: string;
}

export interface ReportItem {
  id: string;
  title: string;
  report_type: string;
  start_date: string;
  end_date: string;
  station_id?: string;
  vehicle_id?: string;
  file_path?: string;
  storage_url?: string;
  status: string;
  summary_kpis?: Record<string, any>;
  created_at: string;
}
