import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import { Sidebar } from '../components/Sidebar';
import { Header } from '../components/Header';
import { useLiveTelemetry } from '../hooks/useLiveTelemetry';
import { User } from '../types';

interface DashboardLayoutProps {
  user: User | null;
  onLogout: () => void;
}

export function DashboardLayout({ user, onLogout }: DashboardLayoutProps) {
  const [collapsed, setCollapsed] = useState(false);
  const { status: wsStatus, liveGridData } = useLiveTelemetry();

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-950 text-slate-100 font-sans antialiased">
      {/* Sidebar */}
      <Sidebar
        collapsed={collapsed}
        onToggle={() => setCollapsed(!collapsed)}
        userRole={user?.role}
      />

      {/* Main Content Area */}
      <div className="flex flex-1 flex-col overflow-hidden">
        <Header
          user={user}
          wsStatus={wsStatus}
          liveGridData={liveGridData}
          onLogout={onLogout}
        />

        <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 bg-slate-950/90">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
