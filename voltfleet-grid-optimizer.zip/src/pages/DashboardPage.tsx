import React from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Truck,
  Zap,
  BatteryCharging,
  Gauge,
  DollarSign,
  AlertTriangle,
  Building2,
  TrendingUp
} from 'lucide-react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';
import { api } from '../services/api';
import { KpiCard } from '../components/KpiCard';
import { StatusBadge } from '../components/StatusBadge';

const COLORS = ['#06b6d4', '#10b981', '#f59e0b', '#6366f1', '#ec4899', '#64748b'];

export function DashboardPage() {
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['dashboardStats'],
    queryFn: () => api.getDashboardStats(),
    refetchInterval: 8000,
  });

  if (isLoading) {
    return (
      <div className="flex h-96 items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-cyan-500 border-t-transparent" />
          <p className="text-xs text-slate-400">Loading operations center telemetry from Supabase PostgreSQL...</p>
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="rounded-xl border border-rose-800/80 bg-rose-950/40 p-6 text-center">
        <AlertTriangle className="mx-auto h-8 w-8 text-rose-400" />
        <h3 className="mt-2 text-sm font-semibold text-rose-200">Unable to load dashboard data</h3>
        <p className="mt-1 text-xs text-rose-300/80">{(error as any)?.message || 'Database query error'}</p>
        <button
          onClick={() => refetch()}
          className="mt-4 rounded-lg bg-rose-900/60 px-4 py-2 text-xs font-medium text-white hover:bg-rose-800 cursor-pointer"
        >
          Retry Connection
        </button>
      </div>
    );
  }

  const { kpis, charts, recent_sessions, grid_alerts } = data;

  return (
    <div className="space-y-6">
      {/* Page Title & Status */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">
            Operational Control Center
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time multi-depot fleet dispatch, grid load optimization, and charging hub telemetry.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => refetch()}
            className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-300 hover:bg-slate-800 hover:text-white transition-colors cursor-pointer"
          >
            <TrendingUp className="h-3.5 w-3.5 text-cyan-400" />
            Refresh Telemetry
          </button>
        </div>
      </div>

      {/* KPI CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        <KpiCard
          title="Total Vehicles"
          value={kpis.total_vehicles}
          subtitle="Commercial EV Fleet"
          icon={Truck}
          accentColor="cyan"
          trend={{ value: "+4.2%", isPositive: true, label: "this quarter" }}
        />
        <KpiCard
          title="Vehicles Charging"
          value={kpis.vehicles_charging}
          subtitle="Connected to fast chargers"
          icon={BatteryCharging}
          accentColor="cyan"
        />
        <KpiCard
          title="Available Ports"
          value={kpis.available_charging_ports}
          subtitle="Ready for dispatch"
          icon={Zap}
          accentColor="emerald"
        />
        <KpiCard
          title="Busy Ports"
          value={kpis.busy_charging_ports}
          subtitle="Delivering power"
          icon={Zap}
          accentColor="amber"
        />
        <KpiCard
          title="Charging Stations"
          value={kpis.total_charging_stations}
          subtitle="Active Superhubs"
          icon={Building2}
          accentColor="indigo"
        />
        <KpiCard
          title="Energy Today"
          value={`${kpis.energy_consumed_today.toLocaleString()} kWh`}
          subtitle="Cumulative delivery"
          icon={Gauge}
          accentColor="cyan"
        />
        <KpiCard
          title="Current Grid Load"
          value={`${kpis.current_grid_load} kW`}
          subtitle="Substation bus draw"
          icon={Gauge}
          accentColor="rose"
        />
        <KpiCard
          title="Charging Cost Today"
          value={`$${kpis.charging_cost_today.toLocaleString()}`}
          subtitle="TOU dynamic tariff"
          icon={DollarSign}
          accentColor="emerald"
        />
      </div>

      {/* 6 CHARTS GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-5">
        {/* Chart 1: Fleet Utilization */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 backdrop-blur-md">
          <h3 className="text-sm font-semibold text-slate-200 mb-1 flex items-center justify-between">
            <span>1. Fleet Utilization Status</span>
            <span className="text-[11px] text-slate-400 font-normal">Real-time status</span>
          </h3>
          <p className="text-xs text-slate-500 mb-4">Breakdown across 50 fleet assets</p>
          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={charts.fleet_utilization}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={75}
                  paddingAngle={4}
                  dataKey="value"
                  label={({ name, percent }: any) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {charts.fleet_utilization?.map((_: any, index: number) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Energy Consumption */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 backdrop-blur-md">
          <h3 className="text-sm font-semibold text-slate-200 mb-1 flex items-center justify-between">
            <span>2. Energy Delivered (Hourly kWh)</span>
            <span className="text-[11px] text-slate-400 font-normal">12h Trend</span>
          </h3>
          <p className="text-xs text-slate-500 mb-4">Cumulative charger energy output</p>
          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={charts.hourly_trend}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="time" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={10} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }} />
                <Bar dataKey="energy_kwh" name="Energy (kWh)" fill="#06b6d4" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 3: Charging Activity */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 backdrop-blur-md">
          <h3 className="text-sm font-semibold text-slate-200 mb-1 flex items-center justify-between">
            <span>3. Charging Power Demand</span>
            <span className="text-[11px] text-slate-400 font-normal">Active kW</span>
          </h3>
          <p className="text-xs text-slate-500 mb-4">EV Charging power profile over time</p>
          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={charts.hourly_trend}>
                <defs>
                  <linearGradient id="chgGradSupabase" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="time" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={10} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }} />
                <Area type="monotone" dataKey="charging_load" name="Charging Load (kW)" stroke="#10b981" fillOpacity={1} fill="url(#chgGradSupabase)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 4: Grid Load */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 backdrop-blur-md">
          <h3 className="text-sm font-semibold text-slate-200 mb-1 flex items-center justify-between">
            <span>4. Substation Total Grid Load</span>
            <span className="text-[11px] text-rose-400 font-normal">Cap 5,000 kW</span>
          </h3>
          <p className="text-xs text-slate-500 mb-4">Base load + EV Fast-charging superposition</p>
          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={charts.hourly_trend}>
                <defs>
                  <linearGradient id="gridLoadGradSupabase" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#f43f5e" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="time" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={10} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }} />
                <Area type="monotone" dataKey="grid_load" name="Grid Load (kW)" stroke="#f43f5e" fillOpacity={1} fill="url(#gridLoadGradSupabase)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 5: Charging Cost */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 backdrop-blur-md">
          <h3 className="text-sm font-semibold text-slate-200 mb-1 flex items-center justify-between">
            <span>5. Hourly Electricity Cost</span>
            <span className="text-[11px] text-slate-400 font-normal">USD ($)</span>
          </h3>
          <p className="text-xs text-slate-500 mb-4">Dynamic pricing billing accumulation</p>
          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={charts.hourly_trend}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="time" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={10} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }} />
                <Line type="monotone" dataKey="cost_usd" name="Cost ($)" stroke="#f59e0b" strokeWidth={2} dot={{ fill: '#f59e0b', r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 6: Station Utilization */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 backdrop-blur-md">
          <h3 className="text-sm font-semibold text-slate-200 mb-1 flex items-center justify-between">
            <span>6. Station Hub Utilization (%)</span>
            <span className="text-[11px] text-slate-400 font-normal">Port Occupancy</span>
          </h3>
          <p className="text-xs text-slate-500 mb-4">Utilization across key superhub locations</p>
          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={charts.station_utilization} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis type="number" domain={[0, 100]} stroke="#64748b" fontSize={10} unit="%" />
                <YAxis type="category" dataKey="station" stroke="#64748b" fontSize={10} width={70} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }} />
                <Bar dataKey="utilization" name="Utilization (%)" fill="#6366f1" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* RECENT SESSIONS & GRID ALERTS */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Recent Charging Sessions */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 backdrop-blur-md">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">Recent Charging Sessions</h3>
              <p className="text-xs text-slate-400">Live & recent fleet recharges from Supabase PostgreSQL</p>
            </div>
            <span className="text-xs font-mono text-cyan-400">{recent_sessions?.length || 0} active/recent</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-slate-800 text-slate-400 font-medium">
                <tr>
                  <th className="pb-2.5">Vehicle</th>
                  <th className="pb-2.5">Hub / Port</th>
                  <th className="pb-2.5">Energy</th>
                  <th className="pb-2.5">Cost</th>
                  <th className="pb-2.5">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {recent_sessions?.map((sess: any) => (
                  <tr key={sess.id} className="hover:bg-slate-800/30">
                    <td className="py-2.5 font-bold text-slate-200">{sess.vehicle_reg}</td>
                    <td className="py-2.5 text-slate-300 font-sans truncate max-w-[140px]">
                      {sess.station_name} ({sess.port_number})
                    </td>
                    <td className="py-2.5 text-cyan-400">{sess.energy_delivered_kwh} kWh</td>
                    <td className="py-2.5 text-slate-300">${sess.cost.toFixed(2)}</td>
                    <td className="py-2.5 font-sans">
                      <StatusBadge status={sess.status} size="sm" />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Grid & Operational Alerts */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 backdrop-blur-md">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">Active Grid & Station Alerts</h3>
              <p className="text-xs text-slate-400">Substation anomalies & charger threshold notifications</p>
            </div>
            <span className="text-xs font-mono text-amber-400">{grid_alerts?.length || 0} active</span>
          </div>
          <div className="space-y-3">
            {grid_alerts?.map((alert: any) => (
              <div
                key={alert.id}
                className="flex items-start gap-3 rounded-xl border border-slate-800 bg-slate-950/60 p-3.5"
              >
                <div className="rounded-lg p-2 bg-amber-500/10 text-amber-400 border border-amber-500/20 shrink-0">
                  <AlertTriangle className="h-4 w-4" />
                </div>
                <div className="flex-1 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-200">{alert.title}</span>
                    <StatusBadge status={alert.severity} size="sm" />
                  </div>
                  <p className="mt-1 text-slate-400 leading-relaxed">{alert.message}</p>
                  <p className="mt-1.5 text-[10px] font-mono text-slate-500">
                    {new Date(alert.created_at).toLocaleTimeString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
