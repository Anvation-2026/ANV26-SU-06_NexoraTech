import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { BatteryCharging, Lock, Mail, ArrowRight, ShieldCheck, Zap, Database } from 'lucide-react';
import { api } from '../services/api';
import { User } from '../types';

interface LoginPageProps {
  onLoginSuccess: (user: User, token: string) => void;
}

export function LoginPage({ onLoginSuccess }: LoginPageProps) {
  const navigate = useNavigate();
  const [email, setEmail] = useState('manager@evfleet.io');
  const [password, setPassword] = useState('password123');
  const [rememberMe, setRememberMe] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!email || !password) {
      setError('Please provide both email and password.');
      return;
    }

    setLoading(true);
    try {
      const data = await api.login(email, password);
      localStorage.setItem('token', data.access_token);
      localStorage.setItem('user', JSON.stringify(data.user));
      onLoginSuccess(data.user, data.access_token);
      navigate('/');
    } catch (err: any) {
      setError(err.message || 'Authentication failed. Please verify credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickLogin = (quickEmail: string) => {
    setEmail(quickEmail);
    setPassword('password123');
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-950 p-4 relative overflow-hidden font-sans">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-cyan-950/30 via-slate-950 to-slate-950 pointer-events-none" />
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="relative w-full max-w-md rounded-2xl border border-slate-800 bg-slate-900/90 p-8 shadow-2xl backdrop-blur-xl"
      >
        {/* Brand header */}
        <div className="flex flex-col items-center text-center">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-tr from-cyan-600 to-blue-500 text-white shadow-xl shadow-cyan-500/25">
            <BatteryCharging className="h-8 w-8" />
          </div>
          <h1 className="mt-4 text-2xl font-bold tracking-tight text-white">GRIDVOLT ENTERPRISE</h1>
          <p className="mt-1 text-xs text-slate-400">EV Fleet & Charging Grid Energy Management Control Center</p>
          <div className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-emerald-950/80 border border-emerald-800/80 px-2.5 py-0.5 text-[11px] font-medium text-emerald-300">
            <Database className="h-3 w-3" />
            Supabase PostgreSQL Backend
          </div>
        </div>

        {error && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="mt-4 rounded-xl border border-rose-800/80 bg-rose-950/60 p-3 text-xs text-rose-300"
          >
            {error}
          </motion.div>
        )}

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Operator Email</label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@evfleet.io"
                className="w-full rounded-xl border border-slate-800 bg-slate-950/80 py-2.5 pl-10 pr-4 text-sm text-slate-100 placeholder-slate-500 focus:border-cyan-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                required
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-medium text-slate-300">Password</label>
              <button
                type="button"
                onClick={() => alert('For this environment, default password for all seeded accounts is: password123')}
                className="text-xs text-cyan-400 hover:underline cursor-pointer"
              >
                Forgot Password?
              </button>
            </div>
            <div className="relative">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full rounded-xl border border-slate-800 bg-slate-950/80 py-2.5 pl-10 pr-4 text-sm text-slate-100 placeholder-slate-500 focus:border-cyan-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                required
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-1">
            <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="rounded border-slate-700 bg-slate-800 text-cyan-500 focus:ring-cyan-500"
              />
              Remember Session
            </label>
            <span className="flex items-center gap-1 text-[11px] text-slate-500">
              <ShieldCheck className="h-3.5 w-3.5 text-emerald-500" /> Supabase Auth
            </span>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-2 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 py-2.5 text-sm font-semibold text-white shadow-lg shadow-cyan-500/20 hover:from-cyan-500 hover:to-blue-500 focus:outline-none disabled:opacity-50 transition-all cursor-pointer"
          >
            {loading ? (
              <span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
            ) : (
              <>
                <span>Sign In to Dashboard</span>
                <ArrowRight className="h-4 w-4" />
              </>
            )}
          </button>
        </form>

        <div className="mt-8 pt-6 border-t border-slate-800">
          <p className="text-center text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">
            Quick Sign-In by Role
          </p>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              onClick={() => handleQuickLogin('admin@evfleet.io')}
              className="flex items-center justify-center gap-1.5 rounded-lg border border-slate-800 bg-slate-950/60 p-2 text-slate-300 hover:border-cyan-500/50 hover:bg-slate-800/80 transition-colors cursor-pointer"
            >
              <Zap className="h-3.5 w-3.5 text-cyan-400" />
              <span>Admin</span>
            </button>
            <button
              onClick={() => handleQuickLogin('manager@evfleet.io')}
              className="flex items-center justify-center gap-1.5 rounded-lg border border-cyan-800/60 bg-cyan-950/40 p-2 text-cyan-300 hover:border-cyan-500 hover:bg-cyan-950/60 transition-colors cursor-pointer"
            >
              <Zap className="h-3.5 w-3.5 text-cyan-400" />
              <span>Fleet Manager</span>
            </button>
            <button
              onClick={() => handleQuickLogin('operator@evfleet.io')}
              className="flex items-center justify-center gap-1.5 rounded-lg border border-slate-800 bg-slate-950/60 p-2 text-slate-300 hover:border-cyan-500/50 hover:bg-slate-800/80 transition-colors cursor-pointer"
            >
              <Zap className="h-3.5 w-3.5 text-amber-400" />
              <span>Station Operator</span>
            </button>
            <button
              onClick={() => handleQuickLogin('viewer@evfleet.io')}
              className="flex items-center justify-center gap-1.5 rounded-lg border border-slate-800 bg-slate-950/60 p-2 text-slate-300 hover:border-cyan-500/50 hover:bg-slate-800/80 transition-colors cursor-pointer"
            >
              <Zap className="h-3.5 w-3.5 text-slate-400" />
              <span>Viewer</span>
            </button>
          </div>
          <p className="text-center text-[11px] text-slate-500 mt-3">
            Default credentials: <code className="text-slate-400">password123</code>
          </p>
        </div>
      </motion.div>
    </div>
  );
}
