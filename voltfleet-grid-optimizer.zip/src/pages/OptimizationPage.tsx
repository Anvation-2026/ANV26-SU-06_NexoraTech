import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Cpu,
  Zap,
  TrendingDown,
  DollarSign,
  Calendar,
  Clock,
  Sparkles,
  BarChart3,
  CheckCircle2,
  Database,
  ArrowRight
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Line
} from 'recharts';
import { api } from '../services/api';
import { OptimizationResult } from '../types';

export function OptimizationPage() {
  const queryClient = useQueryClient();

  // Load vehicles to select from
  const { data: vehiclesData } = useQuery({
    queryKey: ['vehiclesForOpt'],
    queryFn: () => api.getVehicles({ page_size: 50 }),
  });
  const vehicles = vehiclesData?.items || [];

  // Load past schedules
  const { data: pastSchedules = [], refetch: refetchHistory } = useQuery({
    queryKey: ['pastSchedules'],
    queryFn: () => api.getOptimizationSchedules(),
  });

  // Form states
  const [selectedVehicleId, setSelectedVehicleId] = useState<string>('');
  const [currentSoc, setCurrentSoc] = useState<number>(35);
  const [targetSoc, setTargetSoc] = useState<number>(90);
  const [batteryCapacity, setBatteryCapacity] = useState<number>(75);
  const [chargerPower, setChargerPower] = useState<number>(150);
  const [arrivalTime, setArrivalTime] = useState<string>('2026-10-09T18:00');
  const [departureTime, setDepartureTime] = useState<string>('2026-10-10T06:00');
  const [optimizationResult, setOptimizationResult] = useState<OptimizationResult | null>(null);

  // Auto-populate when vehicle selected
  const handleVehicleSelect = (id: string) => {
    setSelectedVehicleId(id);
    const v = vehicles.find((item) => item.id === id);
    if (v) {
      setCurrentSoc(Math.round(v.current_soc));
      setTargetSoc(Math.round(v.target_soc));
      setBatteryCapacity(v.battery_capacity);
      setChargerPower(v.max_charge_rate_kw || 150);
    }
  };

  // Run Optimization mutation
  const optMutation = useMutation({
    mutationFn: async () => {
      return api.runOptimization({
        vehicle_id: selectedVehicleId || (vehicles[0]?.id || 'c0000000-0000-0000-0000-000000000001'),
        current_soc: Number(currentSoc),
        target_soc: Number(targetSoc),
        battery_capacity: Number(batteryCapacity),
        arrival_time: new Date(arrivalTime).toISOString(),
        departure_time: new Date(departureTime).toISOString(),
        charger_power: Number(chargerPower),
      });
    },
    onSuccess: (res) => {
      setOptimizationResult(res);
      refetchHistory();
      queryClient.invalidateQueries({ queryKey: ['dashboardStats'] });
    },
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            SciPy EV Charging Optimization Engine
            <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-cyan-950 border border-cyan-800/80 text-cyan-300 flex items-center gap-1">
              <Cpu className="h-3 w-3 text-cyan-400" />
              SLSQP Cost & Peak Shaving Solver
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Mathematical programming algorithm shifting depot charging out of on-peak TOU tariff windows to minimize electricity costs while honoring departure deadlines.
          </p>
        </div>

        <div className="flex items-center gap-1.5 text-xs text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-3 py-1.5 rounded-xl">
          <Database className="h-3.5 w-3.5" />
          Schedules saved to Supabase: optimization_schedules
        </div>
      </div>

      {/* Main Grid: Form Parameters & Results */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Optimization Parameters */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-xl space-y-4">
          <div className="border-b border-slate-800 pb-3">
            <h3 className="text-sm font-semibold text-white">Solver Parameters</h3>
            <p className="text-[11px] text-slate-400">Configure vehicle energy demand & time constraints</p>
          </div>

          <div className="space-y-3.5 text-xs">
            {/* Select Asset */}
            <div>
              <label className="block text-slate-300 font-medium mb-1">Target Fleet Asset</label>
              <select
                value={selectedVehicleId}
                onChange={(e) => handleVehicleSelect(e.target.value)}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white focus:border-cyan-500 focus:outline-none"
              >
                <option value="">-- Choose Vehicle from Supabase Fleet --</option>
                {vehicles.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.registration_number} - {v.make} {v.model} ({v.current_soc}% SOC)
                  </option>
                ))}
              </select>
            </div>

            {/* Battery & SOC */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Current SOC (%)</label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={currentSoc}
                  onChange={(e) => setCurrentSoc(Number(e.target.value))}
                  className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-medium mb-1">Target SOC (%)</label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={targetSoc}
                  onChange={(e) => setTargetSoc(Number(e.target.value))}
                  className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Pack Capacity (kWh)</label>
                <input
                  type="number"
                  step="0.5"
                  value={batteryCapacity}
                  onChange={(e) => setBatteryCapacity(Number(e.target.value))}
                  className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-medium mb-1">Charger Rating (kW)</label>
                <input
                  type="number"
                  step="10"
                  value={chargerPower}
                  onChange={(e) => setChargerPower(Number(e.target.value))}
                  className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
                />
              </div>
            </div>

            {/* Arrival & Departure Time Window */}
            <div>
              <label className="block text-slate-300 font-medium mb-1">Arrival Time</label>
              <input
                type="datetime-local"
                value={arrivalTime}
                onChange={(e) => setArrivalTime(e.target.value)}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2 text-xs text-white"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Departure Deadline</label>
              <input
                type="datetime-local"
                value={departureTime}
                onChange={(e) => setDepartureTime(e.target.value)}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2 text-xs text-white"
              />
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800">
            <button
              onClick={() => optMutation.mutate()}
              disabled={optMutation.isPending}
              className="w-full flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 py-3 text-xs font-semibold text-white shadow-lg shadow-cyan-500/20 hover:from-cyan-500 hover:to-blue-500 disabled:opacity-50 transition-all cursor-pointer"
            >
              {optMutation.isPending ? (
                <span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
              ) : (
                <>
                  <Sparkles className="h-4 w-4" />
                  <span>Execute SciPy Optimization</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right 2 Columns: Optimization Results & Comparison Chart */}
        <div className="lg:col-span-2 space-y-6">
          {optimizationResult ? (
            <>
              {/* Executive Savings Banner */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="rounded-xl border border-emerald-900/40 bg-emerald-950/20 p-4">
                  <p className="text-[11px] font-semibold text-emerald-400 uppercase">Estimated Savings</p>
                  <p className="text-2xl font-bold text-emerald-300 font-mono mt-1">
                    ${optimizationResult.estimated_savings}
                  </p>
                  <p className="text-[10px] text-emerald-400/80 mt-1">
                    {Math.round(((optimizationResult.baseline_cost! - optimizationResult.estimated_cost) / (optimizationResult.baseline_cost || 1)) * 100)}% cheaper vs immediate charge
                  </p>
                </div>

                <div className="rounded-xl border border-cyan-900/40 bg-cyan-950/20 p-4">
                  <p className="text-[11px] font-semibold text-cyan-400 uppercase">Optimized Energy Cost</p>
                  <p className="text-2xl font-bold text-cyan-300 font-mono mt-1">
                    ${optimizationResult.estimated_cost}
                  </p>
                  <p className="text-[10px] text-cyan-400/80 mt-1">
                    Baseline: ${optimizationResult.baseline_cost}
                  </p>
                </div>

                <div className="rounded-xl border border-slate-800 bg-slate-900/90 p-4">
                  <p className="text-[11px] font-semibold text-amber-400 uppercase">Peak Shaving</p>
                  <p className="text-2xl font-bold text-amber-300 font-mono mt-1">
                    {optimizationResult.baseline_peak_load - optimizationResult.optimized_peak_load} kW
                  </p>
                  <p className="text-[10px] text-slate-400 mt-1">Peak reduced to {optimizationResult.optimized_peak_load} kW</p>
                </div>
              </div>

              {/* Chart Comparison */}
              <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-xl space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div>
                    <h3 className="text-sm font-semibold text-white">
                      Optimized Dispatch vs Immediate Uncontrolled Charging
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      SciPy shifts energy delivery to hours when grid tariff is $0.14-$0.26 / kWh
                    </p>
                  </div>
                </div>

                <div className="h-72 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={optimizationResult.schedule_intervals}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                      <XAxis dataKey="hour_label" stroke="#64748b" tick={{ fontSize: 10 }} />
                      <YAxis stroke="#64748b" tick={{ fontSize: 10 }} unit=" kW" />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#0f172a',
                          borderColor: '#334155',
                          borderRadius: '0.75rem',
                          fontSize: '11px',
                        }}
                      />
                      <Legend />
                      <Bar dataKey="optimized_power_kw" fill="#06b6d4" name="SciPy Optimized Power (kW)" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="baseline_power_kw" fill="#64748b" name="Uncontrolled Baseline (kW)" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </>
          ) : (
            <div className="rounded-2xl border border-dashed border-slate-800 bg-slate-900/40 p-12 text-center text-slate-400">
              <Cpu className="mx-auto h-10 w-10 text-cyan-500 mb-3" />
              <h3 className="text-base font-semibold text-white">Select Vehicle & Run Optimization</h3>
              <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
                The SciPy mathematical model balances total required energy, maximum charger rating, station capacity, and dynamic TOU rates to deliver minimum operating cost.
              </p>
            </div>
          )}

          {/* Past Optimization Schedules History */}
          <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-xl">
            <h3 className="text-sm font-semibold text-white mb-3">
              Historical Optimization Runs (Stored in Supabase)
            </h3>
            <div className="overflow-x-auto rounded-xl border border-slate-800">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="py-2.5 px-3">Asset</th>
                    <th className="py-2.5 px-3">Energy</th>
                    <th className="py-2.5 px-3">Opt Cost</th>
                    <th className="py-2.5 px-3">Savings</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3">Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {pastSchedules.map((s: any) => (
                    <tr key={s.id} className="hover:bg-slate-800/40">
                      <td className="py-2.5 px-3 font-mono font-medium text-white">
                        {s.vehicle_reg}
                      </td>
                      <td className="py-2.5 px-3 font-mono">{s.energy_required} kWh</td>
                      <td className="py-2.5 px-3 font-mono text-cyan-400">${s.estimated_cost}</td>
                      <td className="py-2.5 px-3 font-mono text-emerald-400 font-semibold">
                        +${s.estimated_savings}
                      </td>
                      <td className="py-2.5 px-3">
                        <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800">
                          {s.status}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-500">
                        {new Date(s.created_at).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
