import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Activity,
  Zap,
  BatteryCharging,
  Gauge,
  Radio,
  RefreshCw,
  Power,
  Sliders,
  CheckCircle2,
  AlertTriangle,
  Database,
  Play,
  Square
} from 'lucide-react';
import {
  AreaChart,
  Area,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';
import { api } from '../services/api';
import { useLiveTelemetry } from '../hooks/useLiveTelemetry';
import { StatusBadge } from '../components/StatusBadge';
import { BatteryIndicator } from '../components/BatteryIndicator';

export function DigitalTwinPage() {
  const queryClient = useQueryClient();
  const { status: liveStatus, liveGridData, liveChargers } = useLiveTelemetry();
  const [selectedStationId, setSelectedStationId] = useState<string>('a0000000-0000-0000-0000-000000000001');
  const [selectedPortId, setSelectedPortId] = useState<string | null>(null);

  // Stations query
  const { data: stations = [] } = useQuery({
    queryKey: ['stations'],
    queryFn: () => api.getStations(),
  });

  // Charging ports query
  const { data: ports = [] } = useQuery({
    queryKey: ['chargingPorts', selectedStationId],
    queryFn: () => api.getChargingPorts({ station_id: selectedStationId }),
  });

  // Selected port details
  const currentPort = ports.find((p) => p.id === selectedPortId) || ports[0];

  // Mutation to toggle port state in Supabase
  const togglePortMutation = useMutation({
    mutationFn: async ({ id, newStatus, currentPower }: { id: string; newStatus: string; currentPower: number }) => {
      return api.updatePort(id, {
        status: newStatus as any,
        current_power_kw: currentPower,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['chargingPorts'] });
      queryClient.invalidateQueries({ queryKey: ['portsSummary'] });
      queryClient.invalidateQueries({ queryKey: ['stations'] });
      queryClient.invalidateQueries({ queryKey: ['dashboardStats'] });
    },
  });

  // Generate live digital twin waveform data
  const now = Date.now();
  const waveformData = Array.from({ length: 15 }, (_, i) => {
    const t = new Date(now - (14 - i) * 2000);
    const power = currentPort?.current_power_kw || 120.0;
    const osc = Math.sin((i / 15) * Math.PI * 2) * 4.5;
    return {
      time: `${t.getSeconds()}s`,
      power_kw: Math.max(0, Math.round((power + osc) * 10) / 10),
      voltage_v: Math.round((400.0 + Math.sin(i) * 1.5) * 10) / 10,
      current_a: Math.round(((power * 1000) / 400.0 + Math.cos(i) * 2.0) * 10) / 10,
      temperature_c: Math.round((34.2 + (power > 50 ? (i * 0.1) : 0)) * 10) / 10,
    };
  });

  const selectedStation = stations.find((s) => s.id === selectedStationId) || stations[0];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            Depot Digital Twin & Live Telemetry
            <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-cyan-950 border border-cyan-800/80 text-cyan-300 flex items-center gap-1">
              <Radio className="h-3 w-3 animate-pulse text-cyan-400" />
              Supabase Realtime Stream
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time physical asset twin for power distribution, charger waveforms, and connected EV battery dynamics.
          </p>
        </div>

        {/* Station Selector Dropdown */}
        <div className="flex items-center gap-2">
          <label className="text-xs text-slate-400 font-medium">Select Hub Depot:</label>
          <select
            value={selectedStationId}
            onChange={(e) => {
              setSelectedStationId(e.target.value);
              setSelectedPortId(null);
            }}
            className="rounded-xl border border-slate-800 bg-slate-900 py-2 px-3 text-xs text-slate-200 focus:border-cyan-500 focus:outline-none cursor-pointer"
          >
            {stations.map((s) => (
              <option key={s.id} value={s.id}>
                {s.code} - {s.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Grid: Twin Visualization + Telemetry Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Depot Bay Canvas */}
        <div className="lg:col-span-2 space-y-6">
          <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-5">
              <div>
                <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                  <Activity className="h-4 w-4 text-cyan-400" />
                  {selectedStation?.name || 'Charging Superhub'} • Physical Bay Matrix
                </h3>
                <p className="text-[11px] text-slate-400">
                  {selectedStation?.address} • Station Max Capacity: {selectedStation?.max_station_power_kw || 350} kW
                </p>
              </div>
              <div className="flex items-center gap-3 text-xs">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <span className="h-2 w-2 rounded-full bg-cyan-400 animate-pulse" />
                  Busy / Charging
                </span>
                <span className="flex items-center gap-1.5 text-slate-400">
                  <span className="h-2 w-2 rounded-full bg-emerald-400" />
                  Available
                </span>
              </div>
            </div>

            {/* Visual Charging Bay Slots */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {ports.map((port) => {
                const isSelected = (currentPort?.id === port.id);
                const isBusy = (port.status === 'BUSY');

                return (
                  <div
                    key={port.id}
                    onClick={() => setSelectedPortId(port.id)}
                    className={`group relative rounded-xl border p-4 cursor-pointer transition-all duration-200 ${
                      isSelected
                        ? 'border-cyan-500 bg-cyan-950/20 shadow-lg shadow-cyan-500/10 ring-1 ring-cyan-500/50'
                        : isBusy
                        ? 'border-slate-800 bg-slate-950/70 hover:border-slate-700'
                        : 'border-slate-800/80 bg-slate-950/40 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-white font-mono">{port.port_number}</span>
                      <StatusBadge status={port.status} size="sm" />
                    </div>

                    <div className="text-[11px] text-slate-400 mb-3 flex items-center justify-between">
                      <span>{port.connector_type}</span>
                      <span className="font-mono text-slate-300">{port.max_power_kw} kW max</span>
                    </div>

                    {isBusy ? (
                      <div className="rounded-lg bg-slate-900/80 p-2.5 border border-slate-800/60 space-y-2">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-mono font-medium text-cyan-300">
                            {port.connected_vehicle_reg || 'EV Asset'}
                          </span>
                          <span className="font-mono font-bold text-amber-400">
                            {port.current_power_kw} kW
                          </span>
                        </div>
                        <BatteryIndicator
                          soc={port.vehicle_soc || 68}
                          isCharging={true}
                          size="sm"
                        />
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center py-3 text-slate-600 rounded-lg border border-dashed border-slate-800">
                        <Zap className="h-5 w-5 mb-1" />
                        <span className="text-[11px]">Bay Empty (Ready)</span>
                      </div>
                    )}

                    <div className="mt-3 flex items-center justify-between text-[10px] text-slate-500 pt-2 border-t border-slate-800/60">
                      <span>Click to Inspect Twin</span>
                      <span className="text-cyan-400 font-mono">Live Sync</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Live Waveform Chart */}
          <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                  <Zap className="h-4 w-4 text-amber-400" />
                  Live Digital Twin Power & Voltage Waveform
                </h3>
                <p className="text-[11px] text-slate-400">
                  Target: {currentPort?.port_number} ({currentPort?.connector_type}) • Real-time sampling @ 10 Hz
                </p>
              </div>
              <div className="text-xs font-mono text-cyan-400 bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800">
                P = {currentPort?.current_power_kw || 0} kW
              </div>
            </div>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={waveformData}>
                  <defs>
                    <linearGradient id="twinPowerGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="time" stroke="#64748b" tick={{ fontSize: 10 }} />
                  <YAxis stroke="#64748b" tick={{ fontSize: 10 }} unit=" kW" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderColor: '#334155',
                      borderRadius: '0.75rem',
                      fontSize: '11px',
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="power_kw"
                    stroke="#06b6d4"
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#twinPowerGrad)"
                    name="Charging Power (kW)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Right 1 Col: Port Telemetry Inspector & Remote Controls */}
        <div className="space-y-6">
          <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-xl space-y-5">
            <div className="border-b border-slate-800 pb-3">
              <span className="text-[10px] uppercase font-bold tracking-wider text-cyan-400">
                Port Inspector
              </span>
              <h3 className="text-lg font-bold text-white mt-1">
                {currentPort?.port_number || 'Port 01'}
              </h3>
              <p className="text-xs text-slate-400">{selectedStation?.name}</p>
            </div>

            {/* Port Status Summary */}
            <div className="space-y-3 text-xs">
              <div className="flex items-center justify-between py-1.5 border-b border-slate-800/60">
                <span className="text-slate-400">Current Status:</span>
                <StatusBadge status={currentPort?.status || 'AVAILABLE'} size="sm" />
              </div>
              <div className="flex items-center justify-between py-1.5 border-b border-slate-800/60">
                <span className="text-slate-400">Connected Asset:</span>
                <span className="font-mono font-semibold text-white">
                  {currentPort?.connected_vehicle_reg || 'None'}
                </span>
              </div>
              <div className="flex items-center justify-between py-1.5 border-b border-slate-800/60">
                <span className="text-slate-400">Connector Standard:</span>
                <span className="font-medium text-slate-200">{currentPort?.connector_type}</span>
              </div>
              <div className="flex items-center justify-between py-1.5 border-b border-slate-800/60">
                <span className="text-slate-400">Active Power Delivery:</span>
                <span className="font-mono font-bold text-cyan-400">
                  {currentPort?.current_power_kw || 0.0} kW
                </span>
              </div>
              <div className="flex items-center justify-between py-1.5 border-b border-slate-800/60">
                <span className="text-slate-400">Bus Line Voltage:</span>
                <span className="font-mono text-slate-200">400.2 V</span>
              </div>
              <div className="flex items-center justify-between py-1.5 border-b border-slate-800/60">
                <span className="text-slate-400">Current Amperage:</span>
                <span className="font-mono text-slate-200">
                  {Math.round(((currentPort?.current_power_kw || 0) * 1000) / 400.0)} A
                </span>
              </div>
              <div className="flex items-center justify-between py-1.5">
                <span className="text-slate-400">Thermal Probe:</span>
                <span className="font-mono text-emerald-400">34.2 °C (Nominal)</span>
              </div>
            </div>

            {/* Remote Simulator Actions */}
            <div className="pt-3 border-t border-slate-800 space-y-2.5">
              <p className="text-xs font-semibold text-slate-300">Remote Operations Control</p>
              {currentPort?.status === 'BUSY' ? (
                <button
                  onClick={() =>
                    currentPort &&
                    togglePortMutation.mutate({
                      id: currentPort.id,
                      newStatus: 'AVAILABLE',
                      currentPower: 0.0,
                    })
                  }
                  disabled={togglePortMutation.isPending}
                  className="w-full flex items-center justify-center gap-2 rounded-xl bg-rose-600/20 border border-rose-500/40 p-2.5 text-xs font-semibold text-rose-300 hover:bg-rose-600/30 transition-all cursor-pointer"
                >
                  <Square className="h-3.5 w-3.5 text-rose-400" />
                  Stop Charge & Disconnect Bay
                </button>
              ) : (
                <button
                  onClick={() =>
                    currentPort &&
                    togglePortMutation.mutate({
                      id: currentPort.id,
                      newStatus: 'BUSY',
                      currentPower: 120.0,
                    })
                  }
                  disabled={togglePortMutation.isPending}
                  className="w-full flex items-center justify-center gap-2 rounded-xl bg-cyan-600/20 border border-cyan-500/40 p-2.5 text-xs font-semibold text-cyan-300 hover:bg-cyan-600/30 transition-all cursor-pointer"
                >
                  <Play className="h-3.5 w-3.5 text-cyan-400" />
                  Simulate Fast Charge Session (120 kW)
                </button>
              )}

              <p className="text-[11px] text-slate-500 text-center">
                Updates are persisted immediately to the Supabase PostgreSQL database table <code className="text-slate-400">charging_ports</code>.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
