import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'motion/react';
import {
  Zap,
  Filter,
  Truck,
  Clock,
  Gauge,
  Thermometer,
  X,
  CheckCircle2,
  AlertOctagon,
  RefreshCw
} from 'lucide-react';
import { api } from '../services/api';
import { ChargingPort } from '../types';
import { useLiveTelemetry } from '../hooks/useLiveTelemetry';
import { StatusBadge } from '../components/StatusBadge';
import { BatteryIndicator } from '../components/BatteryIndicator';

export function ChargingPortsPage() {
  const { liveChargers } = useLiveTelemetry();
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [selectedPortId, setSelectedPortId] = useState<string | null>(null);

  // Summary query
  const { data: summary } = useQuery({
    queryKey: ['portsSummary'],
    queryFn: () => api.getPortsSummary(),
    refetchInterval: 5000,
  });

  // Ports list query
  const { data: ports, isLoading, refetch } = useQuery({
    queryKey: ['chargingPorts', statusFilter],
    queryFn: () => api.getChargingPorts({ status: statusFilter }),
    refetchInterval: 5000,
  });

  // Port detail query
  const { data: portDetail } = useQuery({
    queryKey: ['portDetail', selectedPortId],
    queryFn: () => (selectedPortId ? api.getChargingPort(selectedPortId) : null),
    enabled: !!selectedPortId,
  });

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            Charging Ports Infrastructure
            <span className="text-xs font-mono font-medium px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
              {summary?.total || 60} High-Power Outlets
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time outlet monitoring, thermal throttling safety, and power delivery logs.
          </p>
        </div>
        <button
          onClick={() => refetch()}
          className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-xs font-semibold text-slate-300 hover:bg-slate-800 hover:text-white"
        >
          <RefreshCw className="h-3.5 w-3.5 text-cyan-400" />
          Refresh
        </button>
      </div>

      {/* SUMMARY KPI CARDS */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div
          onClick={() => setStatusFilter('ALL')}
          className={`cursor-pointer rounded-xl border p-3.5 backdrop-blur-md transition-all ${
            statusFilter === 'ALL' ? 'border-cyan-500 bg-slate-900' : 'border-slate-800 bg-slate-950/80'
          }`}
        >
          <span className="text-[10px] text-slate-400 uppercase tracking-wider">Total Ports</span>
          <p className="mt-1 text-2xl font-bold text-white font-mono">{summary?.total || 60}</p>
        </div>

        <div
          onClick={() => setStatusFilter('AVAILABLE')}
          className={`cursor-pointer rounded-xl border p-3.5 backdrop-blur-md transition-all ${
            statusFilter === 'AVAILABLE' ? 'border-emerald-500 bg-emerald-950/30' : 'border-slate-800 bg-slate-950/80'
          }`}
        >
          <span className="text-[10px] text-emerald-400 uppercase tracking-wider">Available</span>
          <p className="mt-1 text-2xl font-bold text-emerald-400 font-mono">{summary?.available || 45}</p>
        </div>

        <div
          onClick={() => setStatusFilter('BUSY')}
          className={`cursor-pointer rounded-xl border p-3.5 backdrop-blur-md transition-all ${
            statusFilter === 'BUSY' ? 'border-cyan-500 bg-cyan-950/30' : 'border-slate-800 bg-slate-950/80'
          }`}
        >
          <span className="text-[10px] text-cyan-400 uppercase tracking-wider">Busy / In Use</span>
          <p className="mt-1 text-2xl font-bold text-cyan-400 font-mono">{summary?.busy || 12}</p>
        </div>

        <div
          onClick={() => setStatusFilter('RESERVED')}
          className={`cursor-pointer rounded-xl border p-3.5 backdrop-blur-md transition-all ${
            statusFilter === 'RESERVED' ? 'border-amber-500 bg-amber-950/30' : 'border-slate-800 bg-slate-950/80'
          }`}
        >
          <span className="text-[10px] text-amber-400 uppercase tracking-wider">Reserved</span>
          <p className="mt-1 text-2xl font-bold text-amber-400 font-mono">{summary?.reserved || 3}</p>
        </div>

        <div
          onClick={() => setStatusFilter('FAULTED')}
          className={`cursor-pointer rounded-xl border p-3.5 backdrop-blur-md transition-all ${
            statusFilter === 'FAULTED' ? 'border-rose-500 bg-rose-950/30' : 'border-slate-800 bg-slate-950/80'
          }`}
        >
          <span className="text-[10px] text-rose-400 uppercase tracking-wider">Faulted</span>
          <p className="mt-1 text-2xl font-bold text-rose-400 font-mono">{summary?.faulted || 1}</p>
        </div>

        <div
          onClick={() => setStatusFilter('OFFLINE')}
          className={`cursor-pointer rounded-xl border p-3.5 backdrop-blur-md transition-all ${
            statusFilter === 'OFFLINE' ? 'border-slate-600 bg-slate-900' : 'border-slate-800 bg-slate-950/80'
          }`}
        >
          <span className="text-[10px] text-slate-500 uppercase tracking-wider">Offline</span>
          <p className="mt-1 text-2xl font-bold text-slate-400 font-mono">{summary?.offline || 1}</p>
        </div>
      </div>

      {/* PORTS GRID CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {isLoading ? (
          <div className="col-span-full py-16 text-center text-slate-400">
            <div className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-cyan-500 border-t-transparent" />
            <p className="mt-2 text-xs">Loading charging ports from PostgreSQL...</p>
          </div>
        ) : ports?.length === 0 ? (
          <div className="col-span-full py-16 text-center text-slate-400">
            No ports found under status "{statusFilter}".
          </div>
        ) : (
          ports?.map((port) => {
            const liveData = liveChargers[port.id];
            const activePower = liveData?.current_power_kw ?? port.current_power_kw;
            const activeStatus = liveData?.status ?? port.status;
            const activeSoc = liveData?.vehicle_soc ?? port.vehicle_soc;
            const activeReg = liveData?.vehicle_reg ?? port.connected_vehicle_reg;

            return (
              <motion.div
                key={port.id}
                whileHover={{ y: -2 }}
                onClick={() => setSelectedPortId(port.id)}
                className={`cursor-pointer rounded-2xl border p-5 backdrop-blur-md transition-all shadow-lg ${
                  activeStatus === 'BUSY'
                    ? 'border-cyan-500/40 bg-slate-900/90'
                    : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-mono font-bold text-sm text-white">{port.port_number}</span>
                    <p className="text-[11px] text-slate-400 truncate max-w-[150px]">{port.station_name}</p>
                  </div>
                  <StatusBadge status={activeStatus} size="sm" />
                </div>

                <div className="mt-4 space-y-1.5 text-xs font-mono">
                  <div className="flex justify-between text-slate-400 font-sans">
                    <span>Connector:</span>
                    <span className="font-mono font-medium text-slate-200">{port.connector_type}</span>
                  </div>
                  <div className="flex justify-between text-slate-400 font-sans">
                    <span>Max Rating:</span>
                    <span className="font-mono text-slate-200">{port.max_power_kw} kW</span>
                  </div>
                  <div className="flex justify-between text-slate-400 font-sans">
                    <span>Active Output:</span>
                    <span className="font-mono font-bold text-cyan-400">{activePower} kW</span>
                  </div>
                </div>

                {activeStatus === 'BUSY' ? (
                  <div className="mt-4 rounded-xl border border-slate-800 bg-slate-950/80 p-3 text-xs">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[11px] text-slate-400 flex items-center gap-1">
                        <Truck className="h-3.5 w-3.5 text-cyan-400" />
                        {activeReg || 'Fleet Truck'}
                      </span>
                      <span className="text-[10px] text-cyan-400 font-mono animate-pulse">45 min</span>
                    </div>
                    {activeSoc !== null && activeSoc !== undefined && (
                      <BatteryIndicator soc={activeSoc} isCharging={true} size="sm" />
                    )}
                    <div className="mt-2 text-[10px] text-slate-500 flex justify-between font-mono">
                      <span>DELIVERED: {port.energy_delivered_kwh || 38.5} kWh</span>
                    </div>
                  </div>
                ) : (
                  <div className="mt-4 rounded-xl border border-dashed border-slate-800 bg-slate-950/40 p-3 text-center text-xs text-slate-500">
                    Port available for charging
                  </div>
                )}
              </motion.div>
            );
          })
        )}
      </div>

      {/* PORT TELEMETRY DRAWER */}
      {portDetail && (
        <div className="fixed inset-y-0 right-0 z-50 w-full max-w-md bg-slate-900 border-l border-slate-800 shadow-2xl p-6 overflow-y-auto">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <h2 className="text-lg font-bold text-white font-mono">{portDetail.port_number}</h2>
              <p className="text-xs text-slate-400">{portDetail.station_name} &bull; {portDetail.connector_type}</p>
            </div>
            <button
              onClick={() => setSelectedPortId(null)}
              className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          <div className="mt-6 space-y-4 text-xs font-mono">
            <div className="rounded-xl border border-slate-800 bg-slate-950 p-4">
              <span className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold font-sans">
                Port Specifications
              </span>
              <div className="mt-3 grid grid-cols-2 gap-3 text-slate-300">
                <div>
                  <span className="text-slate-500 text-[10px]">MAX POWER</span>
                  <p className="font-bold">{portDetail.max_power_kw} kW</p>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px]">CURRENT POWER</span>
                  <p className="font-bold text-cyan-400">{portDetail.current_power_kw} kW</p>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px]">STATUS</span>
                  <div className="mt-0.5"><StatusBadge status={portDetail.status} size="sm" /></div>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px]">CONNECTED EV</span>
                  <p className="font-bold">{portDetail.connected_vehicle_reg || 'None'}</p>
                </div>
              </div>
            </div>

            {/* Live Telemetry History */}
            <div className="rounded-xl border border-slate-800 bg-slate-950 p-4">
              <span className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold font-sans">
                Recent Port Sensor Readings (Simulated)
              </span>
              <div className="mt-3 space-y-2">
                {portDetail.recent_telemetry?.slice(0, 5).map((t: any, idx: number) => (
                  <div key={idx} className="flex justify-between items-center bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-slate-400">{new Date(t.created_at).toLocaleTimeString()}</span>
                    <span className="text-cyan-400">{t.power_kw} kW</span>
                    <span className="text-emerald-400">{t.voltage_v} V</span>
                    <span className="text-amber-400">{t.temperature_c} &deg;C</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
