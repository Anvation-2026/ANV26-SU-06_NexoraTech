import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Star,
  MessageSquare,
  Search,
  Filter,
  Plus,
  ThumbsUp,
  Building2,
  Calendar,
  Sparkles
} from 'lucide-react';
import { api } from '../services/api';
import { CustomerFeedback } from '../types';
import { Modal } from '../components/Modal';

export function CustomerFeedbackPage() {
  const queryClient = useQueryClient();
  const [categoryFilter, setCategoryFilter] = useState('ALL');
  const [stationFilter, setStationFilter] = useState('ALL');
  const [search, setSearch] = useState('');
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState(false);

  // Form state
  const [formStationId, setFormStationId] = useState('');
  const [formName, setFormName] = useState('Commercial Fleet Driver');
  const [formRating, setFormRating] = useState(5);
  const [formCategory, setFormCategory] = useState('CHARGING_SPEED');
  const [formComment, setFormComment] = useState('');

  // Fetch summary
  const { data: summary } = useQuery({
    queryKey: ['feedbackSummary'],
    queryFn: () => api.getFeedbackSummary(),
  });

  // Fetch feedback list
  const { data: feedbackList, isLoading } = useQuery({
    queryKey: ['feedback', categoryFilter, stationFilter, search],
    queryFn: () =>
      api.getFeedback({
        category: categoryFilter,
        station_id: stationFilter,
      }),
  });

  // Fetch stations for dropdowns
  const { data: stations } = useQuery({
    queryKey: ['stations'],
    queryFn: () => api.getStations(),
  });

  // Submit feedback mutation
  const submitMutation = useMutation({
    mutationFn: (payload: any) => api.submitFeedback(payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['feedback'] });
      queryClient.invalidateQueries({ queryKey: ['feedbackSummary'] });
      setIsSubmitModalOpen(false);
      setFormComment('');
    },
    onError: (err: any) => {
      alert(`Error submitting feedback: ${err.message}`);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formStationId && stations && stations.length > 0) {
      setFormStationId(stations[0].id);
    }
    submitMutation.mutate({
      station_id: formStationId || (stations ? stations[0].id : ''),
      customer_name: formName,
      rating: formRating,
      category: formCategory,
      comment: formComment,
    });
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            Driver & Operator Feedback
            <span className="text-xs font-mono font-medium px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
              {summary?.total_reviews || 0} Verified Reviews
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Driver satisfaction ratings, charging speed perceptions, hardware reliability, and ease of use.
          </p>
        </div>
        <button
          onClick={() => {
            if (stations && stations.length > 0) setFormStationId(stations[0].id);
            setIsSubmitModalOpen(true);
          }}
          className="flex items-center gap-2 rounded-xl bg-cyan-600 px-4 py-2.5 text-xs font-semibold text-white hover:bg-cyan-500 shadow-lg shadow-cyan-600/20 transition-all cursor-pointer"
        >
          <Plus className="h-4 w-4" />
          <span>Submit Driver Review</span>
        </button>
      </div>

      {/* RATING SUMMARY CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Overall Score */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 backdrop-blur-md flex flex-col items-center justify-center text-center">
          <span className="text-xs uppercase tracking-wider text-slate-400 font-semibold">Average Fleet Satisfaction</span>
          <div className="mt-2 text-4xl font-bold text-white font-mono flex items-center gap-2">
            <span>{summary?.average_rating || 4.8}</span>
            <span className="text-amber-400 text-2xl">/ 5.0</span>
          </div>
          <div className="mt-2 flex items-center gap-1 text-amber-400">
            {[1, 2, 3, 4, 5].map((s) => (
              <Star key={s} className="h-4 w-4 fill-amber-400" />
            ))}
          </div>
          <p className="mt-2 text-[11px] text-slate-500">Based on {summary?.total_reviews || 0} operational audits</p>
        </div>

        {/* Rating Distribution */}
        <div className="md:col-span-2 rounded-2xl border border-slate-800 bg-slate-900/90 p-5 backdrop-blur-md">
          <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-3">
            Star Distribution Rating Breakdown
          </h3>
          <div className="space-y-2">
            {[5, 4, 3, 2, 1].map((star) => {
              const count = summary?.rating_distribution?.[star] || 0;
              const total = summary?.total_reviews || 1;
              const pct = Math.round((count / total) * 100);
              return (
                <div key={star} className="flex items-center gap-3 text-xs font-mono">
                  <span className="w-12 text-slate-400 flex items-center gap-1">
                    {star} <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
                  </span>
                  <div className="flex-1 h-2 rounded-full bg-slate-800 overflow-hidden">
                    <div className="h-full bg-amber-400 rounded-full" style={{ width: `${pct}%` }} />
                  </div>
                  <span className="w-10 text-right text-slate-400">{count}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* FILTER CONTROLS */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 rounded-2xl border border-slate-800 bg-slate-900/80 p-4 backdrop-blur-md">
        <div className="flex items-center gap-3 flex-wrap text-xs">
          <div className="flex items-center gap-2">
            <span className="text-slate-400">Category:</span>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2 text-xs text-slate-200 focus:border-cyan-500 focus:outline-none"
            >
              <option value="ALL">All Categories</option>
              <option value="CHARGING_SPEED">Charging Speed</option>
              <option value="AVAILABILITY">Stall Availability</option>
              <option value="PAYMENT">Billing & Payment</option>
              <option value="APP_EXPERIENCE">Telemetry & App</option>
              <option value="LOCATION">Hub Location</option>
              <option value="HARDWARE">Hardware & Cables</option>
              <option value="CUSTOMER_SERVICE">Customer Service</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-slate-400">Station Hub:</span>
            <select
              value={stationFilter}
              onChange={(e) => setStationFilter(e.target.value)}
              className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2 text-xs text-slate-200 focus:border-cyan-500 focus:outline-none"
            >
              <option value="ALL">All Hubs</option>
              {stations?.map((st) => (
                <option key={st.id} value={st.id}>{st.name}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* FEEDBACK LIST */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {isLoading ? (
          <div className="col-span-full py-12 text-center text-slate-400">
            <div className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-cyan-500 border-t-transparent" />
            <p className="mt-2 text-xs">Loading feedback from PostgreSQL...</p>
          </div>
        ) : feedbackList?.length === 0 ? (
          <div className="col-span-full py-12 text-center text-slate-500">
            No reviews matching selected filter.
          </div>
        ) : (
          feedbackList?.map((item) => (
            <div
              key={item.id}
              className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 backdrop-blur-md flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-1.5">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <Star
                        key={s}
                        className={`h-3.5 w-3.5 ${
                          s <= item.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-700'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="rounded-md bg-slate-800 px-2 py-0.5 text-[10px] font-mono font-medium text-cyan-400">
                    {item.category.replace(/_/g, ' ')}
                  </span>
                </div>

                <p className="text-xs text-slate-200 leading-relaxed italic">
                  &ldquo;{item.comment}&rdquo;
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                <span className="font-semibold text-slate-300">{item.customer_name}</span>
                <span className="truncate max-w-[150px] text-slate-500">{item.station_name}</span>
              </div>
            </div>
          ))
        )}
      </div>

      {/* SUBMIT REVIEW MODAL */}
      <Modal
        isOpen={isSubmitModalOpen}
        onClose={() => setIsSubmitModalOpen(false)}
        title="Submit Commercial Driver Review"
      >
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 mb-1">Charging Superhub</label>
            <select
              value={formStationId}
              onChange={(e) => setFormStationId(e.target.value)}
              className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2 text-slate-200 focus:border-cyan-500 focus:outline-none"
              required
            >
              {stations?.map((st) => (
                <option key={st.id} value={st.id}>{st.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-slate-300 mb-1">Driver Name / Organization</label>
            <input
              type="text"
              value={formName}
              onChange={(e) => setFormName(e.target.value)}
              className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2 text-slate-200 focus:border-cyan-500 focus:outline-none"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 mb-1">Rating (1 to 5 Stars)</label>
              <select
                value={formRating}
                onChange={(e) => setFormRating(parseInt(e.target.value))}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2 text-slate-200 focus:border-cyan-500 focus:outline-none"
              >
                <option value={5}>5 Stars (Excellent)</option>
                <option value={4}>4 Stars (Good)</option>
                <option value={3}>3 Stars (Average)</option>
                <option value={2}>2 Stars (Poor)</option>
                <option value={1}>1 Star (Critical Issues)</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-300 mb-1">Audit Category</label>
              <select
                value={formCategory}
                onChange={(e) => setFormCategory(e.target.value)}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2 text-slate-200 focus:border-cyan-500 focus:outline-none"
              >
                <option value="CHARGING_SPEED">Charging Speed</option>
                <option value="AVAILABILITY">Stall Availability</option>
                <option value="PAYMENT">Billing & Payment</option>
                <option value="APP_EXPERIENCE">Telemetry & App</option>
                <option value="LOCATION">Hub Location</option>
                <option value="HARDWARE">Hardware & Cables</option>
                <option value="CUSTOMER_SERVICE">Customer Service</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-slate-300 mb-1">Observation / Operational Comment</label>
            <textarea
              rows={3}
              value={formComment}
              onChange={(e) => setFormComment(e.target.value)}
              placeholder="Detail charging speeds, connector handling, bay ingress, or electrical issues..."
              className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2 text-slate-200 focus:border-cyan-500 focus:outline-none"
              required
            />
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={() => setIsSubmitModalOpen(false)}
              className="rounded-xl border border-slate-800 px-4 py-2 text-slate-400 hover:bg-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitMutation.isPending}
              className="rounded-xl bg-cyan-600 px-4 py-2 font-semibold text-white hover:bg-cyan-500 disabled:opacity-50"
            >
              {submitMutation.isPending ? 'Publishing...' : 'Publish Feedback'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
