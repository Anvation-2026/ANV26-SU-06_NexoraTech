import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Zap,
  Filter,
  RefreshCw,
  Search,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Radio,
  Play,
  Square,
  Activity,
  Database
} from 'lucide-react';
import { api } from '../services/api';
import { ChargingPort } from '../types';
import { StatusBadge } from '../components/StatusBadge';
import { BatteryIndicator } from '../components/BatteryIndicator';
import { Modal } from '../components/Modal';

export function PortsPage() {
  const queryClient = useQueryClient();
  const [stationFilter, setStationFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPort, setSelectedPort] = useState<ChargingPort | null>(null);

  // Ports Summary query
  const { data: summary } = useQuery({
    queryKey: ['portsSummary'],
    queryFn: () => api.getPortsSummary(),
  });

  // Stations query
  const { data: stations = [] } = useQuery({
    queryKey: ['stations'],
    queryFn: () => api.getStations(),
  });

  // Charging Ports query
  const { data: ports = [], isLoading, refetch } = useQuery({
    queryKey: ['chargingPorts', statusFilter, stationFilter],
    queryFn: () =>
      api.getChargingPorts({
        status: statusFilter,
        station_id: stationFilter,
      }),
  });

  // Port update mutation
  const togglePortMutation = useMutation({
    mutationFn: async ({ id, newStatus, currentPower }: { id: string; newStatus: string; currentPower: number }) => {
      return api.updatePort(id, {
        status: newStatus as any,
        current_power_kw: currentPower,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['chargingPorts'] });
      queryClient.invalidateQueries({ queryKey: ['portsSummary'] });
      queryClient.invalidateQueries({ queryKey: ['stations'] });
      queryClient.invalidateQueries({ queryKey: ['dashboardStats'] });
      if (selectedPort) {
        setSelectedPort(null);
      }
    },
  });

  const filteredPorts = ports.filter((p) => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      p.port_number.toLowerCase().includes(term) ||
      p.connector_type.toLowerCase().includes(term) ||
      (p.station_name && p.station_name.toLowerCase().includes(term)) ||
      (p.connected_vehicle_reg && p.connected_vehicle_reg.toLowerCase().includes(term))
    );
  });

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            Charging Port Infrastructure
            <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-800/80 text-emerald-400 flex items-center gap-1">
              <Database className="h-3 w-3" />
              Supabase Table: charging_ports
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time port connectivity status, power ratings, and charging session dispatch across all depot hubs.
          </p>
        </div>

        <button
          onClick={() => refetch()}
          className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-xs font-medium text-slate-300 hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <RefreshCw className="h-3.5 w-3.5" />
          Refresh Ports
        </button>
      </div>

      {/* KPI Overview Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-3.5">
          <p className="text-[11px] font-semibold text-slate-400 uppercase">Total Ports</p>
          <p className="text-xl font-bold text-white font-mono mt-1">{summary?.total || 60}</p>
        </div>
        <div className="rounded-xl border border-emerald-900/40 bg-emerald-950/20 p-3.5">
          <p className="text-[11px] font-semibold text-emerald-400 uppercase">Available</p>
          <p className="text-xl font-bold text-emerald-300 font-mono mt-1">{summary?.available || 45}</p>
        </div>
        <div className="rounded-xl border border-cyan-900/40 bg-cyan-950/20 p-3.5">
          <p className="text-[11px] font-semibold text-cyan-400 uppercase">Charging / Busy</p>
          <p className="text-xl font-bold text-cyan-300 font-mono mt-1">{summary?.busy || 12}</p>
        </div>
        <div className="rounded-xl border border-amber-900/40 bg-amber-950/20 p-3.5">
          <p className="text-[11px] font-semibold text-amber-400 uppercase">Reserved</p>
          <p className="text-xl font-bold text-amber-300 font-mono mt-1">{summary?.reserved || 2}</p>
        </div>
        <div className="rounded-xl border border-rose-900/40 bg-rose-950/20 p-3.5">
          <p className="text-[11px] font-semibold text-rose-400 uppercase">Faulted / Maint</p>
          <p className="text-xl font-bold text-rose-300 font-mono mt-1">{summary?.faulted || 1}</p>
        </div>
        <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-3.5">
          <p className="text-[11px] font-semibold text-amber-400 uppercase">Active Power</p>
          <p className="text-xl font-bold text-amber-300 font-mono mt-1">
            {summary?.total_active_power_kw || 680} kW
          </p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row gap-3 rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search port number, hub station, vehicle, or connector..."
            className="w-full rounded-xl border border-slate-800 bg-slate-950/80 py-2 pl-10 pr-4 text-xs text-slate-200 placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 flex items-center gap-1">
              <Filter className="h-3 w-3" /> Hub:
            </span>
            <select
              value={stationFilter}
              onChange={(e) => setStationFilter(e.target.value)}
              className="rounded-xl border border-slate-800 bg-slate-950/80 py-2 px-3 text-xs text-slate-200 focus:border-cyan-500 focus:outline-none cursor-pointer"
            >
              <option value="ALL">All Hubs (10 Stations)</option>
              {stations.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="rounded-xl border border-slate-800 bg-slate-950/80 py-2 px-3 text-xs text-slate-200 focus:border-cyan-500 focus:outline-none cursor-pointer"
            >
              <option value="ALL">All Statuses</option>
              <option value="AVAILABLE">Available</option>
              <option value="BUSY">Busy / Charging</option>
              <option value="RESERVED">Reserved</option>
              <option value="FAULTED">Faulted</option>
            </select>
          </div>
        </div>
      </div>

      {/* Ports Grid */}
      {isLoading ? (
        <div className="py-16 text-center text-slate-400">
          <span className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-cyan-500 border-t-transparent mb-2" />
          <p className="text-xs">Loading charging ports from Supabase...</p>
        </div>
      ) : filteredPorts.length === 0 ? (
        <div className="rounded-2xl border border-slate-800 bg-slate-900/40 py-16 text-center text-slate-500">
          <Zap className="mx-auto h-8 w-8 text-slate-600 mb-2" />
          No charging ports match current filter.
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredPorts.map((port) => {
            const isBusy = (port.status === 'BUSY');

            return (
              <div
                key={port.id}
                onClick={() => setSelectedPort(port)}
                className="rounded-2xl border border-slate-800 bg-slate-900/80 p-4 shadow-lg hover:border-slate-700 transition-all cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-mono font-bold text-white text-sm">{port.port_number}</span>
                    <StatusBadge status={port.status} size="sm" />
                  </div>

                  <p className="text-xs text-slate-400 truncate mb-3">{port.station_name}</p>

                  <div className="flex items-center justify-between text-xs py-1.5 border-t border-slate-800/60">
                    <span className="text-slate-400">Connector:</span>
                    <span className="font-semibold text-slate-200">{port.connector_type}</span>
                  </div>

                  <div className="flex items-center justify-between text-xs py-1.5 border-t border-slate-800/60">
                    <span className="text-slate-400">Max Rating:</span>
                    <span className="font-mono text-slate-200">{port.max_power_kw} kW</span>
                  </div>

                  <div className="flex items-center justify-between text-xs py-1.5 border-t border-slate-800/60">
                    <span className="text-slate-400">Current Output:</span>
                    <span className={`font-mono font-bold ${isBusy ? 'text-amber-400' : 'text-slate-400'}`}>
                      {port.current_power_kw} kW
                    </span>
                  </div>

                  {isBusy && port.connected_vehicle_reg && (
                    <div className="mt-3 rounded-xl bg-slate-950/70 p-2.5 border border-slate-800/80">
                      <div className="flex items-center justify-between text-xs mb-1.5">
                        <span className="font-mono text-cyan-300 font-medium">
                          {port.connected_vehicle_reg}
                        </span>
                        <span className="text-[10px] text-slate-400">SOC</span>
                      </div>
                      <BatteryIndicator soc={port.vehicle_soc || 65} isCharging={true} size="sm" />
                    </div>
                  )}
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
                  <span>Click for Control</span>
                  <span className="text-cyan-400 font-medium hover:underline">Manage &rarr;</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* PORT INSPECTOR / CONTROL MODAL */}
      <Modal
        isOpen={!!selectedPort}
        onClose={() => setSelectedPort(null)}
        title={`Port Diagnostics: ${selectedPort?.port_number}`}
      >
        {selectedPort && (
          <div className="space-y-4">
            <div className="rounded-xl bg-slate-950 p-3 border border-slate-800 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Hub Station:</span>
                <span className="text-white font-medium">{selectedPort.station_name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Connector:</span>
                <span className="text-white">{selectedPort.connector_type}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Max Rating:</span>
                <span className="font-mono text-white">{selectedPort.max_power_kw} kW</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Live Power Delivery:</span>
                <span className="font-mono font-bold text-amber-400">{selectedPort.current_power_kw} kW</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Connected Asset:</span>
                <span className="font-mono text-cyan-300">{selectedPort.connected_vehicle_reg || 'None'}</span>
              </div>
            </div>

            <div className="pt-2">
              <p className="text-xs font-semibold text-slate-300 mb-2">Simulate Remote Command</p>
              {selectedPort.status === 'BUSY' ? (
                <button
                  onClick={() =>
                    togglePortMutation.mutate({
                      id: selectedPort.id,
                      newStatus: 'AVAILABLE',
                      currentPower: 0.0,
                    })
                  }
                  disabled={togglePortMutation.isPending}
                  className="w-full flex items-center justify-center gap-2 rounded-xl bg-rose-600 p-2.5 text-xs font-semibold text-white hover:bg-rose-500 disabled:opacity-50 cursor-pointer"
                >
                  <Square className="h-4 w-4" />
                  Terminate Session & Disconnect
                </button>
              ) : (
                <button
                  onClick={() =>
                    togglePortMutation.mutate({
                      id: selectedPort.id,
                      newStatus: 'BUSY',
                      currentPower: selectedPort.max_power_kw >= 250 ? 180.0 : 100.0,
                    })
                  }
                  disabled={togglePortMutation.isPending}
                  className="w-full flex items-center justify-center gap-2 rounded-xl bg-cyan-600 p-2.5 text-xs font-semibold text-white hover:bg-cyan-500 disabled:opacity-50 cursor-pointer"
                >
                  <Play className="h-4 w-4" />
                  Dispatch Fast Charging Session ({selectedPort.max_power_kw >= 250 ? '180 kW' : '100 kW'})
                </button>
              )}
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
