import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  MapPin,
  Zap,
  Calendar,
  Clock,
  Plus,
  Trash2,
  CheckCircle2,
  X,
  Database,
  Building2,
  Navigation
} from 'lucide-react';
import { api } from '../services/api';
import { ChargingStation, Booking } from '../types';
import { Modal } from '../components/Modal';
import { StatusBadge } from '../components/StatusBadge';

export function StationsPage() {
  const queryClient = useQueryClient();
  const [selectedStationForBooking, setSelectedStationForBooking] = useState<ChargingStation | null>(null);

  // New Booking Form
  const [bookingDate, setBookingDate] = useState('2026-10-09');
  const [bookingTime, setBookingTime] = useState('10:00');
  const [durationMinutes, setDurationMinutes] = useState(60);
  const [bookingNotes, setBookingNotes] = useState('Routine depot logistics recharge');

  // Query stations from Supabase
  const { data: stations = [], isLoading } = useQuery({
    queryKey: ['stations'],
    queryFn: () => api.getStations(),
  });

  // Query bookings from Supabase
  const { data: bookings = [], refetch: refetchBookings } = useQuery({
    queryKey: ['bookings'],
    queryFn: () => api.getBookings(),
  });

  // Create booking mutation
  const createBookingMutation = useMutation({
    mutationFn: (bData: any) => api.createBooking(bData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bookings'] });
      setSelectedStationForBooking(null);
    },
  });

  // Cancel booking mutation
  const cancelBookingMutation = useMutation({
    mutationFn: (id: string) => api.cancelBooking(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bookings'] });
    },
  });

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStationForBooking) return;

    // Pick first available port or port 1
    const port = selectedStationForBooking.ports?.[0];
    createBookingMutation.mutate({
      station_id: selectedStationForBooking.id,
      port_id: port ? port.id : 'd0000000-0000-0000-0000-000000000001',
      booking_date: bookingDate,
      start_time: bookingTime,
      duration_minutes: Number(durationMinutes),
      notes: bookingNotes,
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            Charging Hubs & Port Reservations
            <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-800/80 text-emerald-400 flex items-center gap-1">
              <Database className="h-3 w-3" />
              Supabase Tables: charging_stations & bookings
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time multi-depot terminal locations, bay availability, tariff rates, and automated fleet reservations.
          </p>
        </div>
      </div>

      {/* Stations Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {stations.map((st) => (
          <div
            key={st.id}
            className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 shadow-xl hover:border-slate-700 transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-cyan-400 font-mono">{st.code}</span>
                <StatusBadge status={st.status} size="sm" />
              </div>

              <h3 className="text-base font-bold text-white tracking-tight">{st.name}</h3>
              <p className="text-xs text-slate-400 flex items-center gap-1.5 mt-1">
                <MapPin className="h-3.5 w-3.5 text-slate-500 shrink-0" />
                {st.address}
              </p>

              <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
                <div className="rounded-xl bg-slate-950/80 p-2.5 border border-slate-800/80">
                  <span className="text-slate-500 text-[10px] block">Availability</span>
                  <span className="text-emerald-400 font-bold font-mono text-sm">
                    {st.available_ports} / {st.total_ports} Ports
                  </span>
                </div>
                <div className="rounded-xl bg-slate-950/80 p-2.5 border border-slate-800/80">
                  <span className="text-slate-500 text-[10px] block">Tariff Rate</span>
                  <span className="text-white font-bold font-mono text-sm">
                    ${st.price_per_kwh} / kWh
                  </span>
                </div>
              </div>

              <div className="mt-3 space-y-1.5 text-xs text-slate-400 pt-2 border-t border-slate-800/60">
                <div className="flex justify-between">
                  <span>Max Station Power:</span>
                  <span className="font-mono text-slate-200">{st.max_station_power_kw} kW</span>
                </div>
                <div className="flex justify-between">
                  <span>Connectors:</span>
                  <span className="text-slate-300 font-medium">{st.connector_types}</span>
                </div>
              </div>
            </div>

            <div className="mt-5 pt-3 border-t border-slate-800 flex items-center justify-between">
              <a
                href={`https://maps.google.com/?q=${st.latitude},${st.longitude}`}
                target="_blank"
                rel="noreferrer"
                className="text-xs text-slate-400 hover:text-white flex items-center gap-1"
              >
                <Navigation className="h-3 w-3 text-cyan-400" />
                Directions
              </a>
              <button
                onClick={() => setSelectedStationForBooking(st)}
                className="flex items-center gap-1.5 rounded-xl bg-cyan-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-cyan-500 transition-colors cursor-pointer"
              >
                <Calendar className="h-3.5 w-3.5" />
                Book Charging Bay
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Active Fleet Bookings Section */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <Calendar className="h-4 w-4 text-cyan-400" />
              Active Depot Port Bookings (Supabase: bookings)
            </h3>
            <p className="text-[11px] text-slate-400">
              Reserved charging bays for logistics routes and emergency turnarounds
            </p>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            {bookings.length} Registered Bookings
          </span>
        </div>

        <div className="overflow-x-auto rounded-xl border border-slate-800">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Booking Code</th>
                <th className="py-2.5 px-3">Hub Station</th>
                <th className="py-2.5 px-3">Port</th>
                <th className="py-2.5 px-3">Date & Time</th>
                <th className="py-2.5 px-3">Duration</th>
                <th className="py-2.5 px-3">Est. Cost</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {bookings.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-6 text-center text-slate-500">
                    No bookings recorded yet.
                  </td>
                </tr>
              ) : (
                bookings.map((b) => (
                  <tr key={b.id} className="hover:bg-slate-800/40">
                    <td className="py-2.5 px-3 font-mono font-bold text-cyan-400">
                      {b.booking_code}
                    </td>
                    <td className="py-2.5 px-3 font-medium text-white">{b.station_name}</td>
                    <td className="py-2.5 px-3 font-mono text-slate-300">{b.port_number}</td>
                    <td className="py-2.5 px-3 text-slate-300">
                      {b.booking_date} @ {b.start_time}
                    </td>
                    <td className="py-2.5 px-3 text-slate-400">{b.duration_minutes} min</td>
                    <td className="py-2.5 px-3 font-mono text-emerald-400">${b.estimated_cost}</td>
                    <td className="py-2.5 px-3">
                      <StatusBadge status={b.status} size="sm" />
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      {b.status === 'CONFIRMED' && (
                        <button
                          onClick={() => cancelBookingMutation.mutate(b.id)}
                          className="rounded-lg p-1 text-slate-400 hover:text-rose-400 hover:bg-rose-950/40 transition-colors cursor-pointer"
                          title="Cancel Booking"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* BOOKING MODAL */}
      <Modal
        isOpen={!!selectedStationForBooking}
        onClose={() => setSelectedStationForBooking(null)}
        title={`Reserve Bay at ${selectedStationForBooking?.name}`}
      >
        <form onSubmit={handleBookingSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Booking Date</label>
              <input
                type="date"
                required
                value={bookingDate}
                onChange={(e) => setBookingDate(e.target.value)}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Start Time</label>
              <input
                type="time"
                required
                value={bookingTime}
                onChange={(e) => setBookingTime(e.target.value)}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Duration (minutes)
            </label>
            <select
              value={durationMinutes}
              onChange={(e) => setDurationMinutes(Number(e.target.value))}
              className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
            >
              <option value={30}>30 Minutes ($10.50 est)</option>
              <option value={45}>45 Minutes ($15.75 est)</option>
              <option value={60}>60 Minutes ($21.00 est)</option>
              <option value={90}>90 Minutes ($31.50 est)</option>
              <option value={120}>120 Minutes ($42.00 est)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Dispatch Notes</label>
            <textarea
              rows={2}
              value={bookingNotes}
              onChange={(e) => setBookingNotes(e.target.value)}
              className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
            />
          </div>

          <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setSelectedStationForBooking(null)}
              className="rounded-xl border border-slate-800 bg-slate-900 px-4 py-2 text-xs text-slate-300 hover:bg-slate-800 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={createBookingMutation.isPending}
              className="rounded-xl bg-cyan-600 px-4 py-2 text-xs font-semibold text-white hover:bg-cyan-500 disabled:opacity-50 cursor-pointer"
            >
              {createBookingMutation.isPending ? 'Reserving...' : 'Confirm Reservation'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
