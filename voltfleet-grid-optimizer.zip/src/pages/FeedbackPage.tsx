import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  MessageSquare,
  Star,
  Plus,
  Filter,
  CheckCircle2,
  Database,
  ThumbsUp,
  Building2
} from 'lucide-react';
import { api } from '../services/api';
import { CustomerFeedback } from '../types';
import { Modal } from '../components/Modal';

export function FeedbackPage() {
  const queryClient = useQueryClient();
  const [categoryFilter, setCategoryFilter] = useState('ALL');
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState(false);

  // Form State
  const [stationId, setStationId] = useState('');
  const [customerName, setCustomerName] = useState('Commercial Fleet Driver');
  const [rating, setRating] = useState(5);
  const [category, setCategory] = useState('CHARGING_SPEED');
  const [comment, setComment] = useState('');

  // Query stations
  const { data: stations = [] } = useQuery({
    queryKey: ['stations'],
    queryFn: () => api.getStations(),
  });

  // Query feedback summary
  const { data: summary } = useQuery({
    queryKey: ['feedbackSummary'],
    queryFn: () => api.getFeedbackSummary(),
  });

  // Query feedback list
  const { data: feedbackList = [], isLoading, refetch } = useQuery({
    queryKey: ['feedbackList', categoryFilter],
    queryFn: () => api.getFeedback({ category: categoryFilter }),
  });

  // Mutation to submit feedback to Supabase
  const submitMutation = useMutation({
    mutationFn: (data: any) => api.submitFeedback(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['feedbackList'] });
      queryClient.invalidateQueries({ queryKey: ['feedbackSummary'] });
      setIsSubmitModalOpen(false);
      setComment('');
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitMutation.mutate({
      station_id: stationId || stations[0]?.id || 'a0000000-0000-0000-0000-000000000001',
      customer_name: customerName,
      rating: Number(rating),
      category,
      comment,
    });
  };

  const renderStars = (count: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${
          i < count ? 'fill-amber-400 text-amber-400' : 'text-slate-700'
        }`}
      />
    ));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            Customer & Driver Station Feedback
            <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-800/80 text-emerald-400 flex items-center gap-1">
              <Database className="h-3 w-3" />
              Supabase Table: customer_feedback
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Driver reviews, terminal charging experience, station reliability sentiment, and incident feedback.
          </p>
        </div>

        <button
          onClick={() => {
            if (stations.length > 0 && !stationId) setStationId(stations[0].id);
            setIsSubmitModalOpen(true);
          }}
          className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 px-4 py-2 text-xs font-semibold text-white shadow-lg shadow-cyan-500/20 hover:from-cyan-500 hover:to-blue-500 transition-all cursor-pointer"
        >
          <Plus className="h-4 w-4" />
          Submit Feedback
        </button>
      </div>

      {/* Summary KPI Cards & Rating Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Overall Rating Box */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 shadow-xl flex flex-col justify-center items-center text-center">
          <span className="text-xs font-semibold text-slate-400 uppercase">Average Hub Rating</span>
          <div className="flex items-center gap-2 mt-2">
            <span className="text-4xl font-extrabold text-white font-mono">
              {summary?.average_rating || 4.8}
            </span>
            <span className="text-slate-500 text-lg">/ 5.0</span>
          </div>
          <div className="flex items-center gap-1 mt-2">
            {renderStars(Math.round(summary?.average_rating || 5))}
          </div>
          <span className="text-xs text-slate-400 mt-2">
            Based on {summary?.total_reviews || 4} verified driver reviews
          </span>
        </div>

        {/* Breakdown by Category */}
        <div className="md:col-span-2 rounded-2xl border border-slate-800 bg-slate-900/80 p-5 shadow-xl space-y-2">
          <span className="text-xs font-semibold text-slate-300 uppercase block mb-3">
            Satisfaction Distribution (Supabase Realtime)
          </span>
          {[5, 4, 3, 2, 1].map((stars) => {
            const count = summary?.rating_distribution?.[stars] || (stars >= 4 ? (stars === 5 ? 3 : 1) : 0);
            const total = summary?.total_reviews || 4;
            const pct = Math.round((count / total) * 100);

            return (
              <div key={stars} className="flex items-center gap-3 text-xs">
                <div className="flex items-center gap-1 w-14">
                  <span className="font-mono text-slate-300">{stars}</span>
                  <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
                </div>
                <div className="flex-1 h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-amber-400 rounded-full transition-all duration-500"
                    style={{ width: `${pct}%` }}
                  />
                </div>
                <span className="w-10 text-right font-mono text-slate-400">{count}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Filter Bar */}
      <div className="flex items-center gap-3 rounded-2xl border border-slate-800 bg-slate-900/60 p-4 text-xs">
        <Filter className="h-4 w-4 text-slate-400" />
        <span className="text-slate-300 font-medium">Filter Category:</span>
        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          className="rounded-xl border border-slate-800 bg-slate-950/80 py-1.5 px-3 text-xs text-slate-200 focus:border-cyan-500 focus:outline-none cursor-pointer"
        >
          <option value="ALL">All Categories</option>
          <option value="CHARGING_SPEED">Charging Speed</option>
          <option value="AVAILABILITY">Bay Availability</option>
          <option value="APP_EXPERIENCE">App Experience</option>
          <option value="PAYMENT">Automated Billing</option>
          <option value="HARDWARE">Charger Hardware</option>
          <option value="CUSTOMER_SERVICE">Customer Support</option>
        </select>
      </div>

      {/* Feedback Feed */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {feedbackList.map((item) => (
          <div
            key={item.id}
            className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 shadow-lg flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1">{renderStars(item.rating)}</div>
                <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full bg-slate-800 text-cyan-400">
                  {item.category.replace(/_/g, ' ')}
                </span>
              </div>

              <p className="text-xs text-slate-200 font-medium my-2">"{item.comment}"</p>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
              <div>
                <span className="font-medium text-slate-300">{item.customer_name}</span>
                <span className="block text-[10px] text-slate-500">{item.station_name}</span>
              </div>
              <span className="text-slate-500">
                {new Date(item.created_at).toLocaleDateString()}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* SUBMIT FEEDBACK MODAL */}
      <Modal
        isOpen={isSubmitModalOpen}
        onClose={() => setIsSubmitModalOpen(false)}
        title="Submit Charging Feedback"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Hub Station</label>
            <select
              value={stationId}
              onChange={(e) => setStationId(e.target.value)}
              className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
            >
              {stations.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.code})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Your Name / Role</label>
            <input
              type="text"
              required
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Star Rating (1-5)</label>
              <select
                value={rating}
                onChange={(e) => setRating(Number(e.target.value))}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
              >
                <option value={5}>⭐⭐⭐⭐⭐ (5 - Flawless)</option>
                <option value={4}>⭐⭐⭐⭐ (4 - Very Good)</option>
                <option value={3}>⭐⭐⭐ (3 - Acceptable)</option>
                <option value={2}>⭐⭐ (2 - Subpar)</option>
                <option value={1}>⭐ (1 - Faulted)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Topic Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
              >
                <option value="CHARGING_SPEED">CHARGING_SPEED</option>
                <option value="AVAILABILITY">AVAILABILITY</option>
                <option value="APP_EXPERIENCE">APP_EXPERIENCE</option>
                <option value="PAYMENT">PAYMENT</option>
                <option value="LOCATION">LOCATION</option>
                <option value="HARDWARE">HARDWARE</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Feedback Comments</label>
            <textarea
              required
              rows={3}
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Describe charging speed, bay condition, or app experience..."
              className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
            />
          </div>

          <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsSubmitModalOpen(false)}
              className="rounded-xl border border-slate-800 bg-slate-900 px-4 py-2 text-xs text-slate-300 hover:bg-slate-800 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitMutation.isPending}
              className="rounded-xl bg-cyan-600 px-4 py-2 text-xs font-semibold text-white hover:bg-cyan-500 disabled:opacity-50 cursor-pointer"
            >
              {submitMutation.isPending ? 'Publishing...' : 'Publish Feedback'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
