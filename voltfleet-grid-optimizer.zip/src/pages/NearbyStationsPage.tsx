import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'motion/react';
import {
  MapPin,
  Navigation,
  Calendar,
  Clock,
  Zap,
  DollarSign,
  CheckCircle2,
  List,
  Map,
  X,
  Plus,
  Trash2,
  ExternalLink
} from 'lucide-react';
import { api } from '../services/api';
import { ChargingStation, Booking } from '../types';
import { StatusBadge } from '../components/StatusBadge';
import { Modal } from '../components/Modal';

export function NearbyStationsPage() {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState<'stations' | 'bookings'>('stations');
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');

  // Selected station for view details modal
  const [detailsStation, setDetailsStation] = useState<ChargingStation | null>(null);

  // Pre-book modal state
  const [bookingStation, setBookingStation] = useState<ChargingStation | null>(null);
  const [selectedPortId, setSelectedPortId] = useState('');
  const [bookingDate, setBookingDate] = useState(
    new Date(Date.now() + 86400000).toISOString().split('T')[0]
  );
  const [bookingTime, setBookingTime] = useState('10:00');
  const [durationMinutes, setDurationMinutes] = useState(60);
  const [bookingNotes, setBookingNotes] = useState('Priority depot fast-charge');

  // Queries
  const { data: stations, isLoading: loadingStations } = useQuery({
    queryKey: ['stations'],
    queryFn: () => api.getStations(),
  });

  const { data: bookings, refetch: refetchBookings } = useQuery({
    queryKey: ['bookings'],
    queryFn: () => api.getBookings(),
  });

  // Create booking mutation
  const bookingMutation = useMutation({
    mutationFn: (payload: any) => api.createBooking(payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bookings'] });
      setBookingStation(null);
      setActiveTab('bookings');
      alert('Booking confirmed successfully!');
    },
    onError: (err: any) => {
      alert(`Booking failed: ${err.message}`);
    },
  });

  // Cancel booking mutation
  const cancelBookingMutation = useMutation({
    mutationFn: (id: string) => api.cancelBooking(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bookings'] });
    },
  });

  const handleOpenBooking = (station: ChargingStation) => {
    setBookingStation(station);
    if (station.ports && station.ports.length > 0) {
      setSelectedPortId(station.ports[0].id);
    }
  };

  const handleConfirmBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bookingStation || !selectedPortId) return;

    bookingMutation.mutate({
      station_id: bookingStation.id,
      port_id: selectedPortId,
      booking_date: bookingDate,
      start_time: bookingTime,
      duration_minutes: durationMinutes,
      notes: bookingNotes,
    });
  };

  const handleNavigate = (station: ChargingStation) => {
    // Open Google Maps URL as required
    const url = `https://www.google.com/maps/search/?api=1&query=${station.latitude},${station.longitude}`;
    window.open(url, '_blank');
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            Regional Charging Hubs & Pre-Booking
            <span className="text-xs font-mono font-medium px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
              {stations?.length || 0} Connected Hubs
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Locate high-power transit superhubs, check live stall availability, and reserve time-slots.
          </p>
        </div>

        {/* Tab switch */}
        <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 p-1 rounded-xl text-xs">
          <button
            onClick={() => setActiveTab('stations')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              activeTab === 'stations' ? 'bg-cyan-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            All Stations
          </button>
          <button
            onClick={() => setActiveTab('bookings')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              activeTab === 'bookings' ? 'bg-cyan-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            Active Bookings ({bookings?.length || 0})
          </button>
        </div>
      </div>

      {activeTab === 'stations' ? (
        <>
          {/* Controls: List vs Map toggle */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 p-1 rounded-xl text-xs">
              <button
                onClick={() => setViewMode('list')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium ${
                  viewMode === 'list' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                <List className="h-3.5 w-3.5" />
                List View
              </button>
              <button
                onClick={() => setViewMode('map')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium ${
                  viewMode === 'map' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Map className="h-3.5 w-3.5" />
                Interactive Map View
              </button>
            </div>
          </div>

          {/* Map View */}
          {viewMode === 'map' && (
            <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 backdrop-blur-md">
              <div className="flex items-center justify-between mb-3 text-xs text-slate-400">
                <span>San Francisco Bay Area Superhub Geolocation Network</span>
                <span className="font-mono text-cyan-400">Central Depot: 37.7749° N, -122.4194° W</span>
              </div>
              <div className="relative h-96 w-full rounded-xl bg-slate-950 border border-slate-800 overflow-hidden flex items-center justify-center">
                {/* Visual Map Grid */}
                <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px] opacity-40" />
                <div className="relative z-10 w-full h-full p-8 flex flex-wrap items-center justify-center gap-6">
                  {stations?.map((st, i) => (
                    <motion.div
                      key={st.id}
                      whileHover={{ scale: 1.05 }}
                      onClick={() => handleOpenBooking(st)}
                      className="cursor-pointer rounded-xl border border-cyan-500/40 bg-slate-900/90 p-3 shadow-xl backdrop-blur-md flex flex-col items-center gap-1 min-w-[140px]"
                    >
                      <MapPin className="h-6 w-6 text-cyan-400" />
                      <span className="font-bold text-xs text-white text-center truncate max-w-[130px]">{st.name}</span>
                      <span className="text-[10px] text-emerald-400 font-mono font-semibold">
                        {st.available_ports} / {st.total_ports} Available
                      </span>
                      <span className="text-[10px] text-slate-400">${st.price_per_kwh}/kWh</span>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* List View */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
            {stations?.map((station) => (
              <motion.div
                key={station.id}
                whileHover={{ y: -2 }}
                className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-lg backdrop-blur-md flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-base font-bold text-white tracking-tight">{station.name}</h3>
                      <p className="text-xs text-slate-400 mt-0.5">{station.address}</p>
                    </div>
                    <StatusBadge status={station.status} size="sm" />
                  </div>

                  {/* Quick specs */}
                  <div className="mt-4 grid grid-cols-2 gap-2 rounded-xl bg-slate-950/80 p-3 text-xs font-mono">
                    <div>
                      <span className="text-[10px] text-slate-500 font-sans">AVAILABLE PORTS</span>
                      <p className="font-bold text-emerald-400">
                        {station.available_ports} of {station.total_ports} Free
                      </p>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 font-sans">MAX CHARGE SPEED</span>
                      <p className="font-bold text-cyan-400">{station.max_station_power_kw} kW</p>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 font-sans">ELECTRICITY TARIFF</span>
                      <p className="font-bold text-slate-200">${station.price_per_kwh} / kWh</p>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 font-sans">CONNECTORS</span>
                      <p className="text-[11px] text-slate-300 font-sans truncate">{station.connector_types}</p>
                    </div>
                  </div>
                </div>

                {/* Actions: VIEW DETAILS, NAVIGATE, PRE-BOOK */}
                <div className="mt-5 grid grid-cols-3 gap-2 pt-3 border-t border-slate-800 text-xs">
                  <button
                    onClick={() => setDetailsStation(station)}
                    className="rounded-xl border border-slate-800 bg-slate-950/80 py-2 font-medium text-slate-300 hover:bg-slate-800 hover:text-white transition-colors cursor-pointer"
                  >
                    VIEW DETAILS
                  </button>
                  <button
                    onClick={() => handleNavigate(station)}
                    className="flex items-center justify-center gap-1 rounded-xl border border-slate-800 bg-slate-950/80 py-2 font-medium text-cyan-400 hover:bg-slate-800 transition-colors cursor-pointer"
                  >
                    <Navigation className="h-3.5 w-3.5" />
                    <span>NAVIGATE</span>
                  </button>
                  <button
                    onClick={() => handleOpenBooking(station)}
                    className="flex items-center justify-center gap-1 rounded-xl bg-cyan-600 py-2 font-semibold text-white hover:bg-cyan-500 shadow-md shadow-cyan-600/20 transition-all cursor-pointer"
                  >
                    <Calendar className="h-3.5 w-3.5" />
                    <span>PRE-BOOK</span>
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </>
      ) : (
        /* BOOKINGS MANAGEMENT VIEW */
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 backdrop-blur-md">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-base font-bold text-white">Active Pre-Booked Charging Reservations</h2>
              <p className="text-xs text-slate-400">Guaranteed bay allocation for fleet delivery vehicles</p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-slate-800 text-slate-400 font-semibold uppercase">
                <tr>
                  <th className="pb-3 px-3">Booking Code</th>
                  <th className="pb-3 px-3">Charging Station</th>
                  <th className="pb-3 px-3">Reserved Port</th>
                  <th className="pb-3 px-3">Date & Time</th>
                  <th className="pb-3 px-3">Duration</th>
                  <th className="pb-3 px-3">Est. Cost</th>
                  <th className="pb-3 px-3">Status</th>
                  <th className="pb-3 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {bookings?.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-12 text-center text-slate-500 font-sans">
                      No active bookings found. Select a charging station to reserve a slot.
                    </td>
                  </tr>
                ) : (
                  bookings?.map((bk) => (
                    <tr key={bk.id} className="hover:bg-slate-800/30">
                      <td className="py-3 px-3 font-bold text-cyan-400">{bk.booking_code}</td>
                      <td className="py-3 px-3 font-sans font-medium text-slate-200">{bk.station_name}</td>
                      <td className="py-3 px-3 text-slate-300">{bk.port_number}</td>
                      <td className="py-3 px-3 text-slate-200">
                        {bk.booking_date} at {bk.start_time}
                      </td>
                      <td className="py-3 px-3 text-slate-400">{bk.duration_minutes} mins</td>
                      <td className="py-3 px-3 text-emerald-400">${bk.estimated_cost?.toFixed(2)}</td>
                      <td className="py-3 px-3 font-sans">
                        <StatusBadge status={bk.status} size="sm" />
                      </td>
                      <td className="py-3 px-3 text-right font-sans">
                        {bk.status === 'CONFIRMED' && (
                          <button
                            onClick={() => cancelBookingMutation.mutate(bk.id)}
                            className="rounded-lg bg-rose-950/60 border border-rose-800/80 px-2.5 py-1 text-xs text-rose-300 hover:bg-rose-900 transition-colors cursor-pointer"
                          >
                            Cancel
                          </button>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* VIEW DETAILS MODAL */}
      <Modal
        isOpen={!!detailsStation}
        onClose={() => setDetailsStation(null)}
        title={detailsStation?.name || 'Station Details'}
      >
        {detailsStation && (
          <div className="space-y-4 text-xs font-mono">
            <div className="rounded-xl border border-slate-800 bg-slate-950 p-4">
              <span className="text-[10px] uppercase tracking-wider text-slate-500 font-sans font-semibold">
                Hub Infrastructure Specs
              </span>
              <div className="mt-3 grid grid-cols-2 gap-3 text-slate-300">
                <div>
                  <span className="text-slate-500 text-[10px]">ADDRESS</span>
                  <p className="font-sans font-medium">{detailsStation.address}</p>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px]">MAX POWER</span>
                  <p className="font-bold text-cyan-400">{detailsStation.max_station_power_kw} kW</p>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px]">GRID CAPACITY</span>
                  <p className="font-bold">{detailsStation.grid_capacity_kw} kW</p>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px]">CURRENT LOAD</span>
                  <p className="font-bold text-amber-400">{detailsStation.current_load_kw} kW</p>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => handleNavigate(detailsStation)}
                className="flex items-center gap-1.5 rounded-xl border border-slate-800 px-4 py-2 text-slate-300 hover:bg-slate-800"
              >
                <Navigation className="h-3.5 w-3.5 text-cyan-400" />
                <span>Open in Google Maps</span>
              </button>
              <button
                onClick={() => {
                  const st = detailsStation;
                  setDetailsStation(null);
                  handleOpenBooking(st);
                }}
                className="rounded-xl bg-cyan-600 px-4 py-2 font-semibold text-white hover:bg-cyan-500"
              >
                Proceed to Pre-Book
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* PRE-BOOK WORKFLOW MODAL */}
      <Modal
        isOpen={!!bookingStation}
        onClose={() => setBookingStation(null)}
        title={`Pre-Book Stall at ${bookingStation?.name}`}
      >
        <form onSubmit={handleConfirmBooking} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 mb-1">1. Select Charging Stall / Port</label>
            <select
              value={selectedPortId}
              onChange={(e) => setSelectedPortId(e.target.value)}
              className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2 text-slate-200 focus:border-cyan-500 focus:outline-none"
              required
            >
              {bookingStation?.ports?.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.port_number} ({p.connector_type} - {p.max_power_kw} kW) - Status: {p.status}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 mb-1">2. Reservation Date</label>
              <input
                type="date"
                value={bookingDate}
                onChange={(e) => setBookingDate(e.target.value)}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2 text-slate-200 focus:border-cyan-500 focus:outline-none"
                required
              />
            </div>
            <div>
              <label className="block text-slate-300 mb-1">3. Start Time</label>
              <input
                type="time"
                value={bookingTime}
                onChange={(e) => setBookingTime(e.target.value)}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2 text-slate-200 focus:border-cyan-500 focus:outline-none"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-300 mb-1">4. Expected Session Duration</label>
            <select
              value={durationMinutes}
              onChange={(e) => setDurationMinutes(parseInt(e.target.value))}
              className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2 text-slate-200 focus:border-cyan-500 focus:outline-none"
            >
              <option value={30}>30 Minutes (Quick Top-Up)</option>
              <option value={45}>45 Minutes (Standard Turnaround)</option>
              <option value={60}>60 Minutes (Full Heavy Recharge)</option>
              <option value={90}>90 Minutes (Overnight / Depot Rest)</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-300 mb-1">5. Route / Mission Notes</label>
            <input
              type="text"
              value={bookingNotes}
              onChange={(e) => setBookingNotes(e.target.value)}
              placeholder="e.g. Amazon Hub delivery run"
              className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2 text-slate-200 focus:border-cyan-500 focus:outline-none"
            />
          </div>

          <div className="rounded-xl bg-slate-950 border border-slate-800 p-3 flex justify-between items-center font-mono">
            <div>
              <span className="text-[10px] text-slate-500 font-sans">ESTIMATED RESERVATION COST</span>
              <p className="text-emerald-400 font-bold text-sm">
                ${((durationMinutes / 60) * 45 * (bookingStation?.price_per_kwh || 0.28)).toFixed(2)} USD
              </p>
            </div>
            <span className="text-[10px] text-cyan-400 font-sans">Guaranteed Bay Lock</span>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={() => setBookingStation(null)}
              className="rounded-xl border border-slate-800 px-4 py-2 text-slate-400 hover:bg-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={bookingMutation.isPending}
              className="rounded-xl bg-cyan-600 px-4 py-2 font-semibold text-white hover:bg-cyan-500 disabled:opacity-50"
            >
              {bookingMutation.isPending ? 'Confirming Lock...' : 'Confirm Pre-Booking'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
