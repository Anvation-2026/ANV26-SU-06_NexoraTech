import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Gauge,
  Zap,
  Sun,
  Activity,
  AlertTriangle,
  CheckCircle2,
  TrendingDown,
  TrendingUp,
  Cpu,
  RefreshCw
} from 'lucide-react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend
} from 'recharts';
import { api } from '../services/api';
import { useLiveTelemetry } from '../hooks/useLiveTelemetry';
import { StatusBadge } from '../components/StatusBadge';

export function GridMonitorPage() {
  const queryClient = useQueryClient();
  const { liveGridData } = useLiveTelemetry();

  const { data: currentGrid, refetch: refetchCurrent } = useQuery({
    queryKey: ['gridCurrent'],
    queryFn: () => api.getGridCurrent(),
    refetchInterval: 5000,
  });

  const { data: gridHistory } = useQuery({
    queryKey: ['gridHistory'],
    queryFn: () => api.getGridHistory(),
    refetchInterval: 15000,
  });

  const { data: alerts, refetch: refetchAlerts } = useQuery({
    queryKey: ['gridAlerts'],
    queryFn: () => api.getGridAlerts(),
    refetchInterval: 10000,
  });

  const resolveAlertMutation = useMutation({
    mutationFn: (alertId: string) => api.resolveAlert(alertId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['gridAlerts'] });
    },
  });

  const active = liveGridData || currentGrid;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            Electrical Grid Monitor & Demand Response
            <span className="text-xs font-mono font-medium px-2 py-0.5 rounded-full bg-cyan-950 border border-cyan-800 text-cyan-400">
              5,000 kW Substation Interconnect
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time multi-transformer load balancing, peak shaving analytics, and renewable generation.
          </p>
        </div>
        <button
          onClick={() => {
            refetchCurrent();
            refetchAlerts();
          }}
          className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-xs font-semibold text-slate-300 hover:bg-slate-800 hover:text-white"
        >
          <RefreshCw className="h-3.5 w-3.5 text-cyan-400" />
          Refresh Metrics
        </button>
      </div>

      {/* 10 KEY GRID METRIC DIALS */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5 font-mono">
        <div className="rounded-xl border border-slate-800 bg-slate-900/90 p-4">
          <span className="text-[10px] uppercase tracking-wider text-slate-400 font-sans">Total Grid Capacity</span>
          <p className="mt-1 text-2xl font-bold text-white">{active?.total_capacity_kw || 5000} kW</p>
        </div>

        <div className="rounded-xl border border-rose-500/30 bg-slate-900/90 p-4">
          <span className="text-[10px] uppercase tracking-wider text-rose-400 font-sans">Current Grid Load</span>
          <p className="mt-1 text-2xl font-bold text-rose-400">{active?.current_grid_load_kw || 2450} kW</p>
        </div>

        <div className="rounded-xl border border-cyan-500/30 bg-slate-900/90 p-4">
          <span className="text-[10px] uppercase tracking-wider text-cyan-400 font-sans">EV Charging Load</span>
          <p className="mt-1 text-2xl font-bold text-cyan-400">{active?.charging_load_kw || 680} kW</p>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/90 p-4">
          <span className="text-[10px] uppercase tracking-wider text-slate-400 font-sans">Depot Base Load</span>
          <p className="mt-1 text-2xl font-bold text-slate-200">{active?.base_load_kw || 1770} kW</p>
        </div>

        <div className="rounded-xl border border-emerald-500/30 bg-slate-900/90 p-4">
          <span className="text-[10px] uppercase tracking-wider text-emerald-400 font-sans">Solar & Renewables</span>
          <p className="mt-1 text-2xl font-bold text-emerald-400">{active?.renewable_energy_kw || 950} kW</p>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/90 p-4">
          <span className="text-[10px] uppercase tracking-wider text-slate-400 font-sans">Peak Historical Demand</span>
          <p className="mt-1 text-xl font-bold text-amber-400">{active?.peak_demand_kw || 3250} kW</p>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/90 p-4">
          <span className="text-[10px] uppercase tracking-wider text-slate-400 font-sans">Bus AC Voltage</span>
          <p className="mt-1 text-xl font-bold text-slate-200">{active?.voltage_v || 400.2} V</p>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/90 p-4">
          <span className="text-[10px] uppercase tracking-wider text-slate-400 font-sans">Frequency</span>
          <p className="mt-1 text-xl font-bold text-slate-200">{active?.frequency_hz || 50.01} Hz</p>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/90 p-4">
          <span className="text-[10px] uppercase tracking-wider text-slate-400 font-sans">Power Factor</span>
          <p className="mt-1 text-xl font-bold text-emerald-400">{active?.power_factor || 0.98}</p>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/90 p-4">
          <span className="text-[10px] uppercase tracking-wider text-slate-400 font-sans">Capacity Utilization</span>
          <p className="mt-1 text-xl font-bold text-cyan-400">{active?.capacity_utilization_pct || 49.0}%</p>
        </div>
      </div>

      {/* CHARTS */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Chart 1: Grid Load History (Base vs Charging) */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 backdrop-blur-md">
          <h3 className="text-sm font-semibold text-white mb-1">
            24-Hour Grid Load Superposition (Base Load vs EV Fleet Charging)
          </h3>
          <p className="text-xs text-slate-500 mb-4">Total substation load profile in kilowatts (kW)</p>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={gridHistory}>
                <defs>
                  <linearGradient id="baseGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#64748b" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#64748b" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="chgGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.6}/>
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.1}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="hour_label" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={10} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }} />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Area type="monotone" dataKey="base_load_kw" name="Base Depot Load (kW)" stroke="#64748b" fill="url(#baseGrad)" />
                <Area type="monotone" dataKey="charging_load_kw" name="EV Charging Draw (kW)" stroke="#06b6d4" fill="url(#chgGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Renewable Generation vs Total Load */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 backdrop-blur-md">
          <h3 className="text-sm font-semibold text-white mb-1">
            Renewable Generation vs Total Demand
          </h3>
          <p className="text-xs text-slate-500 mb-4">Solar PV & Battery Storage offset</p>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={gridHistory}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="hour_label" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={10} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }} />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Line type="monotone" dataKey="grid_load_kw" name="Total Grid Demand (kW)" stroke="#f43f5e" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="renewable_kw" name="Solar PV Gen (kW)" stroke="#10b981" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* GRID ALERTS TABLE */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 backdrop-blur-md">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-semibold text-white">Substation Alerts & Safety Thresholds</h3>
            <p className="text-xs text-slate-400">Automated protective relay notifications and power limits</p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-800 text-slate-400 font-semibold uppercase">
              <tr>
                <th className="pb-3 px-3">Severity</th>
                <th className="pb-3 px-3">Alert Type</th>
                <th className="pb-3 px-3">Description</th>
                <th className="pb-3 px-3">Status</th>
                <th className="pb-3 px-3">Timestamp</th>
                <th className="pb-3 px-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {alerts?.map((alert) => (
                <tr key={alert.id} className="hover:bg-slate-800/30">
                  <td className="py-3 px-3 font-sans">
                    <StatusBadge status={alert.severity} size="sm" />
                  </td>
                  <td className="py-3 px-3 font-bold text-slate-200">{alert.alert_type}</td>
                  <td className="py-3 px-3 text-slate-300 font-sans max-w-md">
                    <div className="font-semibold text-slate-100">{alert.title}</div>
                    <div className="text-[11px] text-slate-400">{alert.message}</div>
                  </td>
                  <td className="py-3 px-3 font-sans">
                    <StatusBadge status={alert.status} size="sm" />
                  </td>
                  <td className="py-3 px-3 text-slate-400 text-[11px]">
                    {new Date(alert.created_at).toLocaleTimeString()}
                  </td>
                  <td className="py-3 px-3 text-right font-sans">
                    {alert.status === 'ACTIVE' ? (
                      <button
                        onClick={() => resolveAlertMutation.mutate(alert.id)}
                        disabled={resolveAlertMutation.isPending}
                        className="rounded-lg bg-emerald-950/80 border border-emerald-800 px-3 py-1 text-xs font-semibold text-emerald-400 hover:bg-emerald-900 transition-colors cursor-pointer"
                      >
                        Acknowledge / Resolve
                      </button>
                    ) : (
                      <span className="text-xs text-slate-500 italic">Resolved</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
