import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  FileText,
  Download,
  Plus,
  Eye,
  Calendar,
  CheckCircle2,
  Database,
  BarChart2,
  Printer,
  Sparkles
} from 'lucide-react';
import { api } from '../services/api';
import { ReportItem } from '../types';
import { Modal } from '../components/Modal';

export function ReportsPage() {
  const queryClient = useQueryClient();
  const [isGenerateOpen, setIsGenerateOpen] = useState(false);
  const [viewingReport, setViewingReport] = useState<ReportItem | null>(null);

  // Form State
  const [reportType, setReportType] = useState('Executive Summary');
  const [startDate, setStartDate] = useState('2026-10-01');
  const [endDate, setEndDate] = useState('2026-10-08');

  // Query reports from Supabase
  const { data: reports = [], isLoading, refetch } = useQuery({
    queryKey: ['reports'],
    queryFn: () => api.getReports(),
  });

  // Mutation to generate and save report to Supabase
  const generateMutation = useMutation({
    mutationFn: (data: any) => api.generateReport(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reports'] });
      setIsGenerateOpen(false);
    },
  });

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    generateMutation.mutate({
      report_type: reportType,
      start_date: startDate,
      end_date: endDate,
    });
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            Operational Audit & PDF Reports
            <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-800/80 text-emerald-400 flex items-center gap-1">
              <Database className="h-3 w-3" />
              Supabase Table: reports
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Generate and export automated fleet energy consumption, TOU financial audits, and grid peak demand reports.
          </p>
        </div>

        <button
          onClick={() => setIsGenerateOpen(true)}
          className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 px-4 py-2 text-xs font-semibold text-white shadow-lg shadow-cyan-500/20 hover:from-cyan-500 hover:to-blue-500 transition-all cursor-pointer"
        >
          <Plus className="h-4 w-4" />
          Generate New Audit Report
        </button>
      </div>

      {/* Reports Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Report Title</th>
                <th className="py-3 px-4">Audit Category</th>
                <th className="py-3 px-4">Audit Period</th>
                <th className="py-3 px-4">Generated Timestamp</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {isLoading ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400">
                    Loading reports from Supabase...
                  </td>
                </tr>
              ) : reports.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500">
                    No reports generated yet. Click "Generate New Audit Report" above.
                  </td>
                </tr>
              ) : (
                reports.map((rep) => (
                  <tr key={rep.id} className="hover:bg-slate-800/40">
                    <td className="py-3 px-4">
                      <div className="font-semibold text-white">{rep.title}</div>
                      <div className="text-[10px] text-slate-500 font-mono">ID: {rep.id}</div>
                    </td>
                    <td className="py-3 px-4 text-cyan-300 font-medium">{rep.report_type}</td>
                    <td className="py-3 px-4 text-slate-300 font-mono">
                      {rep.start_date} &rarr; {rep.end_date}
                    </td>
                    <td className="py-3 px-4 text-slate-400">
                      {new Date(rep.created_at).toLocaleString()}
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-950 text-emerald-400 border border-emerald-800">
                        {rep.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => setViewingReport(rep)}
                          className="flex items-center gap-1 rounded-lg bg-slate-800 px-2.5 py-1 text-slate-200 hover:bg-slate-700 hover:text-white transition-colors cursor-pointer"
                        >
                          <Eye className="h-3.5 w-3.5 text-cyan-400" />
                          View
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* GENERATE REPORT MODAL */}
      <Modal
        isOpen={isGenerateOpen}
        onClose={() => setIsGenerateOpen(false)}
        title="Generate Operational Audit Report"
      >
        <form onSubmit={handleGenerate} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Audit Template Category
            </label>
            <select
              value={reportType}
              onChange={(e) => setReportType(e.target.value)}
              className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
            >
              <option value="Executive Summary">Executive Operational Summary</option>
              <option value="Grid Impact & Load Factor">Grid Substation Load & Peak Shaving</option>
              <option value="Fleet Energy Efficiency">Fleet Asset Energy Delivered (kWh)</option>
              <option value="TOU Cost Optimization">SciPy Dispatch & TOU Tariff Savings</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Start Date</label>
              <input
                type="date"
                required
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">End Date</label>
              <input
                type="date"
                required
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
              />
            </div>
          </div>

          <div className="rounded-xl bg-slate-950 p-3 border border-slate-800 text-[11px] text-slate-400 space-y-1">
            <p className="font-semibold text-slate-300">Generated Report Will Include:</p>
            <p>• Fleet energy throughput and total kilowatt-hours delivered</p>
            <p>• Substation peak demand curves and transformer utilization</p>
            <p>• Mathematical optimization savings calculation against TOU tariffs</p>
          </div>

          <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsGenerateOpen(false)}
              className="rounded-xl border border-slate-800 bg-slate-900 px-4 py-2 text-xs text-slate-300 hover:bg-slate-800 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={generateMutation.isPending}
              className="flex items-center gap-1.5 rounded-xl bg-cyan-600 px-4 py-2 text-xs font-semibold text-white hover:bg-cyan-500 disabled:opacity-50 cursor-pointer"
            >
              {generateMutation.isPending ? 'Generating...' : 'Generate & Save to Supabase'}
            </button>
          </div>
        </form>
      </Modal>

      {/* VIEW REPORT AUDIT MODAL */}
      <Modal
        isOpen={!!viewingReport}
        onClose={() => setViewingReport(null)}
        title={viewingReport?.title || 'Operational Audit Report'}
        maxWidth="max-w-2xl"
      >
        {viewingReport && (
          <div className="space-y-5 print:text-black">
            {/* Header info */}
            <div className="border-b border-slate-800 pb-3 flex justify-between items-start">
              <div>
                <p className="text-xs text-cyan-400 font-mono font-semibold">
                  AUDIT PERIOD: {viewingReport.start_date} TO {viewingReport.end_date}
                </p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Generated by GridVolt Enterprise Supabase Data Engine
                </p>
              </div>
              <button
                onClick={handlePrint}
                className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800 px-3 py-1.5 text-xs text-white hover:bg-slate-700 transition-colors cursor-pointer"
              >
                <Printer className="h-3.5 w-3.5" />
                Print / Save PDF
              </button>
            </div>

            {/* KPI grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {Object.entries(viewingReport.summary_kpis || {}).map(([key, val]) => (
                <div key={key} className="rounded-xl bg-slate-950 p-3 border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">{key}</span>
                  <span className="text-base font-bold text-white font-mono mt-1 block">{String(val)}</span>
                </div>
              ))}
            </div>

            {/* Executive narrative */}
            <div className="rounded-xl bg-slate-950/80 p-4 border border-slate-800 text-xs text-slate-300 space-y-2">
              <h4 className="font-semibold text-white text-sm">Audit Findings & Compliance</h4>
              <p>
                1. <strong>Energy Dispatch:</strong> High speed DC fast charging terminals maintained an overall system uptime of 98.7% across 10 metropolitan superhub depots.
              </p>
              <p>
                2. <strong>Grid Peak Mitigation:</strong> SciPy schedule optimization successfully prevented substation capacity threshold breeches during the 16:00 - 21:00 peak pricing interval.
              </p>
              <p>
                3. <strong>Cost Reduction:</strong> Off-peak energy shifting saved $1,680.40 (19.4% net reduction in commercial utility charges).
              </p>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setViewingReport(null)}
                className="rounded-xl border border-slate-800 bg-slate-900 px-4 py-2 text-xs text-slate-300 hover:bg-slate-800 cursor-pointer"
              >
                Close Audit
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
