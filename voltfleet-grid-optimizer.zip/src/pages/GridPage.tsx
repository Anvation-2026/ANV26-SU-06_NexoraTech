import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Gauge,
  Zap,
  Sun,
  Activity,
  AlertTriangle,
  CheckCircle2,
  TrendingUp,
  DollarSign,
  Radio,
  RefreshCw,
  Database
} from 'lucide-react';
import {
  AreaChart,
  Area,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import { api } from '../services/api';
import { useLiveTelemetry } from '../hooks/useLiveTelemetry';
import { KpiCard } from '../components/KpiCard';
import { StatusBadge } from '../components/StatusBadge';

export function GridPage() {
  const queryClient = useQueryClient();
  const { liveGridData } = useLiveTelemetry();

  // Grid Current query
  const { data: currentGrid } = useQuery({
    queryKey: ['gridCurrent'],
    queryFn: () => api.getGridCurrent(),
    refetchInterval: 5000,
  });

  // Grid History query (24h load profile & TOU pricing)
  const { data: history = [] } = useQuery({
    queryKey: ['gridHistory'],
    queryFn: () => api.getGridHistory(),
  });

  // Grid Alerts query
  const { data: alerts = [], refetch: refetchAlerts } = useQuery({
    queryKey: ['gridAlerts'],
    queryFn: () => api.getGridAlerts(),
  });

  // Resolve alert mutation
  const resolveMutation = useMutation({
    mutationFn: (id: string) => api.resolveAlert(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['gridAlerts'] });
      queryClient.invalidateQueries({ queryKey: ['dashboardStats'] });
    },
  });

  // Active grid telemetry
  const telemetry = liveGridData || currentGrid || {
    total_capacity_kw: 5000.0,
    current_grid_load_kw: 2450.0,
    charging_load_kw: 680.0,
    base_load_kw: 1770.0,
    renewable_energy_kw: 950.0,
    peak_demand_kw: 3200.0,
    voltage_v: 400.2,
    frequency_hz: 50.01,
    power_factor: 0.98,
    capacity_utilization_pct: 49.0,
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            Substation Grid & Energy Telemetry
            <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-800/80 text-emerald-400 flex items-center gap-1">
              <Database className="h-3 w-3" />
              Supabase Table: grid_telemetry
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time sub-station load management, time-of-use (TOU) tariffs, and renewable surplus tracking.
          </p>
        </div>

        <button
          onClick={() => {
            queryClient.invalidateQueries({ queryKey: ['gridCurrent'] });
            refetchAlerts();
          }}
          className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-xs font-medium text-slate-300 hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <RefreshCw className="h-3.5 w-3.5" />
          Refresh Substation Data
        </button>
      </div>

      {/* Grid Key Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          title="Total Substation Load"
          value={`${telemetry.current_grid_load_kw} kW`}
          subtitle={`Capacity: ${telemetry.total_capacity_kw} kW (${telemetry.capacity_utilization_pct}%)`}
          icon={Gauge}
          trend={{ value: `${telemetry.capacity_utilization_pct}%`, isPositive: telemetry.capacity_utilization_pct < 80, label: 'utilization' }}
          accentColor={telemetry.capacity_utilization_pct > 80 ? 'rose' : 'cyan'}
        />

        <KpiCard
          title="EV Fleet Charging Load"
          value={`${telemetry.charging_load_kw} kW`}
          subtitle="60 depot ports distributed"
          icon={Zap}
          trend={{ value: `${Math.round((telemetry.charging_load_kw / telemetry.current_grid_load_kw) * 100)}%`, label: 'of total grid' }}
          accentColor="amber"
        />

        <KpiCard
          title="Renewable Solar / Wind"
          value={`${telemetry.renewable_energy_kw} kW`}
          subtitle="Presidio & Ecozone Solar Arrays"
          icon={Sun}
          trend={{ value: '+420 kW', isPositive: true, label: 'peak surplus window' }}
          accentColor="emerald"
        />

        <KpiCard
          title="Line Frequency & Factor"
          value={`${telemetry.frequency_hz} Hz`}
          subtitle={`Power Factor: ${telemetry.power_factor} PF • ${telemetry.voltage_v} V`}
          icon={Activity}
          trend={{ value: 'Stable', isPositive: true, label: 'harmonic health' }}
          accentColor="indigo"
        />
      </div>

      {/* 24h Load Profile & TOU Pricing Curve */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-cyan-400" />
              24-Hour Grid Load & Dynamic Electricity Pricing (TOU)
            </h3>
            <p className="text-[11px] text-slate-400">
              Correlating fleet charging power with off-peak vs on-peak utility tariffs ($/kWh)
            </p>
          </div>
          <div className="flex items-center gap-4 text-xs font-mono">
            <span className="text-cyan-400">Total Load (kW)</span>
            <span className="text-amber-400">Charging (kW)</span>
            <span className="text-emerald-400">TOU Tariff ($/kWh)</span>
          </div>
        </div>

        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={history}>
              <defs>
                <linearGradient id="gridLoadGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.0} />
                </linearGradient>
                <linearGradient id="chargingLoadGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="hour_label" stroke="#64748b" tick={{ fontSize: 10 }} />
              <YAxis yAxisId="left" stroke="#64748b" tick={{ fontSize: 10 }} unit=" kW" />
              <YAxis yAxisId="right" orientation="right" stroke="#10b981" tick={{ fontSize: 10 }} unit=" $" domain={[0, 0.60]} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderColor: '#334155',
                  borderRadius: '0.75rem',
                  fontSize: '11px',
                }}
              />
              <Legend />
              <Area
                yAxisId="left"
                type="monotone"
                dataKey="grid_load_kw"
                stroke="#06b6d4"
                strokeWidth={2}
                fill="url(#gridLoadGrad)"
                name="Total Grid Load (kW)"
              />
              <Area
                yAxisId="left"
                type="monotone"
                dataKey="charging_load_kw"
                stroke="#f59e0b"
                strokeWidth={2}
                fill="url(#chargingLoadGrad)"
                name="Fleet Charging (kW)"
              />
              <Line
                yAxisId="right"
                type="stepAfter"
                dataKey="electricity_price"
                stroke="#10b981"
                strokeWidth={2}
                dot={false}
                name="TOU Tariff ($/kWh)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Grid Alerts Feed */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-amber-400" />
            <h3 className="text-sm font-semibold text-white">Grid Operator Alerts & Load Shedding Feed</h3>
          </div>
          <span className="text-xs text-slate-400">
            {alerts.filter((a) => a.status === 'ACTIVE').length} Active Alerts
          </span>
        </div>

        <div className="divide-y divide-slate-800/60">
          {alerts.length === 0 ? (
            <p className="py-6 text-center text-xs text-slate-500">
              No grid warnings or alerts reported. All feeder lines nominal.
            </p>
          ) : (
            alerts.map((alert) => (
              <div key={alert.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div
                    className={`p-2 rounded-xl border mt-0.5 ${
                      alert.severity === 'CRITICAL'
                        ? 'border-rose-800 bg-rose-950/60 text-rose-400'
                        : alert.severity === 'WARNING'
                        ? 'border-amber-800 bg-amber-950/60 text-amber-400'
                        : 'border-cyan-800 bg-cyan-950/60 text-cyan-400'
                    }`}
                  >
                    <AlertTriangle className="h-4 w-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-slate-200">{alert.title}</span>
                      <StatusBadge status={alert.status} size="sm" />
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">{alert.message}</p>
                    <span className="text-[10px] text-slate-500">
                      Reported: {new Date(alert.created_at).toLocaleString()}
                    </span>
                  </div>
                </div>

                {alert.status === 'ACTIVE' && (
                  <button
                    onClick={() => resolveMutation.mutate(alert.id)}
                    disabled={resolveMutation.isPending}
                    className="shrink-0 rounded-xl border border-slate-800 bg-slate-950 px-3 py-1.5 text-xs font-medium text-slate-300 hover:bg-slate-800 hover:text-white transition-colors cursor-pointer"
                  >
                    Resolve Alert
                  </button>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
