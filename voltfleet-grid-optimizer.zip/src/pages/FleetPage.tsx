import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Truck,
  Plus,
  Search,
  Filter,
  History,
  Edit2,
  Trash2,
  AlertCircle,
  Database,
  RefreshCw,
  CheckCircle2,
  X
} from 'lucide-react';
import { api } from '../services/api';
import { Vehicle, VehicleStatus, ChargingStatus } from '../types';
import { StatusBadge } from '../components/StatusBadge';
import { BatteryIndicator } from '../components/BatteryIndicator';
import { Modal } from '../components/Modal';

export function FleetPage() {
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [chargingStatusFilter, setChargingStatusFilter] = useState('ALL');
  const [page, setPage] = useState(1);
  const pageSize = 12;

  // Modals state
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState<Vehicle | null>(null);
  const [historyVehicle, setHistoryVehicle] = useState<Vehicle | null>(null);
  const [deletingVehicleId, setDeletingVehicleId] = useState<string | null>(null);

  // New vehicle form state
  const [newVehicle, setNewVehicle] = useState({
    vin: '',
    registration_number: '',
    make: 'Tesla',
    model: 'Model Y Commercial',
    year: 2024,
    battery_capacity: 75.0,
    current_soc: 85.0,
    target_soc: 90.0,
    status: 'AVAILABLE' as VehicleStatus,
    charging_status: 'DISCONNECTED' as ChargingStatus,
    current_location: 'Central Fleet Depot',
    max_charge_rate_kw: 150.0,
    driver_id: '',
  });

  // Query vehicles from Supabase
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['vehicles', page, pageSize, searchTerm, statusFilter, chargingStatusFilter],
    queryFn: () =>
      api.getVehicles({
        page,
        page_size: pageSize,
        search: searchTerm || undefined,
        status: statusFilter,
        charging_status: chargingStatusFilter,
      }),
  });

  // Query drivers for dropdown
  const { data: drivers = [] } = useQuery({
    queryKey: ['drivers'],
    queryFn: () => api.getDrivers(),
  });

  // History query for selected vehicle
  const { data: chargingHistory = [], isLoading: historyLoading } = useQuery({
    queryKey: ['vehicleHistory', historyVehicle?.id],
    queryFn: () => (historyVehicle ? api.getVehicleChargingHistory(historyVehicle.id) : []),
    enabled: !!historyVehicle,
  });

  // Mutations
  const createMutation = useMutation({
    mutationFn: (vData: Partial<Vehicle>) => api.createVehicle(vData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vehicles'] });
      queryClient.invalidateQueries({ queryKey: ['dashboardStats'] });
      setIsAddOpen(false);
      resetNewForm();
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, updates }: { id: string; updates: Partial<Vehicle> }) =>
      api.updateVehicle(id, updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vehicles'] });
      queryClient.invalidateQueries({ queryKey: ['dashboardStats'] });
      setEditingVehicle(null);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => api.deleteVehicle(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vehicles'] });
      queryClient.invalidateQueries({ queryKey: ['dashboardStats'] });
      setDeletingVehicleId(null);
    },
  });

  const resetNewForm = () => {
    const randomNum = Math.floor(100 + Math.random() * 900);
    setNewVehicle({
      vin: `1FTNE3Y8${randomNum}PKA${Math.floor(10000 + Math.random() * 90000)}`,
      registration_number: `EV-FLT-${randomNum}`,
      make: 'Tesla',
      model: 'Model Y Commercial',
      year: 2024,
      battery_capacity: 75.0,
      current_soc: 85.0,
      target_soc: 90.0,
      status: 'AVAILABLE',
      charging_status: 'DISCONNECTED',
      current_location: 'Central Fleet Depot',
      max_charge_rate_kw: 150.0,
      driver_id: '',
    });
  };

  const handleOpenAddModal = () => {
    resetNewForm();
    setIsAddOpen(true);
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate({
      ...newVehicle,
      battery_capacity: Number(newVehicle.battery_capacity),
      current_soc: Number(newVehicle.current_soc),
      target_soc: Number(newVehicle.target_soc),
      year: Number(newVehicle.year),
      max_charge_rate_kw: Number(newVehicle.max_charge_rate_kw),
      driver_id: newVehicle.driver_id || undefined,
    });
  };

  const handleUpdateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingVehicle) return;
    updateMutation.mutate({
      id: editingVehicle.id,
      updates: {
        status: editingVehicle.status,
        charging_status: editingVehicle.charging_status,
        current_soc: Number(editingVehicle.current_soc),
        target_soc: Number(editingVehicle.target_soc),
        current_location: editingVehicle.current_location,
        max_charge_rate_kw: Number(editingVehicle.max_charge_rate_kw),
      },
    });
  };

  const vehicles = data?.items || [];
  const total = data?.total || 0;
  const totalPages = data?.total_pages || 1;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            Fleet Asset Management
            <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-800/80 text-emerald-400 flex items-center gap-1">
              <Database className="h-3 w-3" />
              Supabase Normalized Table: vehicles
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time telemetry, state of charge (SOC), assigned drivers, and dispatch control.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => refetch()}
            className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-xs font-medium text-slate-300 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            Refresh
          </button>
          <button
            onClick={handleOpenAddModal}
            className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 px-4 py-2 text-xs font-semibold text-white shadow-lg shadow-cyan-500/20 hover:from-cyan-500 hover:to-blue-500 transition-all cursor-pointer"
          >
            <Plus className="h-4 w-4" />
            Add Fleet Asset
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row gap-3 rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setPage(1);
            }}
            placeholder="Search by registration (e.g. EV-FLT-101), VIN, make or model..."
            className="w-full rounded-xl border border-slate-800 bg-slate-950/80 py-2 pl-10 pr-4 text-xs text-slate-200 placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 flex items-center gap-1">
              <Filter className="h-3 w-3" /> Status:
            </span>
            <select
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                setPage(1);
              }}
              className="rounded-xl border border-slate-800 bg-slate-950/80 py-2 px-3 text-xs text-slate-200 focus:border-cyan-500 focus:outline-none cursor-pointer"
            >
              <option value="ALL">All Statuses</option>
              <option value="AVAILABLE">Available</option>
              <option value="CHARGING">Charging</option>
              <option value="ON_TRIP">On Trip</option>
              <option value="IDLE">Idle</option>
              <option value="MAINTENANCE">Maintenance</option>
              <option value="OFFLINE">Offline</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">Charging:</span>
            <select
              value={chargingStatusFilter}
              onChange={(e) => {
                setChargingStatusFilter(e.target.value);
                setPage(1);
              }}
              className="rounded-xl border border-slate-800 bg-slate-950/80 py-2 px-3 text-xs text-slate-200 focus:border-cyan-500 focus:outline-none cursor-pointer"
            >
              <option value="ALL">All Charging States</option>
              <option value="CHARGING">Charging</option>
              <option value="CONNECTED">Connected</option>
              <option value="DISCONNECTED">Disconnected</option>
              <option value="COMPLETE">Complete</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Vehicles Table */}
      <div className="overflow-hidden rounded-2xl border border-slate-800 bg-slate-900/80 shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-800 bg-slate-950/80 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              <tr>
                <th className="py-3.5 px-4">Vehicle</th>
                <th className="py-3.5 px-4">Make / Model</th>
                <th className="py-3.5 px-4">Battery / SOC</th>
                <th className="py-3.5 px-4">Fleet Status</th>
                <th className="py-3.5 px-4">Charging Status</th>
                <th className="py-3.5 px-4">Assigned Driver</th>
                <th className="py-3.5 px-4">Location</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {isLoading ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    <div className="flex items-center justify-center gap-2">
                      <span className="h-4 w-4 animate-spin rounded-full border-2 border-cyan-500 border-t-transparent" />
                      Loading fleet assets from Supabase...
                    </div>
                  </td>
                </tr>
              ) : vehicles.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    <Truck className="mx-auto h-8 w-8 text-slate-600 mb-2" />
                    No vehicles found matching current criteria.
                  </td>
                </tr>
              ) : (
                vehicles.map((v) => (
                  <tr key={v.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-semibold text-white font-mono">{v.registration_number}</div>
                      <div className="text-[10px] text-slate-500 font-mono truncate max-w-[140px]">
                        VIN: {v.vin}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="text-slate-200 font-medium">
                        {v.make} {v.model}
                      </div>
                      <div className="text-[10px] text-slate-500">{v.year} Model • {v.battery_capacity} kWh</div>
                    </td>
                    <td className="py-3 px-4">
                      <BatteryIndicator
                        soc={v.current_soc}
                        isCharging={v.charging_status === 'CHARGING'}
                        size="sm"
                      />
                      <div className="text-[10px] text-slate-500 mt-0.5">Target: {v.target_soc}%</div>
                    </td>
                    <td className="py-3 px-4">
                      <StatusBadge status={v.status} size="sm" />
                    </td>
                    <td className="py-3 px-4">
                      <StatusBadge status={v.charging_status} size="sm" />
                    </td>
                    <td className="py-3 px-4">
                      {v.driver ? (
                        <div>
                          <div className="font-medium text-slate-200">{v.driver.name}</div>
                          <div className="text-[10px] text-slate-500">{v.driver.license_number}</div>
                        </div>
                      ) : (
                        <span className="text-slate-600 italic">Unassigned</span>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <span className="truncate max-w-[150px] block text-slate-400">
                        {v.current_location}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setHistoryVehicle(v)}
                          title="Charging History"
                          className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-cyan-400 transition-colors cursor-pointer"
                        >
                          <History className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => setEditingVehicle(v)}
                          title="Edit Vehicle"
                          className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors cursor-pointer"
                        >
                          <Edit2 className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => setDeletingVehicleId(v.id)}
                          title="Delete Vehicle"
                          className="rounded-lg p-1.5 text-slate-400 hover:bg-rose-950/60 hover:text-rose-400 transition-colors cursor-pointer"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Footer */}
        <div className="flex items-center justify-between border-t border-slate-800 bg-slate-950/60 px-4 py-3 text-xs">
          <div className="text-slate-400">
            Showing <span className="font-medium text-slate-200">{vehicles.length}</span> of{' '}
            <span className="font-medium text-slate-200">{total}</span> total assets in Supabase
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="rounded-lg border border-slate-800 bg-slate-900 px-3 py-1 text-slate-300 hover:bg-slate-800 disabled:opacity-40 disabled:pointer-events-none cursor-pointer"
            >
              Previous
            </button>
            <span className="px-2 text-slate-400">
              Page {page} of {totalPages}
            </span>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page >= totalPages}
              className="rounded-lg border border-slate-800 bg-slate-900 px-3 py-1 text-slate-300 hover:bg-slate-800 disabled:opacity-40 disabled:pointer-events-none cursor-pointer"
            >
              Next
            </button>
          </div>
        </div>
      </div>

      {/* MODAL: ADD VEHICLE */}
      <Modal isOpen={isAddOpen} onClose={() => setIsAddOpen(false)} title="Register New Fleet Asset">
        <form onSubmit={handleCreateSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Registration</label>
              <input
                type="text"
                required
                value={newVehicle.registration_number}
                onChange={(e) => setNewVehicle({ ...newVehicle, registration_number: e.target.value })}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">VIN</label>
              <input
                type="text"
                required
                value={newVehicle.vin}
                onChange={(e) => setNewVehicle({ ...newVehicle, vin: e.target.value })}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Make</label>
              <input
                type="text"
                required
                value={newVehicle.make}
                onChange={(e) => setNewVehicle({ ...newVehicle, make: e.target.value })}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Model</label>
              <input
                type="text"
                required
                value={newVehicle.model}
                onChange={(e) => setNewVehicle({ ...newVehicle, model: e.target.value })}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Year</label>
              <input
                type="number"
                required
                value={newVehicle.year}
                onChange={(e) => setNewVehicle({ ...newVehicle, year: Number(e.target.value) })}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Battery (kWh)</label>
              <input
                type="number"
                step="0.1"
                required
                value={newVehicle.battery_capacity}
                onChange={(e) => setNewVehicle({ ...newVehicle, battery_capacity: Number(e.target.value) })}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Current SOC (%)</label>
              <input
                type="number"
                min="0"
                max="100"
                required
                value={newVehicle.current_soc}
                onChange={(e) => setNewVehicle({ ...newVehicle, current_soc: Number(e.target.value) })}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Target SOC (%)</label>
              <input
                type="number"
                min="0"
                max="100"
                required
                value={newVehicle.target_soc}
                onChange={(e) => setNewVehicle({ ...newVehicle, target_soc: Number(e.target.value) })}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Initial Status</label>
              <select
                value={newVehicle.status}
                onChange={(e) => setNewVehicle({ ...newVehicle, status: e.target.value as VehicleStatus })}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
              >
                <option value="AVAILABLE">AVAILABLE</option>
                <option value="CHARGING">CHARGING</option>
                <option value="ON_TRIP">ON_TRIP</option>
                <option value="IDLE">IDLE</option>
                <option value="MAINTENANCE">MAINTENANCE</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Assigned Driver</label>
              <select
                value={newVehicle.driver_id}
                onChange={(e) => setNewVehicle({ ...newVehicle, driver_id: e.target.value })}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
              >
                <option value="">-- No Driver Assigned --</option>
                {drivers.map((d: any) => (
                  <option key={d.id} value={d.id}>
                    {d.name} ({d.license_number})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Current Location</label>
            <input
              type="text"
              value={newVehicle.current_location}
              onChange={(e) => setNewVehicle({ ...newVehicle, current_location: e.target.value })}
              className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
            />
          </div>

          <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsAddOpen(false)}
              className="rounded-xl border border-slate-800 bg-slate-900 px-4 py-2 text-xs text-slate-300 hover:bg-slate-800 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={createMutation.isPending}
              className="flex items-center gap-1.5 rounded-xl bg-cyan-600 px-4 py-2 text-xs font-semibold text-white hover:bg-cyan-500 disabled:opacity-50 cursor-pointer"
            >
              {createMutation.isPending ? 'Saving...' : 'Save to Supabase'}
            </button>
          </div>
        </form>
      </Modal>

      {/* MODAL: EDIT VEHICLE */}
      <Modal
        isOpen={!!editingVehicle}
        onClose={() => setEditingVehicle(null)}
        title={`Edit Vehicle: ${editingVehicle?.registration_number}`}
      >
        {editingVehicle && (
          <form onSubmit={handleUpdateSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Fleet Status</label>
                <select
                  value={editingVehicle.status}
                  onChange={(e) =>
                    setEditingVehicle({ ...editingVehicle, status: e.target.value as VehicleStatus })
                  }
                  className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
                >
                  <option value="AVAILABLE">AVAILABLE</option>
                  <option value="CHARGING">CHARGING</option>
                  <option value="ON_TRIP">ON_TRIP</option>
                  <option value="IDLE">IDLE</option>
                  <option value="MAINTENANCE">MAINTENANCE</option>
                  <option value="OFFLINE">OFFLINE</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Charging Status</label>
                <select
                  value={editingVehicle.charging_status}
                  onChange={(e) =>
                    setEditingVehicle({
                      ...editingVehicle,
                      charging_status: e.target.value as ChargingStatus,
                    })
                  }
                  className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
                >
                  <option value="DISCONNECTED">DISCONNECTED</option>
                  <option value="CONNECTED">CONNECTED</option>
                  <option value="CHARGING">CHARGING</option>
                  <option value="COMPLETE">COMPLETE</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Current SOC (%)</label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  step="0.5"
                  value={editingVehicle.current_soc}
                  onChange={(e) =>
                    setEditingVehicle({ ...editingVehicle, current_soc: Number(e.target.value) })
                  }
                  className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Target SOC (%)</label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  step="1"
                  value={editingVehicle.target_soc}
                  onChange={(e) =>
                    setEditingVehicle({ ...editingVehicle, target_soc: Number(e.target.value) })
                  }
                  className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Current Location</label>
              <input
                type="text"
                value={editingVehicle.current_location}
                onChange={(e) =>
                  setEditingVehicle({ ...editingVehicle, current_location: e.target.value })
                }
                className="w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-white"
              />
            </div>

            <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setEditingVehicle(null)}
                className="rounded-xl border border-slate-800 bg-slate-900 px-4 py-2 text-xs text-slate-300 hover:bg-slate-800 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={updateMutation.isPending}
                className="flex items-center gap-1.5 rounded-xl bg-cyan-600 px-4 py-2 text-xs font-semibold text-white hover:bg-cyan-500 disabled:opacity-50 cursor-pointer"
              >
                {updateMutation.isPending ? 'Updating...' : 'Update Vehicle'}
              </button>
            </div>
          </form>
        )}
      </Modal>

      {/* MODAL: CHARGING HISTORY */}
      <Modal
        isOpen={!!historyVehicle}
        onClose={() => setHistoryVehicle(null)}
        title={`Charging History: ${historyVehicle?.registration_number}`}
        maxWidth="max-w-2xl"
      >
        {historyLoading ? (
          <div className="py-8 text-center text-xs text-slate-400">Loading history...</div>
        ) : chargingHistory.length === 0 ? (
          <div className="py-8 text-center text-xs text-slate-400">
            No past charging sessions recorded for this asset yet.
          </div>
        ) : (
          <div className="space-y-3">
            <div className="overflow-x-auto rounded-xl border border-slate-800">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="py-2.5 px-3">Station / Port</th>
                    <th className="py-2.5 px-3">Start Time</th>
                    <th className="py-2.5 px-3">SOC Delta</th>
                    <th className="py-2.5 px-3">Delivered</th>
                    <th className="py-2.5 px-3">Cost</th>
                    <th className="py-2.5 px-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {chargingHistory.map((s: any) => (
                    <tr key={s.id} className="hover:bg-slate-800/40">
                      <td className="py-2.5 px-3">
                        <div className="font-medium text-slate-200">{s.station_name}</div>
                        <div className="text-[10px] text-slate-500">{s.port_number}</div>
                      </td>
                      <td className="py-2.5 px-3 text-slate-400">
                        {new Date(s.start_time).toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 font-mono">
                        {s.start_soc}% → {s.end_soc || '--'}%
                      </td>
                      <td className="py-2.5 px-3 font-mono font-medium text-cyan-400">
                        {s.energy_delivered_kwh} kWh
                      </td>
                      <td className="py-2.5 px-3 font-mono text-emerald-400">${s.cost}</td>
                      <td className="py-2.5 px-3">
                        <StatusBadge status={s.status} size="sm" />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </Modal>

      {/* CONFIRM DELETE MODAL */}
      <Modal
        isOpen={!!deletingVehicleId}
        onClose={() => setDeletingVehicleId(null)}
        title="Confirm Asset Deactivation"
      >
        <div className="space-y-4">
          <p className="text-xs text-slate-300">
            Are you sure you want to permanently remove this vehicle from the Supabase fleet database?
            All relational charging sessions and telemetry associated with this asset ID will be cascaded.
          </p>
          <div className="flex justify-end gap-2 pt-2">
            <button
              onClick={() => setDeletingVehicleId(null)}
              className="rounded-xl border border-slate-800 bg-slate-900 px-4 py-2 text-xs text-slate-300 hover:bg-slate-800 cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={() => deletingVehicleId && deleteMutation.mutate(deletingVehicleId)}
              disabled={deleteMutation.isPending}
              className="rounded-xl bg-rose-600 px-4 py-2 text-xs font-semibold text-white hover:bg-rose-500 disabled:opacity-50 cursor-pointer"
            >
              {deleteMutation.isPending ? 'Deleting...' : 'Confirm Delete'}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
