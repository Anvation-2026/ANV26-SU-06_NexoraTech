import os
import sys
import random
from datetime import datetime, timezone, timedelta

# Ensure python path includes applet root
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from backend.app.core.database import SessionLocal, engine, Base
from backend.app.core.security import get_password_hash
from backend.app.models.user import User, Driver, Customer, Notification, SystemSetting
from backend.app.models.fleet import Vehicle, VehicleTelemetry
from backend.app.models.charging import ChargingStation, ChargingPort, ChargingSession, ChargingTelemetry
from backend.app.models.grid import GridTelemetry, GridAlert, ElectricityPrice
from backend.app.models.booking import Booking
from backend.app.models.feedback import CustomerFeedback

def seed():
    print("Initializing Database tables...")
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    try:
        # Check if already seeded
        if db.query(User).count() > 0:
            print("Database already contains data. Skipping initial seed.")
            return

        print("Seeding Users and Roles...")
        users = [
            User(email="admin@evfleet.io", hashed_password=get_password_hash("password123"), full_name="System Administrator", role="ADMIN"),
            User(email="manager@evfleet.io", hashed_password=get_password_hash("password123"), full_name="Sarah Jenkins (Fleet Director)", role="FLEET_MANAGER"),
            User(email="operator@evfleet.io", hashed_password=get_password_hash("password123"), full_name="Marcus Vance (Grid Operator)", role="STATION_OPERATOR"),
            User(email="viewer@evfleet.io", hashed_password=get_password_hash("password123"), full_name="Alex Rivera (Analyst)", role="VIEWER"),
        ]
        db.add_all(users)
        db.commit()

        print("Seeding Drivers...")
        driver_names = [
            "Liam Nelson", "Emma Watson", "Noah Patel", "Olivia Chen", "William Davis",
            "Sophia Martinez", "James Wilson", "Isabella Taylor", "Benjamin Anderson", "Mia Thomas"
        ]
        drivers = []
        for i, name in enumerate(driver_names):
            d = Driver(
                name=name,
                license_number=f"DL-CA-{100000 + i}",
                phone=f"+1 (555) 019-{1000 + i}",
                email=f"{name.lower().replace(' ', '.')}@fleetdriver.org",
                status="AVAILABLE" if i % 2 == 0 else "ON_TRIP"
            )
            drivers.append(d)
        db.add_all(drivers)
        db.commit()

        print("Seeding 10 Charging Stations...")
        stations_data = [
            ("Metro Downtown Superhub", "ST-DT-01", "100 Market St, Financial District", 37.7935, -122.3970, 8, 350.0, 600.0, 0.28, "CCS2, NACS, Type 2"),
            ("Bay Bridge Logistics Depot", "ST-BB-02", "850 Embarcadero Way, Port Access", 37.7885, -122.3890, 6, 300.0, 500.0, 0.26, "CCS2, CHAdeMO"),
            ("Silicon Gateway Transit Park", "ST-SG-03", "4200 Silicon Ave, South Hub", 37.7650, -122.4050, 6, 250.0, 450.0, 0.29, "CCS2, NACS"),
            ("Pacific Heights FastCharge", "ST-PH-04", "2100 California St, Central", 37.7890, -122.4280, 6, 200.0, 400.0, 0.32, "CCS2, Type 2"),
            ("Golden Gate Fleet Terminal", "ST-GG-05", "1500 Marina Blvd, North Gate", 37.8040, -122.4410, 6, 350.0, 600.0, 0.27, "CCS2, NACS"),
            ("Mission Valley Freight Port", "ST-MV-06", "2600 Mission St, Transport Zone", 37.7550, -122.4180, 6, 300.0, 550.0, 0.25, "CCS2, CHAdeMO"),
            ("Airport Cargo Express Depot", "ST-AC-07", "700 Airport Blvd, Cargo Wing", 37.6250, -122.3800, 6, 400.0, 750.0, 0.24, "CCS2, NACS"),
            ("Sunset District Hub", "ST-SD-08", "1900 19th Ave, Westside", 37.7490, -122.4760, 6, 200.0, 400.0, 0.30, "CCS2, Type 2"),
            ("Civic Center Fleet Center", "ST-CC-09", "400 McAllister St, Government Core", 37.7800, -122.4190, 5, 250.0, 450.0, 0.28, "CCS2, NACS"),
            ("Presidio Green Energy Park", "ST-PG-10", "120 Lincoln Blvd, Presidio Ecozone", 37.7990, -122.4650, 5, 250.0, 450.0, 0.27, "CCS2, Type 2, NACS")
        ]

        stations = []
        for name, code, addr, lat, lng, total_p, max_p, grid_cap, price, conn_types in stations_data:
            st = ChargingStation(
                name=name,
                code=code,
                address=addr,
                latitude=lat,
                longitude=lng,
                total_ports=total_p,
                max_station_power_kw=max_p,
                grid_capacity_kw=grid_cap,
                current_load_kw=0.0,
                status="ONLINE",
                price_per_kwh=price,
                connector_types=conn_types
            )
            stations.append(st)
        db.add_all(stations)
        db.commit()

        print("Seeding 60 Charging Ports across stations...")
        ports = []
        port_counter = 1
        connector_options = ["CCS2", "NACS", "Type 2", "CHAdeMO"]
        for st in stations:
            for p_num in range(1, st.total_ports + 1):
                conn_type = connector_options[(p_num - 1) % len(connector_options)]
                p_status = "AVAILABLE"
                if port_counter in [1, 2, 4, 8, 11, 14, 18, 22, 27, 33, 40, 48]:
                    p_status = "BUSY"
                elif port_counter in [5, 17, 39]:
                    p_status = "RESERVED"
                elif port_counter in [29]:
                    p_status = "FAULTED"
                elif port_counter in [55]:
                    p_status = "OFFLINE"

                cp = ChargingPort(
                    station_id=st.id,
                    port_number=f"Port {p_num:02d}",
                    connector_type=conn_type,
                    max_power_kw=150.0 if p_num <= 4 else 350.0,
                    current_power_kw=85.0 if p_status == "BUSY" else 0.0,
                    status=p_status
                )
                ports.append(cp)
                port_counter += 1
        db.add_all(ports)
        db.commit()

        print("Seeding 50 Fleet Vehicles...")
        makes_models = [
            ("Tesla", "Semi", 800.0, 2024),
            ("Tesla", "Model Y Commercial", 75.0, 2023),
            ("Ford", "E-Transit 350", 68.0, 2024),
            ("Rivian", "EDV 700 Delivery", 135.0, 2024),
            ("Mercedes-Benz", "eSprinter Cargo", 113.0, 2024),
            ("Volvo", "VNR Electric Truck", 565.0, 2023),
            ("BrightDrop", "Zevo 600", 165.0, 2024),
            ("BYD", "8TT Electric Semi", 422.0, 2024)
        ]

        vehicles = []
        busy_port_idx = 0
        busy_ports = [p for p in ports if p.status == "BUSY"]

        for i in range(1, 51):
            mm = makes_models[(i - 1) % len(makes_models)]
            soc = random.uniform(25.0, 95.0)
            status = "AVAILABLE"
            charging_status = "DISCONNECTED"
            connected_port = None

            if i <= len(busy_ports):
                status = "CHARGING"
                charging_status = "CHARGING"
                connected_port = busy_ports[busy_port_idx]
                busy_port_idx += 1
                soc = random.uniform(22.0, 68.0)
            elif i % 5 == 0:
                status = "ON_TRIP"
            elif i % 12 == 0:
                status = "MAINTENANCE"
            elif i % 25 == 0:
                status = "IDLE"

            v = Vehicle(
                vin=f"1FTNE3Y8{i:02d}PKA{10000 + i}",
                registration_number=f"EV-FLT-{100 + i:03d}",
                make=mm[0],
                model=mm[1],
                year=mm[3],
                battery_capacity=mm[2],
                current_soc=round(soc, 1),
                target_soc=90.0,
                status=status,
                charging_status=charging_status,
                current_location="Active Delivery Corridor" if status == "ON_TRIP" else "Depot Hub Terminal",
                latitude=37.7749 + random.uniform(-0.05, 0.05),
                longitude=-122.4194 + random.uniform(-0.06, 0.06),
                odometer_km=round(8000.0 + i * 450.0, 1),
                max_charge_rate_kw=150.0 if mm[2] < 200 else 350.0,
                driver_id=drivers[(i - 1) % len(drivers)].id if i % 2 == 0 else None
            )
            vehicles.append(v)
            db.add(v)
            db.flush()

            if connected_port:
                connected_port.connected_vehicle_id = v.id

        db.commit()

        print("Seeding Charging Sessions...")
        now = datetime.now(timezone.utc)
        for i, bp in enumerate(busy_ports):
            sess = ChargingSession(
                port_id=bp.id,
                vehicle_id=bp.connected_vehicle_id or vehicles[i].id,
                start_time=now - timedelta(minutes=random.randint(15, 75)),
                start_soc=round(random.uniform(18.0, 35.0), 1),
                energy_delivered_kwh=round(random.uniform(24.0, 72.0), 1),
                peak_power_kw=bp.max_power_kw,
                cost=round(random.uniform(8.5, 24.0), 2),
                status="ACTIVE"
            )
            db.add(sess)

        # Completed sessions
        for i in range(25):
            st_port = ports[i % len(ports)]
            st_time = now - timedelta(hours=random.randint(2, 48))
            dur_min = random.randint(35, 90)
            kwh = round(dur_min * 1.1, 1)
            sess = ChargingSession(
                port_id=st_port.id,
                vehicle_id=vehicles[i % len(vehicles)].id,
                start_time=st_time,
                end_time=st_time + timedelta(minutes=dur_min),
                start_soc=22.0,
                end_soc=88.0,
                energy_delivered_kwh=kwh,
                peak_power_kw=120.0,
                cost=round(kwh * 0.28, 2),
                status="COMPLETED"
            )
            db.add(sess)
        db.commit()

        print("Seeding Electricity Tariff Rates...")
        for h in range(24):
            if 0 <= h < 6:
                rate, period = 0.14, "OFF_PEAK"
            elif 6 <= h < 16:
                rate, period = 0.26, "MID_PEAK"
            elif 16 <= h < 21:
                rate, period = 0.48, "ON_PEAK"
            else:
                rate, period = 0.18, "OFF_PEAK"
            db.add(ElectricityPrice(hour_of_day=h, price_per_kwh=rate, period_type=period, currency="USD"))
        db.commit()

        print("Seeding Grid Alerts...")
        alerts = [
            GridAlert(severity="WARNING", alert_type="HIGH_GRID_LOAD", title="Substation Grid Utilization Reached 78%", message="High simultaneous fast-charging detected at Bay Area Terminal 1. Automatic load shedding activated.", status="ACTIVE"),
            GridAlert(severity="INFO", alert_type="RENEWABLE_SURPLUS", title="Solar PV Peak Surplus Available", message="Presidio Ecozone generating 420 kW excess solar power. Recommended charging window open.", status="ACTIVE"),
            GridAlert(severity="WARNING", alert_type="CHARGER_OVERLOAD", title="Port 03 Thermal Throttling", message="Port temperature reached 48°C. Max power throttled to 90 kW for cooling.", status="ACTIVE")
        ]
        db.add_all(alerts)
        db.commit()

        print("Seeding Customer Feedback...")
        feedbacks = [
            CustomerFeedback(station_id=stations[0].id, customer_name="Marcus Vance (Logistics Mgr)", rating=5, category="CHARGING_SPEED", comment="350 kW charger charged our heavy semi from 20% to 80% in under 38 minutes. Flawless experience!"),
            CustomerFeedback(station_id=stations[1].id, customer_name="David K. (Delivery Courier)", rating=4, category="AVAILABILITY", comment="Clean station and easy bay access. Port 3 cable is a bit stiff in cold weather."),
            CustomerFeedback(station_id=stations[2].id, customer_name="Rachel Green (Transit Ops)", rating=5, category="APP_EXPERIENCE", comment="Real-time SOC monitoring and digital twin telemetry updates match our onboard dash perfectly."),
            CustomerFeedback(station_id=stations[3].id, customer_name="Kenji Sato (Route Driver)", rating=4, category="PAYMENT", comment="Automated fleet billing worked smoothly with zero manual card swiping needed."),
            CustomerFeedback(station_id=stations[4].id, customer_name="Elena Rostova (Fleet Dispatch)", rating=5, category="HARDWARE", comment="Reliable NACS and CCS2 connectors. Well illuminated canopy and security cameras."),
            CustomerFeedback(station_id=stations[5].id, customer_name="Thomas Wright (Operator)", rating=3, category="LOCATION", comment="Great charging speed but tight turning radius for full 53-ft trailer rigs.")
        ]
        db.add_all(feedbacks)
        db.commit()

        print("Seeding Sample Bookings...")
        tomorrow_str = (now + timedelta(days=1)).strftime("%Y-%m-%d")
        bookings = [
            Booking(station_id=stations[0].id, port_id=ports[0].id, vehicle_id=vehicles[0].id, booking_code="BK-810421", booking_date=tomorrow_str, start_time="09:00", duration_minutes=60, status="CONFIRMED", estimated_cost=21.50, notes="Priority delivery recharge"),
            Booking(station_id=stations[1].id, port_id=ports[6].id, vehicle_id=vehicles[1].id, booking_code="BK-941830", booking_date=tomorrow_str, start_time="14:30", duration_minutes=45, status="CONFIRMED", estimated_cost=16.80, notes="Route change stop"),
        ]
        db.add_all(bookings)
        db.commit()

        print("Seeding System Settings...")
        settings_defaults = [
            SystemSetting(key="organization_name", value="GridVolt Fleet Enterprise", category="GENERAL"),
            SystemSetting(key="max_grid_load_threshold_kw", value="4500", category="GRID"),
            SystemSetting(key="auto_optimize_charging", value="true", category="OPTIMIZATION"),
            SystemSetting(key="currency", value="USD ($)", category="GENERAL")
        ]
        db.add_all(settings_defaults)
        db.commit()

        print("Database successfully seeded with 50 vehicles, 10 stations, 60 ports, sessions, feedback, and telemetry!")

    except Exception as e:
        db.rollback()
        print(f"Error during seeding: {e}")
        raise e
    finally:
        db.close()

if __name__ == "__main__":
    seed()
