import pytest
from datetime import datetime, timezone, timedelta
from fastapi.testclient import TestClient
from backend.app.main import app
from backend.app.core.database import check_db_health
from backend.app.optimization.scheduler import optimize_charging_schedule

client = TestClient(app)

def test_database_connectivity_and_health():
    assert check_db_health() is True
    response = client.get("/api/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert data["database"] == "PostgreSQL"
    assert data["database_connected"] is True

def test_authentication_login_and_me():
    response = client.post(
        "/api/auth/login",
        json={"email": "admin@evfleet.io", "password": "password123"}
    )
    assert response.status_code == 200
    token_data = response.json()
    assert "access_token" in token_data
    assert token_data["user"]["role"] == "ADMIN"

    token = token_data["access_token"]
    me_resp = client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert me_resp.status_code == 200
    assert me_resp.json()["email"] == "admin@evfleet.io"

def test_dashboard_stats():
    response = client.get("/api/dashboard/stats")
    assert response.status_code == 200
    data = response.json()
    assert "kpis" in data
    assert data["kpis"]["total_vehicles"] >= 50
    assert data["kpis"]["total_charging_stations"] >= 10
    assert "charts" in data

def test_vehicles_crud():
    # List vehicles
    response = client.get("/api/vehicles?page=1&page_size=10")
    assert response.status_code == 200
    data = response.json()
    assert "items" in data
    assert len(data["items"]) == 10
    v_id = data["items"][0]["id"]

    # Get single vehicle
    single_resp = client.get(f"/api/vehicles/{v_id}")
    assert single_resp.status_code == 200
    assert single_resp.json()["id"] == v_id

    # Update vehicle
    update_resp = client.put(f"/api/vehicles/{v_id}", json={"current_soc": 88.5})
    assert update_resp.status_code == 200
    assert update_resp.json()["current_soc"] == 88.5

def test_charging_stations_and_ports():
    stations_resp = client.get("/api/stations")
    assert stations_resp.status_code == 200
    stations = stations_resp.json()
    assert len(stations) >= 10
    st_id = stations[0]["id"]

    ports_resp = client.get(f"/api/charging-ports?station_id={st_id}")
    assert ports_resp.status_code == 200
    ports = ports_resp.json()
    assert len(ports) > 0

    summary_resp = client.get("/api/charging-ports/summary")
    assert summary_resp.status_code == 200
    assert summary_resp.json()["total"] >= 60

def test_charging_sessions():
    sessions_resp = client.get("/api/charging-sessions")
    assert sessions_resp.status_code == 200
    sessions = sessions_resp.json()
    assert len(sessions) > 0

def test_grid_apis():
    curr_resp = client.get("/api/grid/current")
    assert curr_resp.status_code == 200
    curr_data = curr_resp.json()
    assert curr_data["total_capacity_kw"] == 5000.0

    hist_resp = client.get("/api/grid/history")
    assert hist_resp.status_code == 200
    assert len(hist_resp.json()) == 24

    alerts_resp = client.get("/api/grid/alerts")
    assert alerts_resp.status_code == 200
    assert isinstance(alerts_resp.json(), list)

def test_scipy_optimization():
    now = datetime.now(timezone.utc)
    res = optimize_charging_schedule(
        vehicle_id="test-veh-01",
        current_soc=25.0,
        target_soc=85.0,
        battery_capacity=100.0,
        arrival_time=now,
        departure_time=now + timedelta(hours=6),
        charger_power=150.0
    )
    assert res["energy_required"] == pytest.approx(60.0, rel=1e-2)
    assert res["estimated_cost"] > 0
    assert "schedule_intervals" in res

def test_bookings():
    bookings_resp = client.get("/api/bookings")
    assert bookings_resp.status_code == 200
    assert isinstance(bookings_resp.json(), list)

def test_customer_feedback():
    feedback_resp = client.get("/api/feedback")
    assert feedback_resp.status_code == 200
    assert len(feedback_resp.json()) > 0

    summary_resp = client.get("/api/feedback/summary")
    assert summary_resp.status_code == 200
    assert summary_resp.json()["total_reviews"] > 0

def test_reports_generation_and_pdf():
    payload = {
        "report_type": "Executive Summary",
        "start_date": "2026-10-01",
        "end_date": "2026-10-08"
    }
    gen_resp = client.post("/api/reports/generate", json=payload)
    assert gen_resp.status_code == 201
    rep = gen_resp.json()
    assert rep["status"] == "GENERATED"
    rep_id = rep["id"]

    download_resp = client.get(f"/api/reports/{rep_id}/download")
    assert download_resp.status_code == 200
    assert download_resp.headers["content-type"] == "application/pdf"
    assert len(download_resp.content) > 1000
