from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from backend.app.core.database import get_db
from backend.app.models.charging import ChargingStation, ChargingPort
from backend.app.schemas.schemas import ChargingStationResponse, ChargingPortResponse

router = APIRouter(prefix="/stations", tags=["Charging Stations"])

@router.get("", response_model=List[ChargingStationResponse])
def get_stations(
    status: Optional[str] = None,
    connector_type: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(ChargingStation)
    if status and status != "ALL":
        query = query.filter(ChargingStation.status == status)

    stations = query.all()
    results = []
    for st in stations:
        ports = db.query(ChargingPort).filter(ChargingPort.station_id == st.id).all()
        avail_count = sum(1 for p in ports if p.status == "AVAILABLE")
        busy_count = sum(1 for p in ports if p.status == "BUSY")
        
        # Calculate current load
        current_load = sum(p.current_power_kw for p in ports)

        port_schemas = []
        for p in ports:
            veh_soc = None
            veh_reg = None
            if p.connected_vehicle:
                veh_soc = p.connected_vehicle.current_soc
                veh_reg = p.connected_vehicle.registration_number
            port_schemas.append(ChargingPortResponse(
                id=p.id,
                station_id=p.station_id,
                port_number=p.port_number,
                connector_type=p.connector_type,
                max_power_kw=p.max_power_kw,
                current_power_kw=p.current_power_kw,
                status=p.status,
                connected_vehicle_id=p.connected_vehicle_id,
                connected_vehicle_soc=veh_soc,
                connected_vehicle_reg=veh_reg,
                created_at=p.created_at
            ))

        results.append(ChargingStationResponse(
            id=st.id,
            name=st.name,
            code=st.code,
            address=st.address,
            latitude=st.latitude,
            longitude=st.longitude,
            total_ports=len(ports),
            available_ports=avail_count,
            busy_ports=busy_count,
            max_station_power_kw=st.max_station_power_kw,
            grid_capacity_kw=st.grid_capacity_kw,
            current_load_kw=round(current_load, 1),
            status=st.status,
            price_per_kwh=st.price_per_kwh,
            connector_types=st.connector_types,
            ports=port_schemas,
            created_at=st.created_at
        ))
    return results

@router.get("/{station_id}", response_model=ChargingStationResponse)
def get_station(station_id: str, db: Session = Depends(get_db)):
    st = db.query(ChargingStation).filter(ChargingStation.id == station_id).first()
    if not st:
        raise HTTPException(status_code=404, detail="Station not found")
    
    ports = db.query(ChargingPort).filter(ChargingPort.station_id == st.id).all()
    avail_count = sum(1 for p in ports if p.status == "AVAILABLE")
    busy_count = sum(1 for p in ports if p.status == "BUSY")
    current_load = sum(p.current_power_kw for p in ports)

    port_schemas = []
    for p in ports:
        veh_soc = None
        veh_reg = None
        if p.connected_vehicle:
            veh_soc = p.connected_vehicle.current_soc
            veh_reg = p.connected_vehicle.registration_number
        port_schemas.append(ChargingPortResponse(
            id=p.id,
            station_id=p.station_id,
            port_number=p.port_number,
            connector_type=p.connector_type,
            max_power_kw=p.max_power_kw,
            current_power_kw=p.current_power_kw,
            status=p.status,
            connected_vehicle_id=p.connected_vehicle_id,
            connected_vehicle_soc=veh_soc,
            connected_vehicle_reg=veh_reg,
            created_at=p.created_at
        ))

    return ChargingStationResponse(
        id=st.id,
        name=st.name,
        code=st.code,
        address=st.address,
        latitude=st.latitude,
        longitude=st.longitude,
        total_ports=len(ports),
        available_ports=avail_count,
        busy_ports=busy_count,
        max_station_power_kw=st.max_station_power_kw,
        grid_capacity_kw=st.grid_capacity_kw,
        current_load_kw=round(current_load, 1),
        status=st.status,
        price_per_kwh=st.price_per_kwh,
        connector_types=st.connector_types,
        ports=port_schemas,
        created_at=st.created_at
    )
