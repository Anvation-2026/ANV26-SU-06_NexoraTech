from typing import List, Optional
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from backend.app.core.database import get_db
from backend.app.models.charging import ChargingSession, ChargingPort, ChargingStation
from backend.app.models.fleet import Vehicle
from backend.app.schemas.schemas import ChargingSessionResponse

router = APIRouter(prefix="/charging-sessions", tags=["Charging Sessions"])

@router.get("", response_model=List[dict])
def get_charging_sessions(
    status: Optional[str] = None,
    limit: int = Query(25, ge=1, le=100),
    db: Session = Depends(get_db)
):
    query = db.query(ChargingSession).order_by(ChargingSession.start_time.desc())
    if status and status != "ALL":
        query = query.filter(ChargingSession.status == status)
    
    sessions = query.limit(limit).all()
    results = []
    for s in sessions:
        port = s.port
        station = port.station if port else None
        veh = s.vehicle
        results.append({
            "id": s.id,
            "port_id": s.port_id,
            "port_number": port.port_number if port else "Port",
            "station_name": station.name if station else "Station",
            "vehicle_id": s.vehicle_id,
            "vehicle_reg": veh.registration_number if veh else "Unknown",
            "vehicle_model": f"{veh.make} {veh.model}" if veh else "",
            "start_time": s.start_time.isoformat(),
            "end_time": s.end_time.isoformat() if s.end_time else None,
            "start_soc": s.start_soc,
            "end_soc": s.end_soc,
            "energy_delivered_kwh": s.energy_delivered_kwh,
            "peak_power_kw": s.peak_power_kw,
            "cost": s.cost,
            "status": s.status
        })
    return results

@router.get("/active", response_model=List[dict])
def get_active_sessions(db: Session = Depends(get_db)):
    return get_charging_sessions(status="ACTIVE", limit=20, db=db)
