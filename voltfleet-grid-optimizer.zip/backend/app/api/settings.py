from typing import Dict, Any
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from backend.app.core.database import get_db
from backend.app.models.user import SystemSetting

router = APIRouter(prefix="/settings", tags=["Settings"])

DEFAULT_SETTINGS = {
    "organization_name": "GridVolt Fleet Enterprise",
    "currency": "USD ($)",
    "timezone": "UTC (America/Los_Angeles)",
    "theme": "dark",
    "max_grid_load_threshold_kw": "4500",
    "peak_price_warning_threshold": "0.40",
    "default_target_soc": "85",
    "auto_optimize_charging": "true",
    "email_notifications": "true",
    "sms_critical_alerts": "false",
    "session_timeout_minutes": "60",
    "two_factor_auth": "optional"
}

@router.get("")
def get_settings(db: Session = Depends(get_db)):
    settings_records = db.query(SystemSetting).all()
    res = dict(DEFAULT_SETTINGS)
    for s in settings_records:
        res[s.key] = s.value
    return res

@router.put("")
def update_settings(updates: Dict[str, Any], db: Session = Depends(get_db)):
    for k, v in updates.items():
        record = db.query(SystemSetting).filter(SystemSetting.key == k).first()
        if record:
            record.value = str(v)
        else:
            db.add(SystemSetting(key=k, value=str(v), category="GENERAL"))
    db.commit()
    return {"message": "Settings updated successfully", "updated": updates}
