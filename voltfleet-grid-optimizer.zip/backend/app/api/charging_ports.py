from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from backend.app.core.database import get_db
from backend.app.models.charging import ChargingPort, ChargingTelemetry, ChargingStation
from backend.app.schemas.schemas import ChargingPortResponse
from backend.app.websocket.manager import ws_manager

router = APIRouter(prefix="/charging-ports", tags=["Charging Ports"])

@router.get("/summary")
def get_ports_summary(db: Session = Depends(get_db)):
    ports = db.query(ChargingPort).all()
    total = len(ports)
    available = sum(1 for p in ports if p.status == "AVAILABLE")
    busy = sum(1 for p in ports if p.status == "BUSY")
    reserved = sum(1 for p in ports if p.status == "RESERVED")
    faulted = sum(1 for p in ports if p.status == "FAULTED")
    offline = sum(1 for p in ports if p.status == "OFFLINE")

    total_active_power = sum(p.current_power_kw for p in ports if p.status == "BUSY")

    return {
        "total": total,
        "available": available,
        "busy": busy,
        "reserved": reserved,
        "faulted": faulted,
        "offline": offline,
        "total_active_power_kw": round(total_active_power, 1)
    }

@router.get("", response_model=List[dict])
def get_charging_ports(
    status: Optional[str] = None,
    station_id: Optional[str] = None,
    connector_type: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(ChargingPort)
    if status and status != "ALL":
        query = query.filter(ChargingPort.status == status)
    if station_id and station_id != "ALL":
        query = query.filter(ChargingPort.station_id == station_id)
    if connector_type and connector_type != "ALL":
        query = query.filter(ChargingPort.connector_type == connector_type)

    ports = query.all()
    results = []
    for p in ports:
        veh = p.connected_vehicle
        station = p.station
        results.append({
            "id": p.id,
            "station_id": p.station_id,
            "station_name": station.name if station else "Station",
            "port_number": p.port_number,
            "connector_type": p.connector_type,
            "max_power_kw": p.max_power_kw,
            "current_power_kw": p.current_power_kw,
            "status": p.status,
            "connected_vehicle_id": p.connected_vehicle_id,
            "connected_vehicle_reg": veh.registration_number if veh else None,
            "connected_vehicle_model": f"{veh.make} {veh.model}" if veh else None,
            "vehicle_soc": veh.current_soc if veh else None,
            "session_duration_min": 45 if p.status == "BUSY" else 0,
            "energy_delivered_kwh": round(p.current_power_kw * 0.75, 1) if p.status == "BUSY" else 0.0,
            "created_at": p.created_at.isoformat()
        })
    return results

@router.get("/{port_id}")
def get_charging_port(port_id: str, db: Session = Depends(get_db)):
    p = db.query(ChargingPort).filter(ChargingPort.id == port_id).first()
    if not p:
        raise HTTPException(status_code=404, detail="Port not found")
    
    veh = p.connected_vehicle
    station = p.station
    telemetry = db.query(ChargingTelemetry).filter(ChargingTelemetry.port_id == p.id).order_by(ChargingTelemetry.created_at.desc()).limit(20).all()

    return {
        "id": p.id,
        "station_id": p.station_id,
        "station_name": station.name if station else "Station",
        "station_address": station.address if station else "",
        "port_number": p.port_number,
        "connector_type": p.connector_type,
        "max_power_kw": p.max_power_kw,
        "current_power_kw": p.current_power_kw,
        "status": p.status,
        "connected_vehicle_id": p.connected_vehicle_id,
        "connected_vehicle_reg": veh.registration_number if veh else None,
        "connected_vehicle_soc": veh.current_soc if veh else None,
        "recent_telemetry": [
            {
                "voltage_v": t.voltage_v,
                "current_a": t.current_a,
                "power_kw": t.power_kw,
                "energy_kwh": t.energy_kwh,
                "temperature_c": t.temperature_c,
                "created_at": t.created_at.isoformat(),
                "is_simulated": t.is_simulated
            }
            for t in reversed(telemetry)
        ]
    }
