from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from backend.app.core.database import get_db
from backend.app.models.fleet import Vehicle
from backend.app.models.optimization import OptimizationSchedule
from backend.app.schemas.schemas import OptimizationRequest, OptimizationResponse
from backend.app.optimization.scheduler import optimize_charging_schedule
from backend.app.websocket.manager import ws_manager

router = APIRouter(prefix="/optimization", tags=["Optimization"])

@router.post("/charging-schedule", response_model=OptimizationResponse)
async def create_charging_schedule(req: OptimizationRequest, db: Session = Depends(get_db)):
    vehicle = db.query(Vehicle).filter(Vehicle.id == req.vehicle_id).first()
    if not vehicle:
        raise HTTPException(status_code=404, detail="Vehicle not found")

    opt_result = optimize_charging_schedule(
        vehicle_id=req.vehicle_id,
        current_soc=req.current_soc,
        target_soc=req.target_soc,
        battery_capacity=req.battery_capacity,
        arrival_time=req.arrival_time,
        departure_time=req.departure_time,
        charger_power=req.charger_power,
        station_capacity=req.station_capacity,
        grid_capacity=req.grid_capacity,
        electricity_price=req.electricity_price,
        charging_priority=req.charging_priority
    )

    # Persist schedule to PostgreSQL
    new_schedule = OptimizationSchedule(
        vehicle_id=req.vehicle_id,
        current_soc=req.current_soc,
        target_soc=req.target_soc,
        battery_capacity=req.battery_capacity,
        arrival_time=req.arrival_time,
        departure_time=req.departure_time,
        charger_power=req.charger_power,
        charging_start=opt_result["charging_start"],
        charging_end=opt_result["charging_end"],
        energy_required=opt_result["energy_required"],
        estimated_cost=opt_result["estimated_cost"],
        baseline_peak_load=opt_result["baseline_peak_load"],
        optimized_peak_load=opt_result["optimized_peak_load"],
        estimated_savings=opt_result["estimated_savings"],
        schedule_intervals=opt_result["schedule_intervals"],
        status="ACTIVE"
    )
    db.add(new_schedule)
    db.commit()
    db.refresh(new_schedule)

    # Broadcast event to WebSocket
    await ws_manager.broadcast("schedule.optimized", {
        "vehicle_id": vehicle.id,
        "registration_number": vehicle.registration_number,
        "savings": opt_result["estimated_savings"],
        "optimized_peak_load": opt_result["optimized_peak_load"]
    })

    return OptimizationResponse(**opt_result)

@router.get("/schedules")
def get_recent_schedules(db: Session = Depends(get_db)):
    schedules = db.query(OptimizationSchedule).order_by(OptimizationSchedule.created_at.desc()).limit(10).all()
    results = []
    for s in schedules:
        veh = s.vehicle
        results.append({
            "id": s.id,
            "vehicle_id": s.vehicle_id,
            "vehicle_reg": veh.registration_number if veh else "Unknown",
            "vehicle_model": f"{veh.make} {veh.model}" if veh else "",
            "energy_required": s.energy_required,
            "estimated_cost": s.estimated_cost,
            "estimated_savings": s.estimated_savings,
            "charging_start": s.charging_start.isoformat(),
            "charging_end": s.charging_end.isoformat(),
            "status": s.status,
            "created_at": s.created_at.isoformat()
        })
    return results
