from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from sqlalchemy import func
from backend.app.core.database import get_db
from backend.app.models.feedback import CustomerFeedback
from backend.app.models.charging import ChargingStation
from backend.app.schemas.schemas import FeedbackCreate, FeedbackResponse

router = APIRouter(prefix="/feedback", tags=["Customer Feedback"])

@router.get("/summary")
def get_feedback_summary(db: Session = Depends(get_db)):
    feedbacks = db.query(CustomerFeedback).all()
    total = len(feedbacks)
    if total == 0:
        return {
            "average_rating": 4.5,
            "total_reviews": 0,
            "rating_distribution": {5: 0, 4: 0, 3: 0, 2: 0, 1: 0},
            "category_breakdown": {}
        }
    
    avg = sum(f.rating for f in feedbacks) / total
    distribution = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
    categories = {}
    for f in feedbacks:
        distribution[f.rating] = distribution.get(f.rating, 0) + 1
        categories[f.category] = categories.get(f.category, 0) + 1

    return {
        "average_rating": round(avg, 2),
        "total_reviews": total,
        "rating_distribution": distribution,
        "category_breakdown": categories
    }

@router.get("", response_model=List[dict])
def get_feedback(
    category: Optional[str] = None,
    station_id: Optional[str] = None,
    min_rating: Optional[int] = None,
    search: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(CustomerFeedback).order_by(CustomerFeedback.created_at.desc())
    if category and category != "ALL":
        query = query.filter(CustomerFeedback.category == category)
    if station_id and station_id != "ALL":
        query = query.filter(CustomerFeedback.station_id == station_id)
    if min_rating:
        query = query.filter(CustomerFeedback.rating >= min_rating)
    if search:
        s = f"%{search}%"
        query = query.filter(
            (CustomerFeedback.comment.ilike(s)) |
            (CustomerFeedback.customer_name.ilike(s))
        )

    feedbacks = query.all()
    results = []
    for f in feedbacks:
        st = f.station
        results.append({
            "id": f.id,
            "station_id": f.station_id,
            "station_name": st.name if st else "Station",
            "customer_name": f.customer_name,
            "rating": f.rating,
            "category": f.category,
            "comment": f.comment,
            "status": f.status,
            "created_at": f.created_at.isoformat()
        })
    return results

@router.post("", response_model=dict, status_code=status.HTTP_201_CREATED)
def submit_feedback(fb_in: FeedbackCreate, db: Session = Depends(get_db)):
    st = db.query(ChargingStation).filter(ChargingStation.id == fb_in.station_id).first()
    if not st:
        raise HTTPException(status_code=404, detail="Station not found")
    
    new_fb = CustomerFeedback(
        station_id=fb_in.station_id,
        customer_name=fb_in.customer_name or "EV Driver",
        rating=fb_in.rating,
        category=fb_in.category,
        comment=fb_in.comment,
        status="PUBLISHED"
    )
    db.add(new_fb)
    db.commit()
    db.refresh(new_fb)

    return {
        "id": new_fb.id,
        "station_name": st.name,
        "customer_name": new_fb.customer_name,
        "rating": new_fb.rating,
        "category": new_fb.category,
        "comment": new_fb.comment,
        "created_at": new_fb.created_at.isoformat()
    }
