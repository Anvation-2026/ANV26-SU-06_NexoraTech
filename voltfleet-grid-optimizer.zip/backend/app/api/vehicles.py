from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from backend.app.core.database import get_db
from backend.app.models.fleet import Vehicle, VehicleTelemetry
from backend.app.models.charging import ChargingSession
from backend.app.schemas.schemas import VehicleCreate, VehicleUpdate, VehicleResponse, ChargingSessionResponse
from backend.app.websocket.manager import ws_manager

router = APIRouter(prefix="/vehicles", tags=["Vehicles"])

@router.get("", response_model=dict)
def get_vehicles(
    page: int = Query(1, ge=1),
    page_size: int = Query(15, ge=1, le=100),
    search: Optional[str] = None,
    status: Optional[str] = None,
    charging_status: Optional[str] = None,
    sort_by: str = Query("created_at"),
    sort_desc: bool = Query(True),
    db: Session = Depends(get_db)
):
    query = db.query(Vehicle)

    if search:
        s = f"%{search}%"
        query = query.filter(
            (Vehicle.registration_number.ilike(s)) |
            (Vehicle.vin.ilike(s)) |
            (Vehicle.make.ilike(s)) |
            (Vehicle.model.ilike(s)) |
            (Vehicle.current_location.ilike(s))
        )

    if status and status != "ALL":
        query = query.filter(Vehicle.status == status)

    if charging_status and charging_status != "ALL":
        query = query.filter(Vehicle.charging_status == charging_status)

    total = query.count()

    # Sorting
    sort_attr = getattr(Vehicle, sort_by, Vehicle.created_at)
    if sort_desc:
        query = query.order_by(sort_attr.desc())
    else:
        query = query.order_by(sort_attr.asc())

    vehicles = query.offset((page - 1) * page_size).limit(page_size).all()

    return {
        "items": [VehicleResponse.from_orm(v) for v in vehicles],
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": (total + page_size - 1) // page_size
    }

@router.post("", response_model=VehicleResponse, status_code=status.HTTP_201_CREATED)
async def create_vehicle(vehicle_in: VehicleCreate, db: Session = Depends(get_db)):
    existing = db.query(Vehicle).filter(
        (Vehicle.registration_number == vehicle_in.registration_number) |
        (Vehicle.vin == vehicle_in.vin)
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="Vehicle with this VIN or Registration already exists")

    new_v = Vehicle(**vehicle_in.dict())
    db.add(new_v)
    db.commit()
    db.refresh(new_v)
    
    await ws_manager.broadcast("vehicle.created", {"id": new_v.id, "reg": new_v.registration_number})
    return new_v

@router.get("/{vehicle_id}", response_model=VehicleResponse)
def get_vehicle(vehicle_id: str, db: Session = Depends(get_db)):
    v = db.query(Vehicle).filter(Vehicle.id == vehicle_id).first()
    if not v:
        raise HTTPException(status_code=404, detail="Vehicle not found")
    return v

@router.put("/{vehicle_id}", response_model=VehicleResponse)
async def update_vehicle(vehicle_id: str, vehicle_in: VehicleUpdate, db: Session = Depends(get_db)):
    v = db.query(Vehicle).filter(Vehicle.id == vehicle_id).first()
    if not v:
        raise HTTPException(status_code=404, detail="Vehicle not found")

    update_data = vehicle_in.dict(exclude_unset=True)
    for field, val in update_data.items():
        setattr(v, field, val)

    db.commit()
    db.refresh(v)
    
    await ws_manager.broadcast("vehicle.updated", {
        "id": v.id,
        "registration_number": v.registration_number,
        "current_soc": v.current_soc,
        "status": v.status,
        "charging_status": v.charging_status
    })
    return v

@router.delete("/{vehicle_id}")
async def delete_vehicle(vehicle_id: str, db: Session = Depends(get_db)):
    v = db.query(Vehicle).filter(Vehicle.id == vehicle_id).first()
    if not v:
        raise HTTPException(status_code=404, detail="Vehicle not found")
    
    db.delete(v)
    db.commit()
    return {"message": "Vehicle deleted successfully"}

@router.get("/{vehicle_id}/charging-history")
def get_vehicle_charging_history(vehicle_id: str, db: Session = Depends(get_db)):
    sessions = db.query(ChargingSession).filter(ChargingSession.vehicle_id == vehicle_id).order_by(ChargingSession.start_time.desc()).limit(20).all()
    results = []
    for s in sessions:
        results.append({
            "id": s.id,
            "port_id": s.port_id,
            "station_name": s.port.station.name if s.port and s.port.station else "Unknown Station",
            "port_number": s.port.port_number if s.port else "Port",
            "start_time": s.start_time.isoformat(),
            "end_time": s.end_time.isoformat() if s.end_time else None,
            "start_soc": s.start_soc,
            "end_soc": s.end_soc,
            "energy_delivered_kwh": s.energy_delivered_kwh,
            "cost": s.cost,
            "status": s.status
        })
    return results

@router.get("/{vehicle_id}/telemetry-history")
def get_vehicle_telemetry_history(vehicle_id: str, db: Session = Depends(get_db)):
    telemetry = db.query(VehicleTelemetry).filter(VehicleTelemetry.vehicle_id == vehicle_id).order_by(VehicleTelemetry.created_at.desc()).limit(30).all()
    return [
        {
            "id": t.id,
            "soc": t.soc,
            "battery_temp_c": t.battery_temp_c,
            "charging_power_kw": t.charging_power_kw,
            "voltage_v": t.voltage_v,
            "current_a": t.current_a,
            "speed_kmh": t.speed_kmh,
            "energy_delivered_kwh": t.energy_delivered_kwh,
            "created_at": t.created_at.isoformat(),
            "is_simulated": t.is_simulated
        }
        for t in reversed(telemetry)
    ]
