from typing import List
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from backend.app.core.database import get_db
from backend.app.models.grid import GridTelemetry, GridAlert, ElectricityPrice
from backend.app.models.charging import ChargingPort
from backend.app.schemas.schemas import GridCurrentResponse, GridAlertResponse

router = APIRouter(prefix="/grid", tags=["Grid Monitor"])

@router.get("/current", response_model=GridCurrentResponse)
def get_grid_current(db: Session = Depends(get_db)):
    # Calculate live sum from ports
    ports = db.query(ChargingPort).all()
    charging_load = sum(p.current_power_kw for p in ports if p.status == "BUSY")
    base_load = 1780.0
    total_load = base_load + charging_load
    capacity = 5000.0
    renewable = 980.0

    return GridCurrentResponse(
        total_capacity_kw=capacity,
        current_grid_load_kw=round(total_load, 1),
        charging_load_kw=round(charging_load, 1),
        base_load_kw=round(base_load, 1),
        renewable_energy_kw=round(renewable, 1),
        peak_demand_kw=3250.0,
        voltage_v=400.2,
        frequency_hz=50.01,
        power_factor=0.98,
        capacity_utilization_pct=round((total_load / capacity) * 100.0, 1),
        is_simulated="SIMULATED",
        updated_at=datetime.now(timezone.utc)
    )

@router.get("/history")
def get_grid_history(db: Session = Depends(get_db)):
    # 24-hour historical curve
    now = datetime.now(timezone.utc)
    history = []
    prices = db.query(ElectricityPrice).all()
    price_map = {p.hour_of_day: p.price_per_kwh for p in prices}

    for i in range(24):
        slot_t = now - timedelta(hours=23 - i)
        hour = slot_t.hour
        # Diurnal pattern
        if 8 <= hour <= 20:
            base = 1750.0 + 250.0 * (1 - (abs(hour - 14) / 7.0))
            charging = 550.0 + 220.0 * (1 - (abs(hour - 16) / 8.0))
            renew = 850.0 + 350.0 * (1 - (abs(hour - 13) / 6.0))
        else:
            base = 1150.0 + 100.0 * (hour / 24.0)
            charging = 200.0 + 80.0 * (hour / 24.0)
            renew = 300.0

        history.append({
            "timestamp": slot_t.isoformat(),
            "hour_label": f"{hour:02d}:00",
            "grid_load_kw": round(base + charging, 1),
            "base_load_kw": round(base, 1),
            "charging_load_kw": round(charging, 1),
            "renewable_kw": round(renew, 1),
            "electricity_price": price_map.get(hour, 0.25)
        })
    return history

@router.get("/alerts", response_model=List[GridAlertResponse])
def get_grid_alerts(db: Session = Depends(get_db)):
    alerts = db.query(GridAlert).order_by(GridAlert.created_at.desc()).limit(15).all()
    return alerts

@router.post("/alerts/{alert_id}/resolve")
def resolve_alert(alert_id: str, db: Session = Depends(get_db)):
    alert = db.query(GridAlert).filter(GridAlert.id == alert_id).first()
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")
    alert.status = "RESOLVED"
    alert.resolved_at = datetime.now(timezone.utc)
    db.commit()
    return {"message": "Alert resolved"}
