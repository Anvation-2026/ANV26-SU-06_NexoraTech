import random
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from backend.app.core.database import get_db
from backend.app.models.booking import Booking
from backend.app.models.charging import ChargingStation, ChargingPort
from backend.app.schemas.schemas import BookingCreate, BookingResponse

router = APIRouter(prefix="/bookings", tags=["Bookings"])

@router.get("", response_model=List[dict])
def get_bookings(db: Session = Depends(get_db)):
    bookings = db.query(Booking).order_by(Booking.created_at.desc()).all()
    results = []
    for b in bookings:
        st = b.station
        port = b.port
        results.append({
            "id": b.id,
            "station_id": b.station_id,
            "station_name": st.name if st else "Station",
            "station_address": st.address if st else "",
            "port_id": b.port_id,
            "port_number": port.port_number if port else "Port",
            "booking_code": b.booking_code,
            "booking_date": b.booking_date,
            "start_time": b.start_time,
            "duration_minutes": b.duration_minutes,
            "status": b.status,
            "estimated_cost": b.estimated_cost,
            "notes": b.notes,
            "created_at": b.created_at.isoformat()
        })
    return results

@router.post("", response_model=dict, status_code=status.HTTP_201_CREATED)
def create_booking(booking_in: BookingCreate, db: Session = Depends(get_db)):
    station = db.query(ChargingStation).filter(ChargingStation.id == booking_in.station_id).first()
    if not station:
        raise HTTPException(status_code=404, detail="Station not found")
    
    port = db.query(ChargingPort).filter(ChargingPort.id == booking_in.port_id).first()
    if not port:
        raise HTTPException(status_code=404, detail="Port not found")

    code = f"BK-{random.randint(100000, 999999)}"
    est_kwh = (booking_in.duration_minutes / 60.0) * min(50.0, port.max_power_kw * 0.6)
    est_cost = round(est_kwh * station.price_per_kwh, 2)

    new_b = Booking(
        station_id=booking_in.station_id,
        port_id=booking_in.port_id,
        vehicle_id=booking_in.vehicle_id,
        booking_code=code,
        booking_date=booking_in.booking_date,
        start_time=booking_in.start_time,
        duration_minutes=booking_in.duration_minutes,
        status="CONFIRMED",
        estimated_cost=est_cost,
        notes=booking_in.notes
    )
    db.add(new_b)
    db.commit()
    db.refresh(new_b)

    return {
        "id": new_b.id,
        "booking_code": new_b.booking_code,
        "station_name": station.name,
        "port_number": port.port_number,
        "booking_date": new_b.booking_date,
        "start_time": new_b.start_time,
        "duration_minutes": new_b.duration_minutes,
        "status": new_b.status,
        "estimated_cost": new_b.estimated_cost
    }

@router.delete("/{booking_id}")
def cancel_booking(booking_id: str, db: Session = Depends(get_db)):
    b = db.query(Booking).filter(Booking.id == booking_id).first()
    if not b:
        raise HTTPException(status_code=404, detail="Booking not found")
    b.status = "CANCELLED"
    db.commit()
    return {"message": "Booking cancelled successfully"}
