import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import text

from backend.app.core.config import settings
from backend.app.core.database import engine, Base, check_db_health
from backend.app.websocket.manager import ws_manager
from backend.app.simulator.service import simulator

# Import API routers
from backend.app.api.auth import router as auth_router
from backend.app.api.vehicles import router as vehicles_router
from backend.app.api.stations import router as stations_router
from backend.app.api.charging_ports import router as ports_router
from backend.app.api.charging_sessions import router as sessions_router
from backend.app.api.grid import router as grid_router
from backend.app.api.bookings import router as bookings_router
from backend.app.api.feedback import router as feedback_router
from backend.app.api.optimization import router as optimization_router
from backend.app.api.reports import router as reports_router
from backend.app.api.settings import router as settings_router
from backend.app.api.dashboard import router as dashboard_router

logger = logging.getLogger("uvicorn.error")

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Initializing EV Fleet Management Backend...")
    try:
        # Create tables automatically on startup
        Base.metadata.create_all(bind=engine)
        logger.info("Database tables verified.")
    except Exception as e:
        logger.error(f"Error initializing DB schema: {e}")

    # Start live telemetry simulator
    await simulator.start()
    yield
    await simulator.stop()

app = FastAPI(
    title=settings.PROJECT_NAME,
    openapi_url="/api/openapi.json",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    lifespan=lifespan
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Health Check verifying PostgreSQL database
@app.get("/api/health")
def health_check():
    db_healthy = check_db_health()
    status_str = "healthy" if db_healthy else "degraded"
    status_code = 200 if db_healthy else 503
    return JSONResponse(
        status_code=status_code,
        content={
            "status": status_str,
            "backend": "FastAPI",
            "database": "PostgreSQL",
            "database_connected": db_healthy,
            "version": "1.0.0"
        }
    )

# WebSocket Live Telemetry
@app.websocket("/ws/live")
async def websocket_endpoint(websocket: WebSocket):
    await ws_manager.connect(websocket)
    try:
        while True:
            # Receive client ping or messages
            data = await websocket.receive_text()
            if data == "ping":
                await websocket.send_text("pong")
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)
    except Exception:
        ws_manager.disconnect(websocket)

# Include Routers
app.include_router(auth_router, prefix="/api")
app.include_router(vehicles_router, prefix="/api")
app.include_router(stations_router, prefix="/api")
app.include_router(ports_router, prefix="/api")
app.include_router(sessions_router, prefix="/api")
app.include_router(grid_router, prefix="/api")
app.include_router(bookings_router, prefix="/api")
app.include_router(feedback_router, prefix="/api")
app.include_router(optimization_router, prefix="/api")
app.include_router(reports_router, prefix="/api")
app.include_router(settings_router, prefix="/api")
app.include_router(dashboard_router, prefix="/api")
