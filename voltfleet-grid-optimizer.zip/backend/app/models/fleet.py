from sqlalchemy import Column, String, Float, ForeignKey, DateTime, Integer
from sqlalchemy.orm import relationship
from backend.app.models.base import BaseModel, get_utc_now

class Vehicle(BaseModel):
    __tablename__ = "vehicles"

    vin = Column(String(100), unique=True, index=True, nullable=False)
    registration_number = Column(String(50), unique=True, index=True, nullable=False)
    make = Column(String(100), nullable=False)
    model = Column(String(100), nullable=False)
    year = Column(Integer, default=2024, nullable=False)
    battery_capacity = Column(Float, nullable=False)  # in kWh
    current_soc = Column(Float, default=100.0, nullable=False)  # 0 to 100%
    target_soc = Column(Float, default=90.0, nullable=False)
    status = Column(String(50), default="AVAILABLE", nullable=False)  # AVAILABLE, ON_TRIP, CHARGING, IDLE, MAINTENANCE, OFFLINE
    charging_status = Column(String(50), default="DISCONNECTED", nullable=False)  # DISCONNECTED, CONNECTED, CHARGING, COMPLETE
    current_location = Column(String(255), default="Central Fleet Depot", nullable=False)
    latitude = Column(Float, default=37.7749, nullable=False)
    longitude = Column(Float, default=-122.4194, nullable=False)
    odometer_km = Column(Float, default=12500.0, nullable=False)
    max_charge_rate_kw = Column(Float, default=150.0, nullable=False)

    driver_id = Column(String(36), ForeignKey("drivers.id"), nullable=True)
    driver = relationship("Driver", back_populates="vehicles")

    telemetry = relationship("VehicleTelemetry", back_populates="vehicle", cascade="all, delete-orphan", order_by="desc(VehicleTelemetry.created_at)")
    charging_sessions = relationship("ChargingSession", back_populates="vehicle")
    optimization_schedules = relationship("OptimizationSchedule", back_populates="vehicle")

class VehicleTelemetry(BaseModel):
    __tablename__ = "vehicle_telemetry"

    vehicle_id = Column(String(36), ForeignKey("vehicles.id"), nullable=False, index=True)
    soc = Column(Float, nullable=False)  # %
    battery_temp_c = Column(Float, default=28.5, nullable=False)
    charging_power_kw = Column(Float, default=0.0, nullable=False)
    voltage_v = Column(Float, default=400.0, nullable=False)
    current_a = Column(Float, default=0.0, nullable=False)
    speed_kmh = Column(Float, default=0.0, nullable=False)
    energy_delivered_kwh = Column(Float, default=0.0, nullable=False)
    is_simulated = Column(String(10), default="SIMULATED", nullable=False)

    vehicle = relationship("Vehicle", back_populates="telemetry")
