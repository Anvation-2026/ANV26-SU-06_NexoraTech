from sqlalchemy import Column, String, Integer, ForeignKey, Text
from sqlalchemy.orm import relationship
from backend.app.models.base import BaseModel

class CustomerFeedback(BaseModel):
    __tablename__ = "customer_feedback"

    station_id = Column(String(36), ForeignKey("charging_stations.id"), nullable=False, index=True)
    customer_id = Column(String(36), ForeignKey("customers.id"), nullable=True)
    customer_name = Column(String(255), default="Anonymous EV Driver", nullable=False)
    
    rating = Column(Integer, nullable=False)  # 1 to 5
    category = Column(String(50), nullable=False)  # CHARGING_SPEED, AVAILABILITY, PAYMENT, APP_EXPERIENCE, LOCATION, HARDWARE, CUSTOMER_SERVICE, OTHER
    comment = Column(Text, nullable=False)
    status = Column(String(50), default="PUBLISHED", nullable=False)  # PUBLISHED, UNDER_REVIEW, RESOLVED

    station = relationship("ChargingStation", back_populates="feedback")
    customer = relationship("Customer", back_populates="feedback")
