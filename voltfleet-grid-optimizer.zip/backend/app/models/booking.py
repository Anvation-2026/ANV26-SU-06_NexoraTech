from sqlalchemy import Column, String, Float, ForeignKey, DateTime, Integer, Text
from sqlalchemy.orm import relationship
from backend.app.models.base import BaseModel

class Booking(BaseModel):
    __tablename__ = "bookings"

    station_id = Column(String(36), ForeignKey("charging_stations.id"), nullable=False, index=True)
    port_id = Column(String(36), ForeignKey("charging_ports.id"), nullable=False, index=True)
    customer_id = Column(String(36), ForeignKey("customers.id"), nullable=True)
    vehicle_id = Column(String(36), ForeignKey("vehicles.id"), nullable=True)
    
    booking_code = Column(String(50), unique=True, index=True, nullable=False)
    booking_date = Column(String(20), nullable=False)  # YYYY-MM-DD
    start_time = Column(String(20), nullable=False)  # HH:MM
    duration_minutes = Column(Integer, default=60, nullable=False)
    status = Column(String(50), default="CONFIRMED", nullable=False)  # PENDING, CONFIRMED, ACTIVE, COMPLETED, CANCELLED
    estimated_cost = Column(Float, default=18.5, nullable=False)
    notes = Column(Text, nullable=True)

    station = relationship("ChargingStation", back_populates="bookings")
    port = relationship("ChargingPort", back_populates="bookings")
    customer = relationship("Customer", back_populates="bookings")
    vehicle = relationship("Vehicle")
