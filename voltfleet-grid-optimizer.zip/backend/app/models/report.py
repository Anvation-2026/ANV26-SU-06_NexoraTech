from sqlalchemy import Column, String, ForeignKey, Text, JSON
from backend.app.models.base import BaseModel

class Report(BaseModel):
    __tablename__ = "reports"

    title = Column(String(255), nullable=False)
    report_type = Column(String(100), nullable=False)  # Fleet Utilization, Charging Sessions, Energy Consumption, Grid Performance, Station Utilization, Charging Cost, Customer Feedback, Executive Summary
    start_date = Column(String(30), nullable=False)
    end_date = Column(String(30), nullable=False)
    station_id = Column(String(36), ForeignKey("charging_stations.id"), nullable=True)
    vehicle_id = Column(String(36), ForeignKey("vehicles.id"), nullable=True)
    file_path = Column(String(255), nullable=True)
    status = Column(String(50), default="GENERATED", nullable=False)  # PENDING, GENERATED, FAILED
    summary_kpis = Column(JSON, nullable=True)
