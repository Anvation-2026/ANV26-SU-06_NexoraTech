from sqlalchemy import Column, String, Float, ForeignKey, DateTime, Boolean, Text, Integer
from sqlalchemy.orm import relationship
from backend.app.models.base import BaseModel

class GridTelemetry(BaseModel):
    __tablename__ = "grid_telemetry"

    total_capacity_kw = Column(Float, default=5000.0, nullable=False)
    current_grid_load_kw = Column(Float, default=2450.0, nullable=False)
    charging_load_kw = Column(Float, default=680.0, nullable=False)
    base_load_kw = Column(Float, default=1770.0, nullable=False)
    renewable_energy_kw = Column(Float, default=950.0, nullable=False)
    peak_demand_kw = Column(Float, default=3200.0, nullable=False)
    voltage_v = Column(Float, default=400.0, nullable=False)
    frequency_hz = Column(Float, default=50.02, nullable=False)
    power_factor = Column(Float, default=0.98, nullable=False)
    capacity_utilization_pct = Column(Float, default=49.0, nullable=False)
    is_simulated = Column(String(10), default="SIMULATED", nullable=False)

class GridAlert(BaseModel):
    __tablename__ = "grid_alerts"

    station_id = Column(String(36), ForeignKey("charging_stations.id"), nullable=True)
    severity = Column(String(50), default="WARNING", nullable=False)  # INFO, WARNING, CRITICAL
    alert_type = Column(String(100), nullable=False)  # HIGH_GRID_LOAD, VOLTAGE_ANOMALY, CHARGER_OVERLOAD, STATION_OFFLINE
    title = Column(String(255), nullable=False)
    message = Column(Text, nullable=False)
    status = Column(String(50), default="ACTIVE", nullable=False)  # ACTIVE, ACKNOWLEDGED, RESOLVED
    resolved_at = Column(DateTime(timezone=True), nullable=True)

class ElectricityPrice(BaseModel):
    __tablename__ = "electricity_prices"

    hour_of_day = Column(Integer, nullable=False)  # 0 to 23
    price_per_kwh = Column(Float, nullable=False)  # in USD / EUR
    period_type = Column(String(50), default="OFF_PEAK", nullable=False)  # OFF_PEAK, MID_PEAK, ON_PEAK
    currency = Column(String(10), default="USD", nullable=False)
