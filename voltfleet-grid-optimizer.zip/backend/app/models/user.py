from sqlalchemy import Column, String, Boolean, Text, ForeignKey, Integer, JSON
from sqlalchemy.orm import relationship
from backend.app.models.base import BaseModel

class User(BaseModel):
    __tablename__ = "users"

    email = Column(String(255), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(255), nullable=False)
    role = Column(String(50), default="FLEET_MANAGER", nullable=False)  # ADMIN, FLEET_MANAGER, STATION_OPERATOR, VIEWER
    is_active = Column(Boolean, default=True, nullable=False)
    phone = Column(String(50), nullable=True)

class Driver(BaseModel):
    __tablename__ = "drivers"

    name = Column(String(255), nullable=False)
    license_number = Column(String(100), unique=True, nullable=False)
    phone = Column(String(50), nullable=True)
    email = Column(String(255), nullable=True)
    status = Column(String(50), default="AVAILABLE", nullable=False)  # AVAILABLE, ON_TRIP, OFF_DUTY

    vehicles = relationship("Vehicle", back_populates="driver")

class Customer(BaseModel):
    __tablename__ = "customers"

    name = Column(String(255), nullable=False)
    email = Column(String(255), unique=True, index=True, nullable=False)
    phone = Column(String(50), nullable=True)
    loyalty_tier = Column(String(50), default="STANDARD", nullable=False)  # STANDARD, GOLD, PLATINUM

    bookings = relationship("Booking", back_populates="customer")
    feedback = relationship("CustomerFeedback", back_populates="customer")

class Notification(BaseModel):
    __tablename__ = "notifications"

    user_id = Column(String(36), ForeignKey("users.id"), nullable=True)
    title = Column(String(255), nullable=False)
    message = Column(Text, nullable=False)
    type = Column(String(50), default="INFO", nullable=False)  # INFO, WARNING, ALERT, SUCCESS
    is_read = Column(Boolean, default=False, nullable=False)

class SystemSetting(BaseModel):
    __tablename__ = "system_settings"

    key = Column(String(100), unique=True, index=True, nullable=False)
    value = Column(Text, nullable=False)
    category = Column(String(50), default="GENERAL", nullable=False)
    description = Column(String(255), nullable=True)
