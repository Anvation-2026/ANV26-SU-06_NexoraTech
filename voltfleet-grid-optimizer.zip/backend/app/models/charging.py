from sqlalchemy import Column, String, Float, Integer, ForeignKey, DateTime, Text
from sqlalchemy.orm import relationship
from backend.app.models.base import BaseModel

class ChargingStation(BaseModel):
    __tablename__ = "charging_stations"

    name = Column(String(255), nullable=False, index=True)
    code = Column(String(50), unique=True, index=True, nullable=False)
    address = Column(String(255), nullable=False)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    total_ports = Column(Integer, default=6, nullable=False)
    max_station_power_kw = Column(Float, default=350.0, nullable=False)
    grid_capacity_kw = Column(Float, default=500.0, nullable=False)
    current_load_kw = Column(Float, default=0.0, nullable=False)
    status = Column(String(50), default="ONLINE", nullable=False)  # ONLINE, DEGRADED, OFFLINE, MAINTENANCE
    price_per_kwh = Column(Float, default=0.28, nullable=False)
    connector_types = Column(String(255), default="CCS2, Type 2, NACS", nullable=False)

    ports = relationship("ChargingPort", back_populates="station", cascade="all, delete-orphan")
    bookings = relationship("Booking", back_populates="station")
    feedback = relationship("CustomerFeedback", back_populates="station")

class ChargingPort(BaseModel):
    __tablename__ = "charging_ports"

    station_id = Column(String(36), ForeignKey("charging_stations.id"), nullable=False, index=True)
    port_number = Column(String(50), nullable=False)  # Port 1, Port 2, etc.
    connector_type = Column(String(50), default="CCS2", nullable=False)  # CCS2, CHAdeMO, Type 2, NACS
    max_power_kw = Column(Float, default=150.0, nullable=False)
    current_power_kw = Column(Float, default=0.0, nullable=False)
    status = Column(String(50), default="AVAILABLE", nullable=False)  # AVAILABLE, BUSY, RESERVED, FAULTED, OFFLINE
    connected_vehicle_id = Column(String(36), ForeignKey("vehicles.id"), nullable=True)

    station = relationship("ChargingStation", back_populates="ports")
    connected_vehicle = relationship("Vehicle", foreign_keys=[connected_vehicle_id])
    sessions = relationship("ChargingSession", back_populates="port")
    bookings = relationship("Booking", back_populates="port")
    telemetry = relationship("ChargingTelemetry", back_populates="port", cascade="all, delete-orphan", order_by="desc(ChargingTelemetry.created_at)")

class ChargingSession(BaseModel):
    __tablename__ = "charging_sessions"

    port_id = Column(String(36), ForeignKey("charging_ports.id"), nullable=False, index=True)
    vehicle_id = Column(String(36), ForeignKey("vehicles.id"), nullable=False, index=True)
    start_time = Column(DateTime(timezone=True), nullable=False)
    end_time = Column(DateTime(timezone=True), nullable=True)
    start_soc = Column(Float, default=20.0, nullable=False)
    end_soc = Column(Float, nullable=True)
    energy_delivered_kwh = Column(Float, default=0.0, nullable=False)
    peak_power_kw = Column(Float, default=0.0, nullable=False)
    cost = Column(Float, default=0.0, nullable=False)
    status = Column(String(50), default="ACTIVE", nullable=False)  # ACTIVE, COMPLETED, INTERRUPTED, CANCELLED

    port = relationship("ChargingPort", back_populates="sessions")
    vehicle = relationship("Vehicle", back_populates="charging_sessions")
    telemetry = relationship("ChargingTelemetry", back_populates="session")

class ChargingTelemetry(BaseModel):
    __tablename__ = "charging_telemetry"

    port_id = Column(String(36), ForeignKey("charging_ports.id"), nullable=False, index=True)
    session_id = Column(String(36), ForeignKey("charging_sessions.id"), nullable=True, index=True)
    voltage_v = Column(Float, default=400.0, nullable=False)
    current_a = Column(Float, default=0.0, nullable=False)
    power_kw = Column(Float, default=0.0, nullable=False)
    energy_kwh = Column(Float, default=0.0, nullable=False)
    temperature_c = Column(Float, default=32.0, nullable=False)
    is_simulated = Column(String(10), default="SIMULATED", nullable=False)

    port = relationship("ChargingPort", back_populates="telemetry")
    session = relationship("ChargingSession", back_populates="telemetry")
