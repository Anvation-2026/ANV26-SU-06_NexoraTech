from sqlalchemy import Column, String, Float, ForeignKey, DateTime, Text, JSON
from sqlalchemy.orm import relationship
from backend.app.models.base import BaseModel

class OptimizationSchedule(BaseModel):
    __tablename__ = "optimization_schedules"

    vehicle_id = Column(String(36), ForeignKey("vehicles.id"), nullable=False, index=True)
    station_id = Column(String(36), ForeignKey("charging_stations.id"), nullable=True)
    
    current_soc = Column(Float, nullable=False)
    target_soc = Column(Float, nullable=False)
    battery_capacity = Column(Float, nullable=False)
    arrival_time = Column(DateTime(timezone=True), nullable=False)
    departure_time = Column(DateTime(timezone=True), nullable=False)
    charger_power = Column(Float, nullable=False)
    
    charging_start = Column(DateTime(timezone=True), nullable=False)
    charging_end = Column(DateTime(timezone=True), nullable=False)
    energy_required = Column(Float, nullable=False)
    estimated_cost = Column(Float, nullable=False)
    baseline_peak_load = Column(Float, nullable=False)
    optimized_peak_load = Column(Float, nullable=False)
    estimated_savings = Column(Float, nullable=False)
    schedule_intervals = Column(JSON, nullable=True)  # Detailed 15-min or 1-hr intervals
    status = Column(String(50), default="ACTIVE", nullable=False)  # ACTIVE, EXECUTED, CANCELLED

    vehicle = relationship("Vehicle", back_populates="optimization_schedules")
    station = relationship("ChargingStation")
