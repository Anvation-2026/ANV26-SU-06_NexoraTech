import numpy as np
from scipy.optimize import minimize, linprog
from datetime import datetime, timedelta, timezone
from typing import Dict, Any, List

def calculate_time_of_use_rates(hour: int) -> float:
    """
    Standard dynamic Time-Of-Use (TOU) tariff:
    - 00:00 - 06:00 (Night / Off-peak): $0.14 / kWh
    - 06:00 - 16:00 (Day / Mid-peak): $0.26 / kWh
    - 16:00 - 21:00 (Evening / On-peak): $0.48 / kWh
    - 21:00 - 24:00 (Night / Off-peak): $0.18 / kWh
    """
    if 0 <= hour < 6:
        return 0.14
    elif 6 <= hour < 16:
        return 0.26
    elif 16 <= hour < 21:
        return 0.48
    else:
        return 0.18

def optimize_charging_schedule(
    vehicle_id: str,
    current_soc: float,
    target_soc: float,
    battery_capacity: float,
    arrival_time: datetime,
    departure_time: datetime,
    charger_power: float = 150.0,
    station_capacity: float = 500.0,
    grid_capacity: float = 2000.0,
    electricity_price: float = 0.28,
    charging_priority: str = "COST_OPTIMAL"
) -> Dict[str, Any]:
    """
    SciPy optimization using SLSQP to minimize electricity cost and peak grid load
    while meeting state of charge requirements before departure time.
    """
    # 1. Validation & Energy requirement
    if target_soc <= current_soc:
        target_soc = min(100.0, current_soc + 20.0)

    energy_required = (max(0.0, target_soc - current_soc) / 100.0) * battery_capacity
    if energy_required <= 0.01:
        energy_required = 5.0  # minimal buffer

    # Ensure departure is after arrival
    if departure_time <= arrival_time:
        departure_time = arrival_time + timedelta(hours=4)

    total_hours = max(1.0, (departure_time - arrival_time).total_seconds() / 3600.0)
    
    # Discretize into 1-hour slots (or 15-min if duration is small)
    num_slots = max(1, int(np.ceil(total_hours)))
    dt = total_hours / num_slots  # duration per slot in hours

    # Time of use prices and baseline grid load for each slot
    prices = []
    base_grid_loads = []
    slot_times = []

    for i in range(num_slots):
        slot_t = arrival_time + timedelta(hours=i * dt)
        slot_times.append(slot_t)
        h = slot_t.hour
        price = calculate_time_of_use_rates(h)
        prices.append(price)
        # Typical diurnal grid load profile (kW)
        if 8 <= h <= 20:
            base_load = 1800.0 + 300.0 * np.sin((h - 8) / 12.0 * np.pi)
        else:
            base_load = 1200.0
        base_grid_loads.append(base_load)

    prices = np.array(prices)
    base_grid_loads = np.array(base_grid_loads)

    # Max power charging bound for each slot
    max_power = min(charger_power, station_capacity, grid_capacity)

    # Unoptimized / Baseline charging: Charge immediately at max rate until required energy is met
    baseline_power = np.zeros(num_slots)
    remaining_e = energy_required
    for i in range(num_slots):
        p = min(max_power, remaining_e / dt)
        baseline_power[i] = p
        remaining_e -= p * dt
        if remaining_e <= 0.001:
            break
    
    baseline_cost = float(np.sum(baseline_power * prices * dt))
    baseline_peak_load = float(np.max(base_grid_loads + baseline_power))

    # Objective function for SciPy SLSQP optimization
    # Variables: x = [P_0, P_1, ..., P_{num_slots-1}]
    def objective(x):
        # Cost term
        cost_term = np.sum(x * prices * dt)
        
        # Peak load penalty (smooth approximation of peak or quadratic deviation)
        total_loads = base_grid_loads + x
        peak_term = 0.05 * np.sum((total_loads / grid_capacity) ** 2)

        # Delay penalty (small bias to finish with buffer before departure)
        delay_weights = np.linspace(0.01, 0.05, num_slots)
        delay_term = np.sum(x * delay_weights * dt)

        if charging_priority == "SPEED_OPTIMAL":
            return 0.1 * cost_term + 10.0 * delay_term
        elif charging_priority == "PEAK_MINIMAL":
            return 0.2 * cost_term + 5.0 * peak_term
        else:  # COST_OPTIMAL / BALANCED
            return 1.0 * cost_term + 0.5 * peak_term + 0.05 * delay_term

    # Constraints:
    # 1. Total energy delivered == energy_required
    constraints = [
        {
            'type': 'eq',
            'fun': lambda x: np.sum(x * dt) - energy_required
        }
    ]

    # Bounds: 0 <= P_i <= max_power
    # Also cannot exceed station capacity or grid capacity
    bounds = [(0.0, max_power) for _ in range(num_slots)]

    # Initial guess: evenly spread charging
    avg_p = min(max_power, energy_required / total_hours)
    x0 = np.full(num_slots, avg_p)

    # Run SciPy Optimization
    res = minimize(
        objective,
        x0,
        method='SLSQP',
        bounds=bounds,
        constraints=constraints,
        options={'maxiter': 200, 'ftol': 1e-4}
    )

    if res.success and np.abs(np.sum(res.x * dt) - energy_required) < 1.0:
        opt_power = np.clip(res.x, 0.0, max_power)
        # Normalize slightly to ensure exact energy
        sum_e = np.sum(opt_power * dt)
        if sum_e > 0:
            opt_power = opt_power * (energy_required / sum_e)
    else:
        # Fallback to linear programming or smart off-peak distribution
        cheapest_indices = np.argsort(prices)
        opt_power = np.zeros(num_slots)
        rem = energy_required
        for idx in cheapest_indices:
            p = min(max_power, rem / dt)
            opt_power[idx] = p
            rem -= p * dt
            if rem <= 0.01:
                break

    optimized_cost = float(np.sum(opt_power * prices * dt))
    optimized_peak_load = float(np.max(base_grid_loads + opt_power))
    estimated_savings = max(0.0, baseline_cost - optimized_cost)

    # Determine start and end times of active charging
    active_slots = [i for i, p in enumerate(opt_power) if p > 1.0]
    if active_slots:
        charging_start = slot_times[active_slots[0]]
        charging_end = slot_times[active_slots[-1]] + timedelta(hours=dt)
    else:
        charging_start = arrival_time
        charging_end = arrival_time + timedelta(hours=energy_required / max_power)

    schedule_intervals = []
    for i in range(num_slots):
        st = slot_times[i]
        schedule_intervals.append({
            "slot_index": i,
            "timestamp": st.isoformat(),
            "hour_label": f"{st.strftime('%H:%M')}",
            "optimized_power_kw": round(float(opt_power[i]), 1),
            "baseline_power_kw": round(float(baseline_power[i]), 1),
            "electricity_price": round(float(prices[i]), 3),
            "base_grid_load_kw": round(float(base_grid_loads[i]), 1),
            "total_grid_load_kw": round(float(base_grid_loads[i] + opt_power[i]), 1)
        })

    return {
        "vehicle_id": vehicle_id,
        "charging_start": charging_start,
        "charging_end": charging_end,
        "energy_required": round(float(energy_required), 2),
        "estimated_cost": round(float(optimized_cost), 2),
        "baseline_cost": round(float(baseline_cost), 2),
        "baseline_peak_load": round(float(baseline_peak_load), 1),
        "optimized_peak_load": round(float(optimized_peak_load), 1),
        "estimated_savings": round(float(estimated_savings), 2),
        "schedule_intervals": schedule_intervals
    }
