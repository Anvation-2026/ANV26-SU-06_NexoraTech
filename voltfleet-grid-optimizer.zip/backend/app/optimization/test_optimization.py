import pytest
from datetime import datetime, timedelta, timezone
from backend.app.optimization.scheduler import optimize_charging_schedule

def test_optimize_charging_schedule_basic():
    now = datetime.now(timezone.utc)
    arrival = now
    departure = now + timedelta(hours=8)
    
    result = optimize_charging_schedule(
        vehicle_id="veh-test-01",
        current_soc=20.0,
        target_soc=80.0,
        battery_capacity=100.0,
        arrival_time=arrival,
        departure_time=departure,
        charger_power=150.0,
        station_capacity=500.0,
        grid_capacity=2500.0,
        charging_priority="COST_OPTIMAL"
    )

    assert result["vehicle_id"] == "veh-test-01"
    assert result["energy_required"] == pytest.approx(60.0, rel=1e-2)
    assert result["estimated_cost"] > 0
    assert result["optimized_peak_load"] <= result["baseline_peak_load"] + 10.0
    assert len(result["schedule_intervals"]) == 8
    assert result["estimated_savings"] >= 0.0

def test_optimize_charging_schedule_fast_charging():
    now = datetime.now(timezone.utc)
    arrival = now
    departure = now + timedelta(hours=3)

    result = optimize_charging_schedule(
        vehicle_id="veh-test-02",
        current_soc=40.0,
        target_soc=90.0,
        battery_capacity=80.0,
        arrival_time=arrival,
        departure_time=departure,
        charger_power=100.0,
        charging_priority="SPEED_OPTIMAL"
    )

    assert result["energy_required"] == pytest.approx(40.0, rel=1e-2)
    assert result["charging_start"] <= result["charging_end"]
