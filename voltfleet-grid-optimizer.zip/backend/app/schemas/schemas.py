from typing import Optional, List, Any, Dict
from pydantic import BaseModel, EmailStr, Field
from datetime import datetime

# ================= AUTH SCHEMAS =================
class UserBase(BaseModel):
    email: str
    full_name: str
    role: str = "FLEET_MANAGER"  # ADMIN, FLEET_MANAGER, STATION_OPERATOR, VIEWER
    phone: Optional[str] = None

class UserCreate(UserBase):
    password: str

class UserLogin(BaseModel):
    email: str
    password: str
    remember_me: Optional[bool] = False

class UserResponse(UserBase):
    id: str
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse

# ================= VEHICLE SCHEMAS =================
class VehicleBase(BaseModel):
    vin: str
    registration_number: str
    make: str
    model: str
    year: int = 2024
    battery_capacity: float
    current_soc: float = 85.0
    target_soc: float = 90.0
    status: str = "AVAILABLE"  # AVAILABLE, ON_TRIP, CHARGING, IDLE, MAINTENANCE, OFFLINE
    charging_status: str = "DISCONNECTED"
    current_location: str = "Central Fleet Depot"
    latitude: float = 37.7749
    longitude: float = -122.4194
    odometer_km: float = 12500.0
    max_charge_rate_kw: float = 150.0
    driver_id: Optional[str] = None

class VehicleCreate(VehicleBase):
    pass

class VehicleUpdate(BaseModel):
    registration_number: Optional[str] = None
    make: Optional[str] = None
    model: Optional[str] = None
    battery_capacity: Optional[float] = None
    current_soc: Optional[float] = None
    target_soc: Optional[float] = None
    status: Optional[str] = None
    charging_status: Optional[str] = None
    current_location: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    driver_id: Optional[str] = None
    max_charge_rate_kw: Optional[float] = None

class DriverSimple(BaseModel):
    id: str
    name: str
    license_number: str
    phone: Optional[str] = None
    status: str

    class Config:
        from_attributes = True

class VehicleResponse(VehicleBase):
    id: str
    created_at: datetime
    updated_at: datetime
    driver: Optional[DriverSimple] = None

    class Config:
        from_attributes = True

# ================= CHARGING STATIONS & PORTS =================
class ChargingPortResponse(BaseModel):
    id: str
    station_id: str
    port_number: str
    connector_type: str
    max_power_kw: float
    current_power_kw: float
    status: str
    connected_vehicle_id: Optional[str] = None
    connected_vehicle_soc: Optional[float] = None
    connected_vehicle_reg: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True

class ChargingStationResponse(BaseModel):
    id: str
    name: str
    code: str
    address: str
    latitude: float
    longitude: float
    total_ports: int
    available_ports: int = 0
    busy_ports: int = 0
    max_station_power_kw: float
    grid_capacity_kw: float
    current_load_kw: float
    status: str
    price_per_kwh: float
    connector_types: str
    ports: Optional[List[ChargingPortResponse]] = []
    created_at: datetime

    class Config:
        from_attributes = True

class ChargingSessionResponse(BaseModel):
    id: str
    port_id: str
    vehicle_id: str
    vehicle_reg: Optional[str] = None
    station_name: Optional[str] = None
    port_number: Optional[str] = None
    start_time: datetime
    end_time: Optional[datetime] = None
    start_soc: float
    end_soc: Optional[float] = None
    energy_delivered_kwh: float
    peak_power_kw: float
    cost: float
    status: str

    class Config:
        from_attributes = True

# ================= GRID & TELEMETRY =================
class GridCurrentResponse(BaseModel):
    total_capacity_kw: float
    current_grid_load_kw: float
    charging_load_kw: float
    base_load_kw: float
    renewable_energy_kw: float
    peak_demand_kw: float
    voltage_v: float
    frequency_hz: float
    power_factor: float
    capacity_utilization_pct: float
    is_simulated: str = "SIMULATED"
    updated_at: datetime

class GridAlertResponse(BaseModel):
    id: str
    station_id: Optional[str] = None
    severity: str
    alert_type: str
    title: str
    message: str
    status: str
    created_at: datetime

    class Config:
        from_attributes = True

# ================= SCI-PY OPTIMIZATION =================
class OptimizationRequest(BaseModel):
    vehicle_id: str
    current_soc: float
    target_soc: float
    battery_capacity: float
    arrival_time: datetime
    departure_time: datetime
    charger_power: float = 150.0
    station_capacity: float = 500.0
    grid_capacity: float = 2000.0
    electricity_price: float = 0.28
    charging_priority: str = "COST_OPTIMAL"  # COST_OPTIMAL, SPEED_OPTIMAL, BALANCED

class OptimizationResponse(BaseModel):
    vehicle_id: str
    charging_start: datetime
    charging_end: datetime
    energy_required: float
    estimated_cost: float
    baseline_peak_load: float
    optimized_peak_load: float
    estimated_savings: float
    schedule_intervals: Optional[List[Dict[str, Any]]] = []

# ================= BOOKING =================
class BookingCreate(BaseModel):
    station_id: str
    port_id: str
    vehicle_id: Optional[str] = None
    booking_date: str
    start_time: str
    duration_minutes: int = 60
    notes: Optional[str] = None

class BookingResponse(BaseModel):
    id: str
    station_id: str
    station_name: Optional[str] = None
    port_id: str
    port_number: Optional[str] = None
    booking_code: str
    booking_date: str
    start_time: str
    duration_minutes: int
    status: str
    estimated_cost: float
    notes: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True

# ================= FEEDBACK =================
class FeedbackCreate(BaseModel):
    station_id: str
    customer_name: Optional[str] = "EV Fleet Operator"
    rating: int = Field(ge=1, le=5)
    category: str  # CHARGING_SPEED, AVAILABILITY, PAYMENT, APP_EXPERIENCE, LOCATION, HARDWARE, CUSTOMER_SERVICE, OTHER
    comment: str

class FeedbackResponse(BaseModel):
    id: str
    station_id: str
    station_name: Optional[str] = None
    customer_name: str
    rating: int
    category: str
    comment: str
    status: str
    created_at: datetime

    class Config:
        from_attributes = True

# ================= REPORTS =================
class ReportGenerateRequest(BaseModel):
    report_type: str  # Fleet Utilization, Charging Sessions, Energy Consumption, Grid Performance, Station Utilization, Charging Cost, Customer Feedback, Executive Summary
    start_date: str
    end_date: str
    station_id: Optional[str] = None
    vehicle_id: Optional[str] = None

class ReportResponse(BaseModel):
    id: str
    title: str
    report_type: str
    start_date: str
    end_date: str
    station_id: Optional[str] = None
    vehicle_id: Optional[str] = None
    status: str
    file_path: Optional[str] = None
    summary_kpis: Optional[Dict[str, Any]] = None
    created_at: datetime

    class Config:
        from_attributes = True
