import os
from pydantic_settings import BaseSettings
from typing import List, Any

class Settings(BaseSettings):
    PROJECT_NAME: str = "EV Fleet & Charging Grid Management System"
    API_V1_STR: str = "/api"
    DATABASE_URL: str = os.getenv(
        "DATABASE_URL", 
        "postgresql+psycopg://postgres:password@localhost:5432/ev_grid"
    )
    JWT_SECRET: str = os.getenv("JWT_SECRET", "super-secret-jwt-token-ev-fleet-2026-production-key")
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24  # 1 day
    CORS_ORIGINS: Any = ["*"]

    class Config:
        env_file = ".env"
        extra = "allow"

settings = Settings()
