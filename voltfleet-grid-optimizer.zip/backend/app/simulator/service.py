import asyncio
import logging
import random
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from typing import Dict, Any, List
from backend.app.websocket.manager import ws_manager
from backend.app.core.database import SessionLocal
from backend.app.models.fleet import Vehicle
from backend.app.models.charging import ChargingPort, ChargingStation, ChargingSession
from backend.app.models.grid import GridTelemetry, GridAlert

logger = logging.getLogger("uvicorn.error")

class TelemetryProvider(ABC):
    """
    Standard interface allowing real OCPP / IoT chargers or simulators
    to stream live telemetry to the EV management platform.
    """
    @abstractmethod
    async def step(self):
        pass

class SimulatorService(TelemetryProvider):
    def __init__(self):
        self._running = False
        self._task: asyncio.Task = None

    async def start(self):
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._run_loop())
        logger.info("Live Telemetry Simulation Service started.")

    async def stop(self):
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        logger.info("Live Telemetry Simulation Service stopped.")

    async def _run_loop(self):
        while self._running:
            try:
                await self.step()
            except Exception as e:
                logger.error(f"Error in telemetry simulator step: {e}")
            await asyncio.sleep(3.0)  # Emit telemetry updates every 3 seconds

    async def step(self):
        db = SessionLocal()
        try:
            # 1. Update Grid Telemetry
            base_kw = 1800.0 + random.uniform(-40.0, 40.0)
            charging_kw = 640.0 + random.uniform(-30.0, 30.0)
            renew_kw = 980.0 + random.uniform(-20.0, 20.0)
            total_load_kw = base_kw + charging_kw
            voltage_v = round(399.0 + random.uniform(-1.5, 1.8), 1)
            freq_hz = round(50.0 + random.uniform(-0.04, 0.04), 2)
            power_factor = round(0.98 + random.uniform(-0.01, 0.01), 2)
            utilization_pct = round((total_load_kw / 5000.0) * 100.0, 1)

            grid_data = {
                "total_capacity_kw": 5000.0,
                "current_grid_load_kw": round(total_load_kw, 1),
                "charging_load_kw": round(charging_kw, 1),
                "base_load_kw": round(base_kw, 1),
                "renewable_energy_kw": round(renew_kw, 1),
                "peak_demand_kw": 3250.0,
                "voltage_v": voltage_v,
                "frequency_hz": freq_hz,
                "power_factor": power_factor,
                "capacity_utilization_pct": utilization_pct,
                "is_simulated": "SIMULATED",
                "timestamp": datetime.now(timezone.utc).isoformat()
            }
            await ws_manager.broadcast("grid.updated", grid_data)

            # 2. Update Charging Ports & Connected Vehicles
            busy_ports = db.query(ChargingPort).filter(ChargingPort.status == "BUSY").all()
            for port in busy_ports[:6]:
                # Slight power oscillation
                power_fluctuation = random.uniform(-2.5, 2.5)
                new_power = max(20.0, min(port.max_power_kw, port.current_power_kw + power_fluctuation))
                port.current_power_kw = round(new_power, 1)

                vehicle = None
                if port.connected_vehicle_id:
                    vehicle = db.query(Vehicle).filter(Vehicle.id == port.connected_vehicle_id).first()
                    if vehicle and vehicle.current_soc < vehicle.target_soc:
                        # Increment SOC slightly
                        vehicle.current_soc = min(100.0, round(vehicle.current_soc + 0.1, 2))
                        if vehicle.current_soc >= vehicle.target_soc:
                            vehicle.charging_status = "COMPLETE"
                            port.status = "AVAILABLE"
                            port.current_power_kw = 0.0

                db.commit()

                port_telemetry = {
                    "port_id": port.id,
                    "port_number": port.port_number,
                    "station_id": port.station_id,
                    "current_power_kw": port.current_power_kw,
                    "max_power_kw": port.max_power_kw,
                    "status": port.status,
                    "voltage_v": voltage_v,
                    "current_a": round((port.current_power_kw * 1000.0) / voltage_v, 1) if voltage_v > 0 else 0,
                    "vehicle_soc": vehicle.current_soc if vehicle else None,
                    "vehicle_id": vehicle.id if vehicle else None,
                    "vehicle_reg": vehicle.registration_number if vehicle else None,
                    "is_simulated": "SIMULATED",
                    "timestamp": datetime.now(timezone.utc).isoformat()
                }
                await ws_manager.broadcast("charger.updated", port_telemetry)

                if vehicle:
                    await ws_manager.broadcast("vehicle.updated", {
                        "id": vehicle.id,
                        "registration_number": vehicle.registration_number,
                        "current_soc": vehicle.current_soc,
                        "charging_status": vehicle.charging_status,
                        "is_simulated": "SIMULATED"
                    })

            # Random rare alert broadcast
            if random.random() < 0.05:
                alert_payload = {
                    "title": "Grid Voltage Fluctuation Restabilized",
                    "severity": "INFO",
                    "message": f"Substation bus voltage stabilized at {voltage_v} V with power factor {power_factor}.",
                    "timestamp": datetime.now(timezone.utc).isoformat()
                }
                await ws_manager.broadcast("grid.alert", alert_payload)

        except Exception as ex:
            db.rollback()
            logger.error(f"Error updating simulated telemetry in DB: {ex}")
        finally:
            db.close()

simulator = SimulatorService()
