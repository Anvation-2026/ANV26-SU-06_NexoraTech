# EV Fleet & Charging Grid Management System

A production-ready, full-stack enterprise EV fleet, charging-station, and electrical grid energy-management control center. Features real-time multi-depot fleet monitoring, a synchronized Live Digital Twin over WebSockets, mathematical charging optimization using SciPy (`scipy.optimize`), automated PDF audit reporting with ReportLab, and a PostgreSQL database accessed via SQLAlchemy 2.x and Alembic.

---

## Architecture Overview

```
             ┌─────────────────────────────────────────────────────────┐
             │                     React 19 Frontend                   │
             │   Vite + TypeScript + Tailwind CSS + TanStack Query     │
             │           Recharts + Motion + Lucide React              │
             └────────────────────────────┬────────────────────────────┘
                                          │  REST / WebSockets
                                          ▼
             ┌─────────────────────────────────────────────────────────┐
             │                  Python FastAPI Backend                 │
             │       JWT Auth + Role-Based Access Control (RBAC)       │
             │         Telemetry Simulator / OCPP 2.0.1 Ready          │
             │          SciPy Constrained Optimization (SLSQP)         │
             │          ReportLab PDF Generation Subsystem             │
             └──────────────┬───────────────────────────┬──────────────┘
                            │                           │
            SQLAlchemy 2.0  │                           │ Background
            psycopg3 Driver │                           │ Simulation
                            ▼                           ▼
             ┌───────────────────────────┐    ┌────────────────────────┐
             │    PostgreSQL Database    │    │  WebSocket Telemetry   │
             │  Alembic Migrations / UUID│    │     /ws/live Stream    │
             └───────────────────────────┘    └────────────────────────┘
```

---

## Technology Stack

- **Frontend:**
  - React 19, TypeScript, Vite
  - Tailwind CSS
  - Motion (Framer Motion v12)
  - React Router v7
  - TanStack Query v5
  - Recharts v3
  - Lucide React

- **Backend:**
  - Python 3.10+ / 3.11+
  - FastAPI & Pydantic v2
  - SQLAlchemy 2.0 & Alembic
  - psycopg 3 driver
  - SciPy (`scipy.optimize.minimize` with SLSQP)
  - ReportLab 5.0
  - Native bcrypt password hashing & python-jose JWT
  - WebSockets

- **Database:**
  - PostgreSQL 15+

---

## Prerequisites

1. **Node.js**: v18.0.0 or higher
2. **Python**: v3.10 or higher
3. **PostgreSQL**: v14 or higher

---

## Installation & Setup

### 1. PostgreSQL Database Setup

```bash
# Start PostgreSQL service
sudo service postgresql start

# Create database and configure password
sudo -u postgres psql -c "ALTER USER postgres WITH PASSWORD 'password';"
sudo -u postgres psql -c "CREATE DATABASE ev_grid;"
```

### 2. Environment Variables

Create a `.env` file in the root directory:

```env
DATABASE_URL=postgresql+psycopg://postgres:password@localhost:5432/ev_grid
JWT_SECRET=super-secret-jwt-token-ev-fleet-2026-production-key
CORS_ORIGINS="*"
```

### 3. Backend Setup

```bash
# Install Python dependencies
pip install -r backend/requirements.txt

# Run Alembic migrations
PYTHONPATH=. alembic upgrade head

# Seed initial database records (50 vehicles, 10 stations, 60 ports, telemetry, feedback)
PYTHONPATH=. python3 backend/seed.py
```

### 4. Running the Tests

```bash
# Run SciPy optimization and full backend pytest suite
PYTHONPATH=. pytest backend/tests/test_backend.py
```

### 5. Running the Application

In development, the full-stack server runs Express gateway + Vite + FastAPI automatically:

```bash
# Install Node dependencies
npm install

# Start development server on port 3000
npm run dev
```

Or run backend and frontend separately:

```bash
# Terminal 1: Backend
PYTHONPATH=. uvicorn backend.app.main:app --host 0.0.0.0 --port 8000 --reload

# Terminal 2: Frontend
npm run dev
```

---

## Default User Accounts & Roles

| Role | Email | Password |
|---|---|---|
| **ADMIN** | `admin@evfleet.io` | `password123` |
| **FLEET_MANAGER** | `manager@evfleet.io` | `password123` |
| **STATION_OPERATOR** | `operator@evfleet.io` | `password123` |
| **VIEWER** | `viewer@evfleet.io` | `password123` |

Quick 1-click login buttons for each role are provided directly on the Login page.

---

## Core Features & Modules

1. **Main Operational Dashboard (`/`)**:
   - 9 Live KPI cards: Total Vehicles, Active Vehicles, Charging Vehicles, Available Ports, Busy Ports, Stations, Energy Delivered Today, Current Grid Load, Charging Cost Today.
   - 6 Interactive Recharts: Fleet utilization, hourly energy, charging power demand, substation total grid load, dynamic electricity cost, station hub occupancy.
   - Live recent charging sessions and substation grid alerts.

2. **Fleet Asset Management (`/fleet`)**:
   - Filter, search, and sort 50 commercial EV fleet assets (Tesla Semi, Model Y, Ford E-Transit, Rivian EDV 700, Mercedes eSprinter, Volvo VNR Electric).
   - Real-time battery SOC indicators with color thresholds.
   - Add new vehicle modal, edit vehicle modal, deactivate asset.
   - Vehicle drawer with historical charging sessions and telemetry logs.

3. **Live Digital Twin (`/digital-twin`)**:
   - Synchronized visual hierarchy: Main Utility Substation &rarr; Superhub Stations &rarr; DC Fast Ports &rarr; Connected Fleet EVs.
   - Live WebSocket stream (`/ws/live`) with voltage, current, power factor, and thermal metrics.
   - Marked clearly as "SIMULATED (OCPP v2.0.1 Ready)".

4. **Charging Ports Infrastructure (`/ports`)**:
   - Status breakdown: Available, Busy, Reserved, Faulted, Offline.
   - Card grid with real-time connector type, power rating, connected vehicle registration, and duration.
   - Real-time inspection drawer.

5. **Substation Grid Monitor (`/grid`)**:
   - 10 key metric dials: Total Capacity (5,000 kW), Current Load, Charging Load, Base Load, Solar Generation, Peak Demand, Voltage, Frequency, Power Factor, Utilization.
   - 24-hour load superposition charts (Base Load vs EV Charging).
   - Protective relay alerts with acknowledge/resolve action.

6. **SciPy Mathematical Charging Optimization (`/optimization`)**:
   - Discretized constrained optimization using `scipy.optimize.minimize` (SLSQP).
   - Minimizes electricity cost with dynamic Time-Of-Use (TOU) tariffs ($0.14 - $0.48/kWh).
   - Eliminates peak demand spikes by smoothly spreading charging windows.
   - Side-by-side comparison of baseline peak vs optimized peak load, estimated savings ($), and interval chart.

7. **Nearby Stations & Pre-Booking (`/stations`)**:
   - Interactive list & map view of 10 San Francisco Bay Area transit hubs.
   - "NAVIGATE" button linking to Google Maps with exact coordinates.
   - 5-step Pre-Booking workflow: Select Hub &rarr; Stall &rarr; Date &rarr; Time &rarr; Duration &rarr; Guaranteed Bay Reservation.

8. **Driver & Operator Feedback (`/feedback`)**:
   - Average satisfaction ratings, 5-star distribution breakdowns, and categories (Charging Speed, Stall Availability, Billing, Hardware, etc.).
   - Submit new verified review form.

9. **PDF Reports Generator (`/reports`)**:
   - 8 report types: Fleet Utilization, Charging Sessions, Energy Consumption, Grid Performance, Station Utilization, Charging Cost, Customer Feedback, Executive Summary.
   - Generates certified PDFs on the fly using Python ReportLab.
   - In-app preview and instant download.

10. **System Settings & Parameters (`/settings`)**:
    - Configure transformer threshold alarms, default SOC targets, automated SciPy dispatching, notification channels, and session security policies.

---

## Production Build

```bash
npm run build
npm run start
```
