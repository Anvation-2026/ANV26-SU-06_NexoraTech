import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = process.env.VITE_SUPABASE_URL || 'https://vuqiugfjeipemsacoxek.supabase.co';
const SUPABASE_KEY = process.env.VITE_SUPABASE_ANON_KEY || 'sb_publishable_D0OdLBVLSjltGkdOsBliBg_offrEKCM';

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

async function seed() {
  console.log(`Connecting to Supabase at ${SUPABASE_URL}...`);

  // 1. Stations
  const stationsData = [
    { name: 'Metro Downtown Superhub', code: 'ST-DT-01', address: '100 Market St, Financial District', latitude: 37.7935, longitude: -122.3970, total_ports: 8, max_station_power_kw: 350.0, grid_capacity_kw: 600.0, current_load_kw: 185.0, status: 'ONLINE', price_per_kwh: 0.28, connector_types: 'CCS2, NACS, Type 2' },
    { name: 'Bay Bridge Logistics Depot', code: 'ST-BB-02', address: '850 Embarcadero Way, Port Access', latitude: 37.7885, longitude: -122.3890, total_ports: 6, max_station_power_kw: 300.0, grid_capacity_kw: 500.0, current_load_kw: 150.0, status: 'ONLINE', price_per_kwh: 0.26, connector_types: 'CCS2, CHAdeMO' },
    { name: 'Silicon Gateway Transit Park', code: 'ST-SG-03', address: '4200 Silicon Ave, South Hub', latitude: 37.7650, longitude: -122.4050, total_ports: 6, max_station_power_kw: 250.0, grid_capacity_kw: 450.0, current_load_kw: 120.0, status: 'ONLINE', price_per_kwh: 0.29, connector_types: 'CCS2, NACS' },
    { name: 'Pacific Heights FastCharge', code: 'ST-PH-04', address: '2100 California St, Central', latitude: 37.7890, longitude: -122.4280, total_ports: 6, max_station_power_kw: 200.0, grid_capacity_kw: 400.0, current_load_kw: 0.0, status: 'ONLINE', price_per_kwh: 0.32, connector_types: 'CCS2, Type 2' },
    { name: 'Golden Gate Fleet Terminal', code: 'ST-GG-05', address: '1500 Marina Blvd, North Gate', latitude: 37.8040, longitude: -122.4410, total_ports: 6, max_station_power_kw: 350.0, grid_capacity_kw: 600.0, current_load_kw: 160.0, status: 'ONLINE', price_per_kwh: 0.27, connector_types: 'CCS2, NACS' },
    { name: 'Mission Valley Freight Port', code: 'ST-MV-06', address: '2600 Mission St, Transport Zone', latitude: 37.7550, longitude: -122.4180, total_ports: 6, max_station_power_kw: 300.0, grid_capacity_kw: 550.0, current_load_kw: 65.0, status: 'ONLINE', price_per_kwh: 0.25, connector_types: 'CCS2, CHAdeMO' },
    { name: 'Airport Cargo Express Depot', code: 'ST-AC-07', address: '700 Airport Blvd, Cargo Wing', latitude: 37.6250, longitude: -122.3800, total_ports: 6, max_station_power_kw: 400.0, grid_capacity_kw: 750.0, current_load_kw: 0.0, status: 'ONLINE', price_per_kwh: 0.24, connector_types: 'CCS2, NACS' },
    { name: 'Sunset District Hub', code: 'ST-SD-08', address: '1900 19th Ave, Westside', latitude: 37.7490, longitude: -122.4760, total_ports: 6, max_station_power_kw: 200.0, grid_capacity_kw: 400.0, current_load_kw: 0.0, status: 'ONLINE', price_per_kwh: 0.30, connector_types: 'CCS2, Type 2' },
    { name: 'Civic Center Fleet Center', code: 'ST-CC-09', address: '400 McAllister St, Government Core', latitude: 37.7800, longitude: -122.4190, total_ports: 5, max_station_power_kw: 250.0, grid_capacity_kw: 450.0, current_load_kw: 0.0, status: 'ONLINE', price_per_kwh: 0.28, connector_types: 'CCS2, NACS' },
    { name: 'Presidio Green Energy Park', code: 'ST-PG-10', address: '120 Lincoln Blvd, Presidio Ecozone', latitude: 37.7990, longitude: -122.4650, total_ports: 5, max_station_power_kw: 250.0, grid_capacity_kw: 450.0, current_load_kw: 0.0, status: 'ONLINE', price_per_kwh: 0.27, connector_types: 'CCS2, Type 2, NACS' },
  ];

  const { data: existingStations } = await supabase.from('charging_stations').select('id, code');
  const existingCodes = new Set(existingStations?.map((s) => s.code) || []);
  const stationIdMap = new Map();
  existingStations?.forEach((s) => stationIdMap.set(s.code, s.id));

  for (const s of stationsData) {
    if (!existingCodes.has(s.code)) {
      const { data, error } = await supabase.from('charging_stations').insert(s).select('id, code');
      if (data && data[0]) {
        stationIdMap.set(data[0].code, data[0].id);
      }
    }
  }
  console.log(`Charging Stations verified: ${stationIdMap.size}`);

  // 2. Drivers
  const driversData = [
    { name: 'Liam Nelson', license_number: 'DL-CA-100001', phone: '+1 (555) 019-1001', email: 'liam.nelson@fleetdriver.org', status: 'AVAILABLE' },
    { name: 'Emma Watson', license_number: 'DL-CA-100002', phone: '+1 (555) 019-1002', email: 'emma.watson@fleetdriver.org', status: 'ON_TRIP' },
    { name: 'Noah Patel', license_number: 'DL-CA-100003', phone: '+1 (555) 019-1003', email: 'noah.patel@fleetdriver.org', status: 'AVAILABLE' },
    { name: 'Olivia Chen', license_number: 'DL-CA-100004', phone: '+1 (555) 019-1004', email: 'olivia.chen@fleetdriver.org', status: 'ON_TRIP' },
    { name: 'William Davis', license_number: 'DL-CA-100005', phone: '+1 (555) 019-1005', email: 'william.davis@fleetdriver.org', status: 'AVAILABLE' },
    { name: 'Sophia Martinez', license_number: 'DL-CA-100006', phone: '+1 (555) 019-1006', email: 'sophia.martinez@fleetdriver.org', status: 'ON_TRIP' },
    { name: 'James Wilson', license_number: 'DL-CA-100007', phone: '+1 (555) 019-1007', email: 'james.wilson@fleetdriver.org', status: 'AVAILABLE' },
    { name: 'Isabella Taylor', license_number: 'DL-CA-100008', phone: '+1 (555) 019-1008', email: 'isabella.taylor@fleetdriver.org', status: 'ON_TRIP' },
    { name: 'Benjamin Anderson', license_number: 'DL-CA-100009', phone: '+1 (555) 019-1009', email: 'benjamin.anderson@fleetdriver.org', status: 'AVAILABLE' },
    { name: 'Mia Thomas', license_number: 'DL-CA-100010', phone: '+1 (555) 019-1010', email: 'mia.thomas@fleetdriver.org', status: 'AVAILABLE' },
  ];

  const { data: existingDrivers } = await supabase.from('drivers').select('id, license_number');
  const existingLicense = new Set(existingDrivers?.map((d) => d.license_number) || []);
  const driverIds = existingDrivers?.map((d) => d.id) || [];

  for (const d of driversData) {
    if (!existingLicense.has(d.license_number)) {
      const { data } = await supabase.from('drivers').insert(d).select('id');
      if (data && data[0]) driverIds.push(data[0].id);
    }
  }
  console.log(`Drivers verified: ${driverIds.length}`);

  // 3. Charging Ports
  const { data: existingPorts } = await supabase.from('charging_ports').select('id');
  const portIds = existingPorts?.map((p) => p.id) || [];

  if (portIds.length < 50) {
    const connectorOptions = ['CCS2', 'NACS', 'Type 2', 'CHAdeMO'];
    let pIdx = 1;
    for (const [code, stId] of stationIdMap.entries()) {
      for (let pNum = 1; pNum <= 6; pNum++) {
        const cType = connectorOptions[(pNum - 1) % connectorOptions.length];
        const availableIndices = [2, 3, 6, 9, 12, 15, 20, 25, 30, 35];
        let pStatus = availableIndices.includes(pIdx) ? 'AVAILABLE' : 'BUSY';
        let currKw = pStatus === 'BUSY' ? 85.0 : 0.0;
        if ([5, 17].includes(pIdx)) {
          pStatus = 'RESERVED';
          currKw = 0.0;
        }

        const { data } = await supabase
          .from('charging_ports')
          .insert({
            station_id: stId,
            port_number: `Port ${pNum < 10 ? '0' : ''}${pNum}`,
            connector_type: cType,
            max_power_kw: pNum <= 4 ? 150.0 : 350.0,
            current_power_kw: currKw,
            status: pStatus,
          })
          .select('id');

        if (data && data[0]) portIds.push(data[0].id);
        pIdx++;
      }
    }
  }
  console.log(`Charging Ports verified: ${portIds.length}`);

  // 4. Vehicles (50 commercial fleet assets)
  const { data: existingVehicles } = await supabase.from('vehicles').select('id, registration_number');
  const existingReg = new Set(existingVehicles?.map((v) => v.registration_number) || []);
  const vehicleIds = existingVehicles?.map((v) => v.id) || [];

  const makesModels = [
    ['Tesla', 'Semi', 800.0, 2024],
    ['Tesla', 'Model Y Commercial', 75.0, 2023],
    ['Ford', 'E-Transit 350', 68.0, 2024],
    ['Rivian', 'EDV 700 Delivery', 135.0, 2024],
    ['Mercedes-Benz', 'eSprinter Cargo', 113.0, 2024],
    ['Volvo', 'VNR Electric Truck', 565.0, 2023],
    ['BrightDrop', 'Zevo 600', 165.0, 2024],
    ['BYD', '8TT Electric Semi', 422.0, 2024],
  ];

  const stIdList = Array.from(stationIdMap.values());

  if (vehicleIds.length < 50) {
    for (let i = 1; i <= 50; i++) {
      const reg = `EV-FLT-${100 + i}`;
      if (existingReg.has(reg)) continue;

      const mm = makesModels[(i - 1) % makesModels.length];
      let soc = Math.round((25.0 + Math.random() * 70.0) * 10) / 10;
      let status = 'AVAILABLE';
      let chargingStatus = 'DISCONNECTED';

      if (i <= 10) {
        status = 'CHARGING';
        chargingStatus = 'CHARGING';
        soc = Math.round((22.0 + Math.random() * 45.0) * 10) / 10;
      } else if (i % 5 === 0) {
        status = 'ON_TRIP';
      } else if (i % 12 === 0) {
        status = 'MAINTENANCE';
      } else if (i % 25 === 0) {
        status = 'IDLE';
      }

      const { data } = await supabase
        .from('vehicles')
        .insert({
          vin: `1FTNE3Y8${i < 10 ? '0' : ''}${i}PKA${10000 + i}`,
          registration_number: reg,
          make: mm[0],
          model: mm[1],
          year: mm[3],
          battery_capacity: mm[2],
          current_soc: soc,
          target_soc: 90.0,
          status,
          charging_status: chargingStatus,
          current_location: status === 'ON_TRIP' ? 'Active Delivery Corridor' : 'Central Fleet Depot',
          latitude: 37.7749 + (Math.random() - 0.5) * 0.1,
          longitude: -122.4194 + (Math.random() - 0.5) * 0.1,
          odometer_km: Math.round(8000.0 + i * 450.0),
          max_charge_rate_kw: mm[2] < 200 ? 150.0 : 350.0,
          driver_id: driverIds.length > 0 && i % 2 === 0 ? driverIds[(i - 1) % driverIds.length] : null,
          station_id: stIdList.length > 0 ? stIdList[(i - 1) % stIdList.length] : null,
        })
        .select('id');

      if (data && data[0]) vehicleIds.push(data[0].id);
    }
  }
  console.log(`Vehicles verified: ${vehicleIds.length}`);

  // 5. Grid Telemetry
  const { data: existingGrid } = await supabase.from('grid_telemetry').select('id');
  if (!existingGrid || existingGrid.length === 0) {
    await supabase.from('grid_telemetry').insert({
      total_capacity_kw: 5000.0,
      current_grid_load_kw: 2450.0,
      charging_load_kw: 680.0,
      base_load_kw: 1770.0,
      renewable_energy_kw: 950.0,
      peak_demand_kw: 3200.0,
      voltage_v: 400.2,
      frequency_hz: 50.01,
      power_factor: 0.98,
      capacity_utilization_pct: 49.0,
      is_simulated: 'SIMULATED',
    });
  }

  // 6. Grid Alerts
  const { data: existingAlerts } = await supabase.from('grid_alerts').select('id');
  if (!existingAlerts || existingAlerts.length === 0) {
    await supabase.from('grid_alerts').insert([
      { severity: 'WARNING', alert_type: 'HIGH_GRID_LOAD', title: 'Substation Grid Utilization Reached 78%', message: 'High simultaneous fast-charging detected at Bay Area Terminal 1. Automatic load shedding activated.', status: 'ACTIVE' },
      { severity: 'INFO', alert_type: 'RENEWABLE_SURPLUS', title: 'Solar PV Peak Surplus Available', message: 'Presidio Ecozone generating 420 kW excess solar power. Recommended charging window open.', status: 'ACTIVE' },
      { severity: 'WARNING', alert_type: 'CHARGER_OVERLOAD', title: 'Port 03 Thermal Throttling', message: 'Port temperature reached 48°C. Max power throttled to 90 kW for cooling.', status: 'ACTIVE' },
    ]);
  }

  // 7. Customer Feedback
  const { data: existingFeedback } = await supabase.from('customer_feedback').select('id');
  if ((!existingFeedback || existingFeedback.length === 0) && stIdList.length > 0) {
    await supabase.from('customer_feedback').insert([
      { station_id: stIdList[0], customer_name: 'Marcus Vance (Logistics Mgr)', rating: 5, category: 'CHARGING_SPEED', comment: '350 kW charger charged our heavy semi from 20% to 80% in under 38 minutes. Flawless experience!', status: 'PUBLISHED' },
      { station_id: stIdList[1 % stIdList.length], customer_name: 'David K. (Delivery Courier)', rating: 4, category: 'AVAILABILITY', comment: 'Clean station and easy bay access. Port 3 cable is a bit stiff in cold weather.', status: 'PUBLISHED' },
      { station_id: stIdList[2 % stIdList.length], customer_name: 'Rachel Green (Transit Ops)', rating: 5, category: 'APP_EXPERIENCE', comment: 'Real-time SOC monitoring and digital twin telemetry updates match our onboard dash perfectly.', status: 'PUBLISHED' },
      { station_id: stIdList[3 % stIdList.length], customer_name: 'Kenji Sato (Route Driver)', rating: 4, category: 'PAYMENT', comment: 'Automated fleet billing worked smoothly with zero manual card swiping needed.', status: 'PUBLISHED' },
    ]);
  }

  // 8. Bookings
  const { data: existingBookings } = await supabase.from('bookings').select('id');
  if ((!existingBookings || existingBookings.length === 0) && stIdList.length > 0 && portIds.length > 0) {
    await supabase.from('bookings').insert([
      { station_id: stIdList[0], port_id: portIds[0], booking_code: 'BK-810421', booking_date: '2026-10-09', start_time: '09:00', duration_minutes: 60, status: 'CONFIRMED', estimated_cost: 21.50, notes: 'Priority delivery recharge' },
      { station_id: stIdList[1 % stIdList.length], port_id: portIds[Math.min(5, portIds.length - 1)], booking_code: 'BK-941830', booking_date: '2026-10-09', start_time: '14:30', duration_minutes: 45, status: 'CONFIRMED', estimated_cost: 16.80, notes: 'Route change stop' },
    ]);
  }

  // 9. System Settings
  const { data: existingSettings } = await supabase.from('system_settings').select('key');
  if (!existingSettings || existingSettings.length === 0) {
    await supabase.from('system_settings').insert([
      { key: 'organization_name', value: 'GridVolt Fleet Enterprise', category: 'GENERAL' },
      { key: 'max_grid_load_threshold_kw', value: '4500', category: 'GRID' },
      { key: 'auto_optimize_charging', value: 'true', category: 'OPTIMIZATION' },
      { key: 'currency', value: 'USD ($)', category: 'GENERAL' },
    ]);
  }

  console.log('🎉 Supabase database fully seeded and structured!');
}

seed().catch((err) => {
  console.error('Error during Supabase seeding:', err);
  process.exit(1);
});
