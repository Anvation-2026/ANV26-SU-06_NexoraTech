-- SEED DATA FOR EV FLEET & CHARGING GRID SYSTEM

-- 1. Insert Charging Stations
INSERT INTO charging_stations (id, name, code, address, latitude, longitude, total_ports, max_station_power_kw, grid_capacity_kw, current_load_kw, status, price_per_kwh, connector_types) VALUES
('a0000000-0000-0000-0000-000000000001', 'Metro Downtown Superhub', 'ST-DT-01', '100 Market St, Financial District', 37.7935, -122.3970, 8, 350.0, 600.0, 185.0, 'ONLINE', 0.28, 'CCS2, NACS, Type 2'),
('a0000000-0000-0000-0000-000000000002', 'Bay Bridge Logistics Depot', 'ST-BB-02', '850 Embarcadero Way, Port Access', 37.7885, -122.3890, 6, 300.0, 500.0, 150.0, 'ONLINE', 0.26, 'CCS2, CHAdeMO'),
('a0000000-0000-0000-0000-000000000003', 'Silicon Gateway Transit Park', 'ST-SG-03', '4200 Silicon Ave, South Hub', 37.7650, -122.4050, 6, 250.0, 450.0, 120.0, 'ONLINE', 0.29, 'CCS2, NACS'),
('a0000000-0000-0000-0000-000000000004', 'Pacific Heights FastCharge', 'ST-PH-04', '2100 California St, Central', 37.7890, -122.4280, 6, 200.0, 400.0, 0.0, 'ONLINE', 0.32, 'CCS2, Type 2'),
('a0000000-0000-0000-0000-000000000005', 'Golden Gate Fleet Terminal', 'ST-GG-05', '1500 Marina Blvd, North Gate', 37.8040, -122.4410, 6, 350.0, 600.0, 160.0, 'ONLINE', 0.27, 'CCS2, NACS'),
('a0000000-0000-0000-0000-000000000006', 'Mission Valley Freight Port', 'ST-MV-06', '2600 Mission St, Transport Zone', 37.7550, -122.4180, 6, 300.0, 550.0, 65.0, 'ONLINE', 0.25, 'CCS2, CHAdeMO'),
('a0000000-0000-0000-0000-000000000007', 'Airport Cargo Express Depot', 'ST-AC-07', '700 Airport Blvd, Cargo Wing', 37.6250, -122.3800, 6, 400.0, 750.0, 0.0, 'ONLINE', 0.24, 'CCS2, NACS'),
('a0000000-0000-0000-0000-000000000008', 'Sunset District Hub', 'ST-SD-08', '1900 19th Ave, Westside', 37.7490, -122.4760, 6, 200.0, 400.0, 0.0, 'ONLINE', 0.30, 'CCS2, Type 2'),
('a0000000-0000-0000-0000-000000000009', 'Civic Center Fleet Center', 'ST-CC-09', '400 McAllister St, Government Core', 37.7800, -122.4190, 5, 250.0, 450.0, 0.0, 'ONLINE', 0.28, 'CCS2, NACS'),
('a0000000-0000-0000-0000-000000000010', 'Presidio Green Energy Park', 'ST-PG-10', '120 Lincoln Blvd, Presidio Ecozone', 37.7990, -122.4650, 5, 250.0, 450.0, 0.0, 'ONLINE', 0.27, 'CCS2, Type 2, NACS')
ON CONFLICT (code) DO NOTHING;

-- 2. Insert Drivers
INSERT INTO drivers (id, name, license_number, phone, email, status) VALUES
('b0000000-0000-0000-0000-000000000001', 'Liam Nelson', 'DL-CA-100001', '+1 (555) 019-1001', 'liam.nelson@fleetdriver.org', 'AVAILABLE'),
('b0000000-0000-0000-0000-000000000002', 'Emma Watson', 'DL-CA-100002', '+1 (555) 019-1002', 'emma.watson@fleetdriver.org', 'ON_TRIP'),
('b0000000-0000-0000-0000-000000000003', 'Noah Patel', 'DL-CA-100003', '+1 (555) 019-1003', 'noah.patel@fleetdriver.org', 'AVAILABLE'),
('b0000000-0000-0000-0000-000000000004', 'Olivia Chen', 'DL-CA-100004', '+1 (555) 019-1004', 'olivia.chen@fleetdriver.org', 'ON_TRIP'),
('b0000000-0000-0000-0000-000000000005', 'William Davis', 'DL-CA-100005', '+1 (555) 019-1005', 'william.davis@fleetdriver.org', 'AVAILABLE'),
('b0000000-0000-0000-0000-000000000006', 'Sophia Martinez', 'DL-CA-100006', '+1 (555) 019-1006', 'sophia.martinez@fleetdriver.org', 'ON_TRIP'),
('b0000000-0000-0000-0000-000000000007', 'James Wilson', 'DL-CA-100007', '+1 (555) 019-1007', 'james.wilson@fleetdriver.org', 'AVAILABLE'),
('b0000000-0000-0000-0000-000000000008', 'Isabella Taylor', 'DL-CA-100008', '+1 (555) 019-1008', 'isabella.taylor@fleetdriver.org', 'ON_TRIP'),
('b0000000-0000-0000-0000-000000000009', 'Benjamin Anderson', 'DL-CA-100009', '+1 (555) 019-1009', 'benjamin.anderson@fleetdriver.org', 'AVAILABLE'),
('b0000000-0000-0000-0000-000000000010', 'Mia Thomas', 'DL-CA-100010', '+1 (555) 019-1010', 'mia.thomas@fleetdriver.org', 'AVAILABLE')
ON CONFLICT (license_number) DO NOTHING;

-- 3. Insert Fleet Vehicles (Sample subset of 50 structured vehicles)
INSERT INTO vehicles (id, vin, registration_number, make, model, year, battery_capacity, current_soc, target_soc, status, charging_status, current_location, max_charge_rate_kw, driver_id, station_id) VALUES
('c0000000-0000-0000-0000-000000000001', '1FTNE3Y801PKA10001', 'EV-FLT-101', 'Tesla', 'Semi', 2024, 800.0, 48.0, 90.0, 'CHARGING', 'CHARGING', 'Metro Downtown Superhub', 350.0, 'b0000000-0000-0000-0000-000000000001', 'a0000000-0000-0000-0000-000000000001'),
('c0000000-0000-0000-0000-000000000002', '1FTNE3Y802PKA10002', 'EV-FLT-102', 'Tesla', 'Model Y Commercial', 2023, 75.0, 82.0, 90.0, 'AVAILABLE', 'DISCONNECTED', 'Central Fleet Depot', 150.0, 'b0000000-0000-0000-0000-000000000002', 'a0000000-0000-0000-0000-000000000001'),
('c0000000-0000-0000-0000-000000000003', '1FTNE3Y803PKA10003', 'EV-FLT-103', 'Ford', 'E-Transit 350', 2024, 68.0, 34.0, 85.0, 'CHARGING', 'CHARGING', 'Bay Bridge Logistics Depot', 150.0, 'b0000000-0000-0000-0000-000000000003', 'a0000000-0000-0000-0000-000000000002'),
('c0000000-0000-0000-0000-000000000004', '1FTNE3Y804PKA10004', 'EV-FLT-104', 'Rivian', 'EDV 700 Delivery', 2024, 135.0, 71.0, 90.0, 'ON_TRIP', 'DISCONNECTED', 'Route 101 Southbound', 150.0, 'b0000000-0000-0000-0000-000000000004', 'a0000000-0000-0000-0000-000000000003'),
('c0000000-0000-0000-0000-000000000005', '1FTNE3Y805PKA10005', 'EV-FLT-105', 'Mercedes-Benz', 'eSprinter Cargo', 2024, 113.0, 89.0, 90.0, 'AVAILABLE', 'DISCONNECTED', 'Central Fleet Depot', 150.0, 'b0000000-0000-0000-0000-000000000005', 'a0000000-0000-0000-0000-000000000004'),
('c0000000-0000-0000-0000-000000000006', '1FTNE3Y806PKA10006', 'EV-FLT-106', 'Volvo', 'VNR Electric Truck', 2023, 565.0, 42.0, 85.0, 'CHARGING', 'CHARGING', 'Silicon Gateway Transit Park', 250.0, 'b0000000-0000-0000-0000-000000000006', 'a0000000-0000-0000-0000-000000000003'),
('c0000000-0000-0000-0000-000000000007', '1FTNE3Y807PKA10007', 'EV-FLT-107', 'BrightDrop', 'Zevo 600', 2024, 165.0, 95.0, 100.0, 'AVAILABLE', 'DISCONNECTED', 'Airport Express Depot', 150.0, 'b0000000-0000-0000-0000-000000000007', 'a0000000-0000-0000-0000-000000000007'),
('c0000000-0000-0000-0000-000000000008', '1FTNE3Y808PKA10008', 'EV-FLT-108', 'BYD', '8TT Electric Semi', 2024, 422.0, 28.0, 80.0, 'CHARGING', 'CHARGING', 'Golden Gate Fleet Terminal', 350.0, 'b0000000-0000-0000-0000-000000000008', 'a0000000-0000-0000-0000-000000000005'),
('c0000000-0000-0000-0000-000000000009', '1FTNE3Y809PKA10009', 'EV-FLT-109', 'Tesla', 'Model Y Commercial', 2023, 75.0, 65.0, 90.0, 'ON_TRIP', 'DISCONNECTED', 'Financial District Route', 150.0, 'b0000000-0000-0000-0000-000000000009', 'a0000000-0000-0000-0000-000000000001'),
('c0000000-0000-0000-0000-000000000010', '1FTNE3Y810PKA10010', 'EV-FLT-110', 'Ford', 'E-Transit 350', 2024, 68.0, 19.0, 85.0, 'MAINTENANCE', 'DISCONNECTED', 'Service Bay 2', 150.0, 'b0000000-0000-0000-0000-000000000010', 'a0000000-0000-0000-0000-000000000002')
ON CONFLICT (registration_number) DO NOTHING;

-- 4. Insert Charging Ports
INSERT INTO charging_ports (id, station_id, port_number, connector_type, max_power_kw, current_power_kw, status, connected_vehicle_id) VALUES
('d0000000-0000-0000-0000-000000000001', 'a0000000-0000-0000-0000-000000000001', 'Port 01', 'CCS2', 350.0, 185.0, 'BUSY', 'c0000000-0000-0000-0000-000000000001'),
('d0000000-0000-0000-0000-000000000002', 'a0000000-0000-0000-0000-000000000001', 'Port 02', 'NACS', 250.0, 0.0, 'AVAILABLE', NULL),
('d0000000-0000-0000-0000-000000000003', 'a0000000-0000-0000-0000-000000000001', 'Port 03', 'Type 2', 150.0, 0.0, 'AVAILABLE', NULL),
('d0000000-0000-0000-0000-000000000004', 'a0000000-0000-0000-0000-000000000001', 'Port 04', 'CCS2', 350.0, 0.0, 'RESERVED', NULL),
('d0000000-0000-0000-0000-000000000005', 'a0000000-0000-0000-0000-000000000002', 'Port 01', 'CCS2', 300.0, 150.0, 'BUSY', 'c0000000-0000-0000-0000-000000000003'),
('d0000000-0000-0000-0000-000000000006', 'a0000000-0000-0000-0000-000000000002', 'Port 02', 'CHAdeMO', 150.0, 0.0, 'AVAILABLE', NULL),
('d0000000-0000-0000-0000-000000000007', 'a0000000-0000-0000-0000-000000000003', 'Port 01', 'CCS2', 250.0, 120.0, 'BUSY', 'c0000000-0000-0000-0000-000000000006'),
('d0000000-0000-0000-0000-000000000008', 'a0000000-0000-0000-0000-000000000003', 'Port 02', 'NACS', 250.0, 0.0, 'AVAILABLE', NULL),
('d0000000-0000-0000-0000-000000000009', 'a0000000-0000-0000-0000-000000000005', 'Port 01', 'CCS2', 350.0, 160.0, 'BUSY', 'c0000000-0000-0000-0000-000000000008'),
('d0000000-0000-0000-0000-000000000010', 'a0000000-0000-0000-0000-000000000005', 'Port 02', 'NACS', 350.0, 0.0, 'AVAILABLE', NULL)
ON CONFLICT (id) DO NOTHING;

-- 5. Insert Charging Sessions
INSERT INTO charging_sessions (id, port_id, vehicle_id, start_time, start_soc, energy_delivered_kwh, peak_power_kw, cost, status) VALUES
('e0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000001', 'c0000000-0000-0000-0000-000000000001', NOW() - INTERVAL '35 minutes', 20.0, 84.5, 350.0, 23.66, 'ACTIVE'),
('e0000000-0000-0000-0000-000000000002', 'd0000000-0000-0000-0000-000000000005', 'c0000000-0000-0000-0000-000000000003', NOW() - INTERVAL '25 minutes', 15.0, 31.2, 150.0, 8.11, 'ACTIVE'),
('e0000000-0000-0000-0000-000000000003', 'd0000000-0000-0000-0000-000000000007', 'c0000000-0000-0000-0000-000000000006', NOW() - INTERVAL '40 minutes', 22.0, 68.0, 250.0, 19.72, 'ACTIVE'),
('e0000000-0000-0000-0000-000000000004', 'd0000000-0000-0000-0000-000000000009', 'c0000000-0000-0000-0000-000000000008', NOW() - INTERVAL '15 minutes', 18.0, 42.0, 350.0, 11.34, 'ACTIVE')
ON CONFLICT (id) DO NOTHING;

-- 6. Insert Grid Alerts
INSERT INTO grid_alerts (id, severity, alert_type, title, message, status) VALUES
('f0000000-0000-0000-0000-000000000001', 'WARNING', 'HIGH_GRID_LOAD', 'Substation Grid Utilization Reached 78%', 'High simultaneous fast-charging detected at Bay Area Terminal 1. Automatic load shedding activated.', 'ACTIVE'),
('f0000000-0000-0000-0000-000000000002', 'INFO', 'RENEWABLE_SURPLUS', 'Solar PV Peak Surplus Available', 'Presidio Ecozone generating 420 kW excess solar power. Recommended charging window open.', 'ACTIVE'),
('f0000000-0000-0000-0000-000000000003', 'WARNING', 'CHARGER_OVERLOAD', 'Port 03 Thermal Throttling', 'Port temperature reached 48°C. Max power throttled to 90 kW for cooling.', 'ACTIVE')
ON CONFLICT (id) DO NOTHING;

-- 7. Insert Customer Feedback
INSERT INTO customer_feedback (id, station_id, customer_name, rating, category, comment, status) VALUES
('g0000000-0000-0000-0000-000000000001', 'a0000000-0000-0000-0000-000000000001', 'Marcus Vance (Logistics Mgr)', 5, 'CHARGING_SPEED', '350 kW charger charged our heavy semi from 20% to 80% in under 38 minutes. Flawless experience!', 'PUBLISHED'),
('g0000000-0000-0000-0000-000000000002', 'a0000000-0000-0000-0000-000000000002', 'David K. (Delivery Courier)', 4, 'AVAILABILITY', 'Clean station and easy bay access. Port 3 cable is a bit stiff in cold weather.', 'PUBLISHED'),
('g0000000-0000-0000-0000-000000000003', 'a0000000-0000-0000-0000-000000000003', 'Rachel Green (Transit Ops)', 5, 'APP_EXPERIENCE', 'Real-time SOC monitoring and digital twin telemetry updates match our onboard dash perfectly.', 'PUBLISHED'),
('g0000000-0000-0000-0000-000000000004', 'a0000000-0000-0000-0000-000000000004', 'Kenji Sato (Route Driver)', 4, 'PAYMENT', 'Automated fleet billing worked smoothly with zero manual card swiping needed.', 'PUBLISHED')
ON CONFLICT (id) DO NOTHING;

-- 8. Insert Bookings
INSERT INTO bookings (id, station_id, port_id, vehicle_id, booking_code, booking_date, start_time, duration_minutes, status, estimated_cost, notes) VALUES
('h0000000-0000-0000-0000-000000000001', 'a0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000004', 'c0000000-0000-0000-0000-000000000002', 'BK-810421', '2026-10-09', '09:00', 60, 'CONFIRMED', 21.50, 'Priority delivery recharge'),
('h0000000-0000-0000-0000-000000000002', 'a0000000-0000-0000-0000-000000000002', 'd0000000-0000-0000-0000-000000000006', 'c0000000-0000-0000-0000-000000000005', 'BK-941830', '2026-10-09', '14:30', 45, 'CONFIRMED', 16.80, 'Route change stop')
ON CONFLICT (booking_code) DO NOTHING;

-- 9. Insert System Settings
INSERT INTO system_settings (key, value, category, description) VALUES
('organization_name', 'GridVolt Fleet Enterprise', 'GENERAL', 'Enterprise fleet organization title'),
('currency', 'USD ($)', 'GENERAL', 'Default billing currency code'),
('timezone', 'UTC (America/Los_Angeles)', 'GENERAL', 'Standard operations time zone'),
('theme', 'dark', 'GENERAL', 'Control center user interface color scheme'),
('max_grid_load_threshold_kw', '4500', 'GRID', 'Safety overload cutoff in kilowatts'),
('peak_price_warning_threshold', '0.40', 'GRID', 'TOU pricing alert threshold'),
('default_target_soc', '85', 'CHARGING', 'Default vehicle recharge percentage'),
('auto_optimize_charging', 'true', 'CHARGING', 'Automated SciPy dispatch optimization')
ON CONFLICT (key) DO NOTHING;
