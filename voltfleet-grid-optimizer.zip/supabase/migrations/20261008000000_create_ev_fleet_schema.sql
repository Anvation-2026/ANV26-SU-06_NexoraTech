-- Enable pgcrypto / uuid extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Function to automatically manage updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 1. DRIVERS TABLE
CREATE TABLE IF NOT EXISTS drivers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    license_number VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(50),
    email VARCHAR(255),
    status VARCHAR(50) NOT NULL DEFAULT 'AVAILABLE' CHECK (status IN ('AVAILABLE', 'ON_TRIP', 'OFF_DUTY', 'MAINTENANCE')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. CHARGING STATIONS TABLE
CREATE TABLE IF NOT EXISTS charging_stations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    code VARCHAR(50) NOT NULL UNIQUE,
    address VARCHAR(255) NOT NULL,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    total_ports INTEGER NOT NULL DEFAULT 6 CHECK (total_ports >= 0),
    max_station_power_kw DOUBLE PRECISION NOT NULL DEFAULT 350.0 CHECK (max_station_power_kw > 0),
    grid_capacity_kw DOUBLE PRECISION NOT NULL DEFAULT 600.0 CHECK (grid_capacity_kw > 0),
    current_load_kw DOUBLE PRECISION NOT NULL DEFAULT 0.0 CHECK (current_load_kw >= 0),
    status VARCHAR(50) NOT NULL DEFAULT 'ONLINE' CHECK (status IN ('ONLINE', 'DEGRADED', 'OFFLINE', 'MAINTENANCE')),
    price_per_kwh DOUBLE PRECISION NOT NULL DEFAULT 0.28 CHECK (price_per_kwh >= 0),
    connector_types VARCHAR(255) NOT NULL DEFAULT 'CCS2, Type 2, NACS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. VEHICLES TABLE
CREATE TABLE IF NOT EXISTS vehicles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vin VARCHAR(100) NOT NULL UNIQUE,
    registration_number VARCHAR(50) NOT NULL UNIQUE,
    make VARCHAR(100) NOT NULL,
    model VARCHAR(100) NOT NULL,
    year INTEGER NOT NULL DEFAULT 2024 CHECK (year >= 2000),
    battery_capacity DOUBLE PRECISION NOT NULL CHECK (battery_capacity > 0),
    current_soc DOUBLE PRECISION NOT NULL DEFAULT 100.0 CHECK (current_soc >= 0 AND current_soc <= 100),
    target_soc DOUBLE PRECISION NOT NULL DEFAULT 90.0 CHECK (target_soc >= 0 AND target_soc <= 100),
    status VARCHAR(50) NOT NULL DEFAULT 'AVAILABLE' CHECK (status IN ('AVAILABLE', 'ON_TRIP', 'CHARGING', 'IDLE', 'MAINTENANCE', 'OFFLINE')),
    charging_status VARCHAR(50) NOT NULL DEFAULT 'DISCONNECTED' CHECK (charging_status IN ('DISCONNECTED', 'CONNECTED', 'CHARGING', 'COMPLETE')),
    current_location VARCHAR(255) NOT NULL DEFAULT 'Central Fleet Depot',
    latitude DOUBLE PRECISION NOT NULL DEFAULT 37.7749,
    longitude DOUBLE PRECISION NOT NULL DEFAULT -122.4194,
    odometer_km DOUBLE PRECISION NOT NULL DEFAULT 12500.0 CHECK (odometer_km >= 0),
    max_charge_rate_kw DOUBLE PRECISION NOT NULL DEFAULT 150.0 CHECK (max_charge_rate_kw > 0),
    driver_id UUID REFERENCES drivers(id) ON DELETE SET NULL,
    station_id UUID REFERENCES charging_stations(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 4. CHARGING PORTS TABLE
CREATE TABLE IF NOT EXISTS charging_ports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    station_id UUID NOT NULL REFERENCES charging_stations(id) ON DELETE CASCADE,
    port_number VARCHAR(50) NOT NULL,
    connector_type VARCHAR(50) NOT NULL DEFAULT 'CCS2',
    max_power_kw DOUBLE PRECISION NOT NULL DEFAULT 150.0 CHECK (max_power_kw > 0),
    current_power_kw DOUBLE PRECISION NOT NULL DEFAULT 0.0 CHECK (current_power_kw >= 0),
    status VARCHAR(50) NOT NULL DEFAULT 'AVAILABLE' CHECK (status IN ('AVAILABLE', 'BUSY', 'RESERVED', 'FAULTED', 'OFFLINE')),
    connected_vehicle_id UUID REFERENCES vehicles(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. CHARGING SESSIONS TABLE
CREATE TABLE IF NOT EXISTS charging_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    port_id UUID NOT NULL REFERENCES charging_ports(id) ON DELETE CASCADE,
    vehicle_id UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
    start_time TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    end_time TIMESTAMPTZ,
    start_soc DOUBLE PRECISION NOT NULL DEFAULT 20.0 CHECK (start_soc >= 0 AND start_soc <= 100),
    end_soc DOUBLE PRECISION CHECK (end_soc IS NULL OR (end_soc >= 0 AND end_soc <= 100)),
    energy_delivered_kwh DOUBLE PRECISION NOT NULL DEFAULT 0.0 CHECK (energy_delivered_kwh >= 0),
    peak_power_kw DOUBLE PRECISION NOT NULL DEFAULT 0.0 CHECK (peak_power_kw >= 0),
    cost DOUBLE PRECISION NOT NULL DEFAULT 0.0 CHECK (cost >= 0),
    status VARCHAR(50) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('PENDING', 'ACTIVE', 'COMPLETED', 'INTERRUPTED', 'CANCELLED')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 6. VEHICLE TELEMETRY TABLE
CREATE TABLE IF NOT EXISTS vehicle_telemetry (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vehicle_id UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
    soc DOUBLE PRECISION NOT NULL CHECK (soc >= 0 AND soc <= 100),
    battery_temp_c DOUBLE PRECISION NOT NULL DEFAULT 28.5,
    charging_power_kw DOUBLE PRECISION NOT NULL DEFAULT 0.0 CHECK (charging_power_kw >= 0),
    voltage_v DOUBLE PRECISION NOT NULL DEFAULT 400.0,
    current_a DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    speed_kmh DOUBLE PRECISION NOT NULL DEFAULT 0.0 CHECK (speed_kmh >= 0),
    energy_delivered_kwh DOUBLE PRECISION NOT NULL DEFAULT 0.0 CHECK (energy_delivered_kwh >= 0),
    is_simulated VARCHAR(10) NOT NULL DEFAULT 'SIMULATED',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 7. CHARGING TELEMETRY TABLE
CREATE TABLE IF NOT EXISTS charging_telemetry (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    port_id UUID NOT NULL REFERENCES charging_ports(id) ON DELETE CASCADE,
    session_id UUID REFERENCES charging_sessions(id) ON DELETE CASCADE,
    voltage_v DOUBLE PRECISION NOT NULL DEFAULT 400.0,
    current_a DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    power_kw DOUBLE PRECISION NOT NULL DEFAULT 0.0 CHECK (power_kw >= 0),
    energy_kwh DOUBLE PRECISION NOT NULL DEFAULT 0.0 CHECK (energy_kwh >= 0),
    temperature_c DOUBLE PRECISION NOT NULL DEFAULT 32.0,
    is_simulated VARCHAR(10) NOT NULL DEFAULT 'SIMULATED',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 8. GRID TELEMETRY TABLE
CREATE TABLE IF NOT EXISTS grid_telemetry (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    total_capacity_kw DOUBLE PRECISION NOT NULL DEFAULT 5000.0 CHECK (total_capacity_kw > 0),
    current_grid_load_kw DOUBLE PRECISION NOT NULL DEFAULT 2450.0 CHECK (current_grid_load_kw >= 0),
    charging_load_kw DOUBLE PRECISION NOT NULL DEFAULT 680.0 CHECK (charging_load_kw >= 0),
    base_load_kw DOUBLE PRECISION NOT NULL DEFAULT 1770.0 CHECK (base_load_kw >= 0),
    renewable_energy_kw DOUBLE PRECISION NOT NULL DEFAULT 950.0 CHECK (renewable_energy_kw >= 0),
    peak_demand_kw DOUBLE PRECISION NOT NULL DEFAULT 3200.0 CHECK (peak_demand_kw >= 0),
    voltage_v DOUBLE PRECISION NOT NULL DEFAULT 400.0,
    frequency_hz DOUBLE PRECISION NOT NULL DEFAULT 50.02,
    power_factor DOUBLE PRECISION NOT NULL DEFAULT 0.98 CHECK (power_factor >= 0 AND power_factor <= 1.0),
    capacity_utilization_pct DOUBLE PRECISION NOT NULL DEFAULT 49.0 CHECK (capacity_utilization_pct >= 0 AND capacity_utilization_pct <= 100),
    is_simulated VARCHAR(10) NOT NULL DEFAULT 'SIMULATED',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 9. GRID ALERTS TABLE
CREATE TABLE IF NOT EXISTS grid_alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    station_id UUID REFERENCES charging_stations(id) ON DELETE SET NULL,
    severity VARCHAR(50) NOT NULL DEFAULT 'WARNING' CHECK (severity IN ('INFO', 'WARNING', 'CRITICAL')),
    alert_type VARCHAR(100) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'ACKNOWLEDGED', 'RESOLVED')),
    resolved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 10. BOOKINGS TABLE
CREATE TABLE IF NOT EXISTS bookings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    station_id UUID NOT NULL REFERENCES charging_stations(id) ON DELETE CASCADE,
    port_id UUID NOT NULL REFERENCES charging_ports(id) ON DELETE CASCADE,
    vehicle_id UUID REFERENCES vehicles(id) ON DELETE SET NULL,
    customer_id UUID,
    booking_code VARCHAR(50) NOT NULL UNIQUE,
    booking_date VARCHAR(20) NOT NULL,
    start_time VARCHAR(20) NOT NULL,
    duration_minutes INTEGER NOT NULL DEFAULT 60 CHECK (duration_minutes > 0),
    status VARCHAR(50) NOT NULL DEFAULT 'CONFIRMED' CHECK (status IN ('PENDING', 'CONFIRMED', 'ACTIVE', 'COMPLETED', 'CANCELLED')),
    estimated_cost DOUBLE PRECISION NOT NULL DEFAULT 18.5 CHECK (estimated_cost >= 0),
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 11. CUSTOMER FEEDBACK TABLE
CREATE TABLE IF NOT EXISTS customer_feedback (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    station_id UUID NOT NULL REFERENCES charging_stations(id) ON DELETE CASCADE,
    customer_id UUID,
    customer_name VARCHAR(255) NOT NULL DEFAULT 'Anonymous EV Driver',
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    category VARCHAR(50) NOT NULL CHECK (category IN ('CHARGING_SPEED', 'AVAILABILITY', 'PAYMENT', 'APP_EXPERIENCE', 'LOCATION', 'HARDWARE', 'CUSTOMER_SERVICE', 'OTHER')),
    comment TEXT NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'PUBLISHED' CHECK (status IN ('PUBLISHED', 'UNDER_REVIEW', 'RESOLVED')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 12. OPTIMIZATION SCHEDULES TABLE
CREATE TABLE IF NOT EXISTS optimization_schedules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vehicle_id UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
    station_id UUID REFERENCES charging_stations(id) ON DELETE SET NULL,
    current_soc DOUBLE PRECISION NOT NULL CHECK (current_soc >= 0 AND current_soc <= 100),
    target_soc DOUBLE PRECISION NOT NULL CHECK (target_soc >= 0 AND target_soc <= 100),
    battery_capacity DOUBLE PRECISION NOT NULL CHECK (battery_capacity > 0),
    arrival_time TIMESTAMPTZ NOT NULL,
    departure_time TIMESTAMPTZ NOT NULL,
    charger_power DOUBLE PRECISION NOT NULL CHECK (charger_power > 0),
    charging_start TIMESTAMPTZ NOT NULL,
    charging_end TIMESTAMPTZ NOT NULL,
    energy_required DOUBLE PRECISION NOT NULL CHECK (energy_required >= 0),
    estimated_cost DOUBLE PRECISION NOT NULL CHECK (estimated_cost >= 0),
    baseline_peak_load DOUBLE PRECISION NOT NULL,
    optimized_peak_load DOUBLE PRECISION NOT NULL,
    estimated_savings DOUBLE PRECISION NOT NULL DEFAULT 0.0 CHECK (estimated_savings >= 0),
    schedule_intervals JSONB,
    status VARCHAR(50) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'EXECUTED', 'CANCELLED')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 13. REPORTS TABLE
CREATE TABLE IF NOT EXISTS reports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title VARCHAR(255) NOT NULL,
    report_type VARCHAR(100) NOT NULL,
    start_date VARCHAR(30) NOT NULL,
    end_date VARCHAR(30) NOT NULL,
    station_id UUID REFERENCES charging_stations(id) ON DELETE SET NULL,
    vehicle_id UUID REFERENCES vehicles(id) ON DELETE SET NULL,
    file_path VARCHAR(255),
    storage_url TEXT,
    status VARCHAR(50) NOT NULL DEFAULT 'GENERATED' CHECK (status IN ('PENDING', 'GENERATED', 'FAILED')),
    summary_kpis JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 14. NOTIFICATIONS TABLE
CREATE TABLE IF NOT EXISTS notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(50) NOT NULL DEFAULT 'INFO' CHECK (type IN ('INFO', 'WARNING', 'ALERT', 'SUCCESS')),
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 15. SYSTEM SETTINGS TABLE
CREATE TABLE IF NOT EXISTS system_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    key VARCHAR(100) NOT NULL UNIQUE,
    value TEXT NOT NULL,
    category VARCHAR(50) NOT NULL DEFAULT 'GENERAL',
    description VARCHAR(255),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- INDEXES FOR PERFORMANCE
CREATE INDEX IF NOT EXISTS idx_vehicles_status ON vehicles(status);
CREATE INDEX IF NOT EXISTS idx_vehicles_charging_status ON vehicles(charging_status);
CREATE INDEX IF NOT EXISTS idx_vehicles_driver_id ON vehicles(driver_id);
CREATE INDEX IF NOT EXISTS idx_charging_ports_station_id ON charging_ports(station_id);
CREATE INDEX IF NOT EXISTS idx_charging_ports_status ON charging_ports(status);
CREATE INDEX IF NOT EXISTS idx_charging_sessions_vehicle_id ON charging_sessions(vehicle_id);
CREATE INDEX IF NOT EXISTS idx_charging_sessions_port_id ON charging_sessions(port_id);
CREATE INDEX IF NOT EXISTS idx_vehicle_telemetry_vehicle_id ON vehicle_telemetry(vehicle_id);
CREATE INDEX IF NOT EXISTS idx_charging_telemetry_port_id ON charging_telemetry(port_id);
CREATE INDEX IF NOT EXISTS idx_grid_alerts_status ON grid_alerts(status);
CREATE INDEX IF NOT EXISTS idx_bookings_station_id ON bookings(station_id);
CREATE INDEX IF NOT EXISTS idx_customer_feedback_station_id ON customer_feedback(station_id);
CREATE INDEX IF NOT EXISTS idx_optimization_schedules_vehicle_id ON optimization_schedules(vehicle_id);

-- ENABLE ROW LEVEL SECURITY (RLS)
ALTER TABLE drivers ENABLE ROW LEVEL SECURITY;
ALTER TABLE charging_stations ENABLE ROW LEVEL SECURITY;
ALTER TABLE vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE charging_ports ENABLE ROW LEVEL SECURITY;
ALTER TABLE charging_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE vehicle_telemetry ENABLE ROW LEVEL SECURITY;
ALTER TABLE charging_telemetry ENABLE ROW LEVEL SECURITY;
ALTER TABLE grid_telemetry ENABLE ROW LEVEL SECURITY;
ALTER TABLE grid_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE customer_feedback ENABLE ROW LEVEL SECURITY;
ALTER TABLE optimization_schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE system_settings ENABLE ROW LEVEL SECURITY;

-- CREATE RLS POLICIES FOR OPERATIONAL CONTROL CENTER
-- Allow full public / authenticated access via Anon Key for read and operations
CREATE POLICY "Allow public read access on drivers" ON drivers FOR SELECT USING (true);
CREATE POLICY "Allow public insert on drivers" ON drivers FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update on drivers" ON drivers FOR UPDATE USING (true);
CREATE POLICY "Allow public delete on drivers" ON drivers FOR DELETE USING (true);

CREATE POLICY "Allow public read access on charging_stations" ON charging_stations FOR SELECT USING (true);
CREATE POLICY "Allow public insert on charging_stations" ON charging_stations FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update on charging_stations" ON charging_stations FOR UPDATE USING (true);

CREATE POLICY "Allow public read access on vehicles" ON vehicles FOR SELECT USING (true);
CREATE POLICY "Allow public insert on vehicles" ON vehicles FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update on vehicles" ON vehicles FOR UPDATE USING (true);
CREATE POLICY "Allow public delete on vehicles" ON vehicles FOR DELETE USING (true);

CREATE POLICY "Allow public read access on charging_ports" ON charging_ports FOR SELECT USING (true);
CREATE POLICY "Allow public insert on charging_ports" ON charging_ports FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update on charging_ports" ON charging_ports FOR UPDATE USING (true);

CREATE POLICY "Allow public read access on charging_sessions" ON charging_sessions FOR SELECT USING (true);
CREATE POLICY "Allow public insert on charging_sessions" ON charging_sessions FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update on charging_sessions" ON charging_sessions FOR UPDATE USING (true);

CREATE POLICY "Allow public read access on vehicle_telemetry" ON vehicle_telemetry FOR SELECT USING (true);
CREATE POLICY "Allow public insert on vehicle_telemetry" ON vehicle_telemetry FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public read access on charging_telemetry" ON charging_telemetry FOR SELECT USING (true);
CREATE POLICY "Allow public insert on charging_telemetry" ON charging_telemetry FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public read access on grid_telemetry" ON grid_telemetry FOR SELECT USING (true);
CREATE POLICY "Allow public insert on grid_telemetry" ON grid_telemetry FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public read access on grid_alerts" ON grid_alerts FOR SELECT USING (true);
CREATE POLICY "Allow public insert on grid_alerts" ON grid_alerts FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update on grid_alerts" ON grid_alerts FOR UPDATE USING (true);

CREATE POLICY "Allow public read access on bookings" ON bookings FOR SELECT USING (true);
CREATE POLICY "Allow public insert on bookings" ON bookings FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update on bookings" ON bookings FOR UPDATE USING (true);
CREATE POLICY "Allow public delete on bookings" ON bookings FOR DELETE USING (true);

CREATE POLICY "Allow public read access on customer_feedback" ON customer_feedback FOR SELECT USING (true);
CREATE POLICY "Allow public insert on customer_feedback" ON customer_feedback FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update on customer_feedback" ON customer_feedback FOR UPDATE USING (true);

CREATE POLICY "Allow public read access on optimization_schedules" ON optimization_schedules FOR SELECT USING (true);
CREATE POLICY "Allow public insert on optimization_schedules" ON optimization_schedules FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update on optimization_schedules" ON optimization_schedules FOR UPDATE USING (true);

CREATE POLICY "Allow public read access on reports" ON reports FOR SELECT USING (true);
CREATE POLICY "Allow public insert on reports" ON reports FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update on reports" ON reports FOR UPDATE USING (true);

CREATE POLICY "Allow public read access on notifications" ON notifications FOR SELECT USING (true);
CREATE POLICY "Allow public insert on notifications" ON notifications FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update on notifications" ON notifications FOR UPDATE USING (true);

CREATE POLICY "Allow public read access on system_settings" ON system_settings FOR SELECT USING (true);
CREATE POLICY "Allow public insert on system_settings" ON system_settings FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update on system_settings" ON system_settings FOR UPDATE USING (true);

-- ENABLE SUPABASE REALTIME REPLICATION FOR LIVE TELEMETRY & OPERATIONS
ALTER PUBLICATION supabase_realtime ADD TABLE vehicles;
ALTER PUBLICATION supabase_realtime ADD TABLE charging_ports;
ALTER PUBLICATION supabase_realtime ADD TABLE charging_sessions;
ALTER PUBLICATION supabase_realtime ADD TABLE grid_telemetry;
ALTER PUBLICATION supabase_realtime ADD TABLE grid_alerts;
