import os
import requests
import json
import random
from datetime import datetime, timezone, timedelta

SUPABASE_URL = os.getenv("VITE_SUPABASE_URL", "https://vuqiugfjeipemsacoxek.supabase.co")
SUPABASE_KEY = os.getenv("VITE_SUPABASE_ANON_KEY", "sb_publishable_D0OdLBVLSjltGkdOsBliBg_offrEKCM")

HEADERS = {
    "apikey": SUPABASE_KEY,
    "Authorization": f"Bearer {SUPABASE_KEY}",
    "Content-Type": "application/json",
    "Prefer": "return=representation"
}

def seed_supabase():
    print(f"Connecting to Supabase at {SUPABASE_URL}...")

    # 1. Stations
    stations_data = [
        {"name": "Metro Downtown Superhub", "code": "ST-DT-01", "address": "100 Market St, Financial District", "latitude": 37.7935, "longitude": -122.3970, "total_ports": 8, "max_station_power_kw": 350.0, "grid_capacity_kw": 600.0, "current_load_kw": 185.0, "status": "ONLINE", "price_per_kwh": 0.28, "connector_types": "CCS2, NACS, Type 2"},
        {"name": "Bay Bridge Logistics Depot", "code": "ST-BB-02", "address": "850 Embarcadero Way, Port Access", "latitude": 37.7885, "longitude": -122.3890, "total_ports": 6, "max_station_power_kw": 300.0, "grid_capacity_kw": 500.0, "current_load_kw": 150.0, "status": "ONLINE", "price_per_kwh": 0.26, "connector_types": "CCS2, CHAdeMO"},
        {"name": "Silicon Gateway Transit Park", "code": "ST-SG-03", "address": "4200 Silicon Ave, South Hub", "latitude": 37.7650, "longitude": -122.4050, "total_ports": 6, "max_station_power_kw": 250.0, "grid_capacity_kw": 450.0, "current_load_kw": 120.0, "status": "ONLINE", "price_per_kwh": 0.29, "connector_types": "CCS2, NACS"},
        {"name": "Pacific Heights FastCharge", "code": "ST-PH-04", "address": "2100 California St, Central", "latitude": 37.7890, "longitude": -122.4280, "total_ports": 6, "max_station_power_kw": 200.0, "grid_capacity_kw": 400.0, "current_load_kw": 0.0, "status": "ONLINE", "price_per_kwh": 0.32, "connector_types": "CCS2, Type 2"},
        {"name": "Golden Gate Fleet Terminal", "code": "ST-GG-05", "address": "1500 Marina Blvd, North Gate", "latitude": 37.8040, "longitude": -122.4410, "total_ports": 6, "max_station_power_kw": 350.0, "grid_capacity_kw": 600.0, "current_load_kw": 160.0, "status": "ONLINE", "price_per_kwh": 0.27, "connector_types": "CCS2, NACS"},
        {"name": "Mission Valley Freight Port", "code": "ST-MV-06", "address": "2600 Mission St, Transport Zone", "latitude": 37.7550, "longitude": -122.4180, "total_ports": 6, "max_station_power_kw": 300.0, "grid_capacity_kw": 550.0, "current_load_kw": 65.0, "status": "ONLINE", "price_per_kwh": 0.25, "connector_types": "CCS2, CHAdeMO"},
        {"name": "Airport Cargo Express Depot", "code": "ST-AC-07", "address": "700 Airport Blvd, Cargo Wing", "latitude": 37.6250, "longitude": -122.3800, "total_ports": 6, "max_station_power_kw": 400.0, "grid_capacity_kw": 750.0, "current_load_kw": 0.0, "status": "ONLINE", "price_per_kwh": 0.24, "connector_types": "CCS2, NACS"},
        {"name": "Sunset District Hub", "code": "ST-SD-08", "address": "1900 19th Ave, Westside", "latitude": 37.7490, "longitude": -122.4760, "total_ports": 6, "max_station_power_kw": 200.0, "grid_capacity_kw": 400.0, "current_load_kw": 0.0, "status": "ONLINE", "price_per_kwh": 0.30, "connector_types": "CCS2, Type 2"},
        {"name": "Civic Center Fleet Center", "code": "ST-CC-09", "address": "400 McAllister St, Government Core", "latitude": 37.7800, "longitude": -122.4190, "total_ports": 5, "max_station_power_kw": 250.0, "grid_capacity_kw": 450.0, "current_load_kw": 0.0, "status": "ONLINE", "price_per_kwh": 0.28, "connector_types": "CCS2, NACS"},
        {"name": "Presidio Green Energy Park", "code": "ST-PG-10", "address": "120 Lincoln Blvd, Presidio Ecozone", "latitude": 37.7990, "longitude": -122.4650, "total_ports": 5, "max_station_power_kw": 250.0, "grid_capacity_kw": 450.0, "current_load_kw": 0.0, "status": "ONLINE", "price_per_kwh": 0.27, "connector_types": "CCS2, Type 2, NACS"}
    ]

    r = requests.get(f"{SUPABASE_URL}/rest/v1/charging_stations?select=id,code", headers=HEADERS)
    existing_stations = {s["code"]: s["id"] for s in (r.json() if r.status_code == 200 and isinstance(r.json(), list) else [])}
    station_ids = {}

    for s in stations_data:
        if s["code"] in existing_stations:
            station_ids[s["code"]] = existing_stations[s["code"]]
        else:
            res = requests.post(f"{SUPABASE_URL}/rest/v1/charging_stations", headers=HEADERS, json=s)
            if res.status_code in [200, 201]:
                station_ids[s["code"]] = res.json()[0]["id"]
            else:
                print(f"Error inserting station {s['code']}: {res.text}")

    print(f"Stations seeded: {len(station_ids)} stations active.")

    # 2. Drivers
    drivers_data = [
        {"name": "Liam Nelson", "license_number": "DL-CA-100001", "phone": "+1 (555) 019-1001", "email": "liam.nelson@fleetdriver.org", "status": "AVAILABLE"},
        {"name": "Emma Watson", "license_number": "DL-CA-100002", "phone": "+1 (555) 019-1002", "email": "emma.watson@fleetdriver.org", "status": "ON_TRIP"},
        {"name": "Noah Patel", "license_number": "DL-CA-100003", "phone": "+1 (555) 019-1003", "email": "noah.patel@fleetdriver.org", "status": "AVAILABLE"},
        {"name": "Olivia Chen", "license_number": "DL-CA-100004", "phone": "+1 (555) 019-1004", "email": "olivia.chen@fleetdriver.org", "status": "ON_TRIP"},
        {"name": "William Davis", "license_number": "DL-CA-100005", "phone": "+1 (555) 019-1005", "email": "william.davis@fleetdriver.org", "status": "AVAILABLE"},
        {"name": "Sophia Martinez", "license_number": "DL-CA-100006", "phone": "+1 (555) 019-1006", "email": "sophia.martinez@fleetdriver.org", "status": "ON_TRIP"},
        {"name": "James Wilson", "license_number": "DL-CA-100007", "phone": "+1 (555) 019-1007", "email": "james.wilson@fleetdriver.org", "status": "AVAILABLE"},
        {"name": "Isabella Taylor", "license_number": "DL-CA-100008", "phone": "+1 (555) 019-1008", "email": "isabella.taylor@fleetdriver.org", "status": "ON_TRIP"},
        {"name": "Benjamin Anderson", "license_number": "DL-CA-100009", "phone": "+1 (555) 019-1009", "email": "benjamin.anderson@fleetdriver.org", "status": "AVAILABLE"},
        {"name": "Mia Thomas", "license_number": "DL-CA-100010", "phone": "+1 (555) 019-1010", "email": "mia.thomas@fleetdriver.org", "status": "AVAILABLE"}
    ]

    r_drv = requests.get(f"{SUPABASE_URL}/rest/v1/drivers?select=id,license_number", headers=HEADERS)
    existing_drivers = {d["license_number"]: d["id"] for d in (r_drv.json() if r_drv.status_code == 200 and isinstance(r_drv.json(), list) else [])}
    driver_ids = []

    for d in drivers_data:
        if d["license_number"] in existing_drivers:
            driver_ids.append(existing_drivers[d["license_number"]])
        else:
            res = requests.post(f"{SUPABASE_URL}/rest/v1/drivers", headers=HEADERS, json=d)
            if res.status_code in [200, 201]:
                driver_ids.append(res.json()[0]["id"])
            else:
                print(f"Error inserting driver {d['name']}: {res.text}")

    print(f"Drivers seeded: {len(driver_ids)} drivers active.")

    # 3. Charging Ports
    r_ports = requests.get(f"{SUPABASE_URL}/rest/v1/charging_ports?select=id", headers=HEADERS)
    ports_count = len(r_ports.json()) if r_ports.status_code == 200 and isinstance(r_ports.json(), list) else 0

    port_ids = []
    if ports_count < 60:
        connector_options = ["CCS2", "NACS", "Type 2", "CHAdeMO"]
        p_idx = 1
        for code, st_id in station_ids.items():
            for p_num in range(1, 7):
                c_type = connector_options[(p_num - 1) % len(connector_options)]
                p_status = "AVAILABLE"
                curr_kw = 0.0
                if p_idx in [1, 2, 4, 8, 11, 14, 18, 22, 27, 33]:
                    p_status = "BUSY"
                    curr_kw = 85.0
                elif p_idx in [5, 17]:
                    p_status = "RESERVED"

                port_payload = {
                    "station_id": st_id,
                    "port_number": f"Port {p_num:02d}",
                    "connector_type": c_type,
                    "max_power_kw": 150.0 if p_num <= 4 else 350.0,
                    "current_power_kw": curr_kw,
                    "status": p_status
                }
                res = requests.post(f"{SUPABASE_URL}/rest/v1/charging_ports", headers=HEADERS, json=port_payload)
                if res.status_code in [200, 201]:
                    port_ids.append(res.json()[0]["id"])
                p_idx += 1
        print(f"Ports seeded: {len(port_ids)} ports created.")
    else:
        port_ids = [p["id"] for p in r_ports.json()]
        print(f"Ports already exist: {len(port_ids)} ports.")

    # 4. Vehicles (50 commercial fleet assets)
    r_veh = requests.get(f"{SUPABASE_URL}/rest/v1/vehicles?select=id,registration_number", headers=HEADERS)
    existing_veh = {v["registration_number"]: v["id"] for v in (r_veh.json() if r_veh.status_code == 200 and isinstance(r_veh.json(), list) else [])}
    
    makes_models = [
        ("Tesla", "Semi", 800.0, 2024),
        ("Tesla", "Model Y Commercial", 75.0, 2023),
        ("Ford", "E-Transit 350", 68.0, 2024),
        ("Rivian", "EDV 700 Delivery", 135.0, 2024),
        ("Mercedes-Benz", "eSprinter Cargo", 113.0, 2024),
        ("Volvo", "VNR Electric Truck", 565.0, 2023),
        ("BrightDrop", "Zevo 600", 165.0, 2024),
        ("BYD", "8TT Electric Semi", 422.0, 2024)
    ]

    st_id_list = list(station_ids.values())
    vehicle_ids = []

    if len(existing_veh) < 50:
        for i in range(1, 51):
            reg = f"EV-FLT-{100 + i:03d}"
            if reg in existing_veh:
                vehicle_ids.append(existing_veh[reg])
                continue

            mm = makes_models[(i - 1) % len(makes_models)]
            soc = round(random.uniform(25.0, 95.0), 1)
            status = "AVAILABLE"
            charging_status = "DISCONNECTED"

            if i <= 10:
                status = "CHARGING"
                charging_status = "CHARGING"
                soc = round(random.uniform(22.0, 68.0), 1)
            elif i % 5 == 0:
                status = "ON_TRIP"
            elif i % 12 == 0:
                status = "MAINTENANCE"
            elif i % 25 == 0:
                status = "IDLE"

            veh_payload = {
                "vin": f"1FTNE3Y8{i:02d}PKA{10000 + i}",
                "registration_number": reg,
                "make": mm[0],
                "model": mm[1],
                "year": mm[3],
                "battery_capacity": mm[2],
                "current_soc": soc,
                "target_soc": 90.0,
                "status": status,
                "charging_status": charging_status,
                "current_location": "Central Fleet Depot" if status != "ON_TRIP" else "Active Delivery Corridor",
                "latitude": 37.7749 + random.uniform(-0.05, 0.05),
                "longitude": -122.4194 + random.uniform(-0.06, 0.06),
                "odometer_km": round(8000.0 + i * 450.0, 1),
                "max_charge_rate_kw": 150.0 if mm[2] < 200 else 350.0,
                "driver_id": driver_ids[(i - 1) % len(driver_ids)] if driver_ids and i % 2 == 0 else None,
                "station_id": st_id_list[(i - 1) % len(st_id_list)] if st_id_list else None
            }
            res = requests.post(f"{SUPABASE_URL}/rest/v1/vehicles", headers=HEADERS, json=veh_payload)
            if res.status_code in [200, 201]:
                vehicle_ids.append(res.json()[0]["id"])
            else:
                print(f"Error inserting vehicle {reg}: {res.text}")

        print(f"Vehicles seeded in Supabase: {len(vehicle_ids)} vehicles active.")
    else:
        print(f"Vehicles already seeded: {len(existing_veh)} vehicles present.")

    # 5. Charging Sessions
    r_sess = requests.get(f"{SUPABASE_URL}/rest/v1/charging_sessions?select=id", headers=HEADERS)
    if r_sess.status_code == 200 and len(r_sess.json()) < 10 and len(port_ids) > 0 and len(vehicle_ids) > 0:
        now = datetime.now(timezone.utc)
        for i in range(min(12, len(port_ids), len(vehicle_ids))):
            sess_payload = {
                "port_id": port_ids[i],
                "vehicle_id": vehicle_ids[i],
                "start_time": (now - timedelta(minutes=random.randint(15, 60))).isoformat(),
                "start_soc": round(random.uniform(18.0, 30.0), 1),
                "energy_delivered_kwh": round(random.uniform(25.0, 75.0), 1),
                "peak_power_kw": 150.0,
                "cost": round(random.uniform(10.0, 25.0), 2),
                "status": "ACTIVE" if i < 4 else "COMPLETED"
            }
            requests.post(f"{SUPABASE_URL}/rest/v1/charging_sessions", headers=HEADERS, json=sess_payload)
        print("Charging sessions seeded.")

    # 6. Grid Telemetry
    r_gt = requests.get(f"{SUPABASE_URL}/rest/v1/grid_telemetry?select=id", headers=HEADERS)
    if r_gt.status_code == 200 and len(r_gt.json()) == 0:
        gt_payload = {
            "total_capacity_kw": 5000.0,
            "current_grid_load_kw": 2450.0,
            "charging_load_kw": 680.0,
            "base_load_kw": 1770.0,
            "renewable_energy_kw": 950.0,
            "peak_demand_kw": 3200.0,
            "voltage_v": 400.2,
            "frequency_hz": 50.01,
            "power_factor": 0.98,
            "capacity_utilization_pct": 49.0,
            "is_simulated": "SIMULATED"
        }
        requests.post(f"{SUPABASE_URL}/rest/v1/grid_telemetry", headers=HEADERS, json=gt_payload)
        print("Grid telemetry seeded.")

    # 7. Grid Alerts
    r_ga = requests.get(f"{SUPABASE_URL}/rest/v1/grid_alerts?select=id", headers=HEADERS)
    if r_ga.status_code == 200 and len(r_ga.json()) == 0:
        alerts = [
            {"severity": "WARNING", "alert_type": "HIGH_GRID_LOAD", "title": "Substation Grid Utilization Reached 78%", "message": "High simultaneous fast-charging detected at Bay Area Terminal 1. Automatic load shedding activated.", "status": "ACTIVE"},
            {"severity": "INFO", "alert_type": "RENEWABLE_SURPLUS", "title": "Solar PV Peak Surplus Available", "message": "Presidio Ecozone generating 420 kW excess solar power. Recommended charging window open.", "status": "ACTIVE"},
            {"severity": "WARNING", "alert_type": "CHARGER_OVERLOAD", "title": "Port 03 Thermal Throttling", "message": "Port temperature reached 48°C. Max power throttled to 90 kW for cooling.", "status": "ACTIVE"}
        ]
        for a in alerts:
            requests.post(f"{SUPABASE_URL}/rest/v1/grid_alerts", headers=HEADERS, json=a)
        print("Grid alerts seeded.")

    # 8. Customer Feedback
    r_fb = requests.get(f"{SUPABASE_URL}/rest/v1/customer_feedback?select=id", headers=HEADERS)
    if r_fb.status_code == 200 and len(r_fb.json()) == 0 and st_id_list:
        feedbacks = [
            {"station_id": st_id_list[0], "customer_name": "Marcus Vance (Logistics Mgr)", "rating": 5, "category": "CHARGING_SPEED", "comment": "350 kW charger charged our heavy semi from 20% to 80% in under 38 minutes. Flawless experience!", "status": "PUBLISHED"},
            {"station_id": st_id_list[1 % len(st_id_list)], "customer_name": "David K. (Delivery Courier)", "rating": 4, "category": "AVAILABILITY", "comment": "Clean station and easy bay access. Port 3 cable is a bit stiff in cold weather.", "status": "PUBLISHED"},
            {"station_id": st_id_list[2 % len(st_id_list)], "customer_name": "Rachel Green (Transit Ops)", "rating": 5, "category": "APP_EXPERIENCE", "comment": "Real-time SOC monitoring and digital twin telemetry updates match our onboard dash perfectly.", "status": "PUBLISHED"},
            {"station_id": st_id_list[3 % len(st_id_list)], "customer_name": "Kenji Sato (Route Driver)", "rating": 4, "category": "PAYMENT", "comment": "Automated fleet billing worked smoothly with zero manual card swiping needed.", "status": "PUBLISHED"}
        ]
        for fb in feedbacks:
            requests.post(f"{SUPABASE_URL}/rest/v1/customer_feedback", headers=HEADERS, json=fb)
        print("Customer feedback seeded.")

    # 9. Bookings
    r_bk = requests.get(f"{SUPABASE_URL}/rest/v1/bookings?select=id", headers=HEADERS)
    if r_bk.status_code == 200 and len(r_bk.json()) == 0 and st_id_list and port_ids:
        bookings = [
            {"station_id": st_id_list[0], "port_id": port_ids[0], "booking_code": "BK-810421", "booking_date": "2026-10-09", "start_time": "09:00", "duration_minutes": 60, "status": "CONFIRMED", "estimated_cost": 21.50, "notes": "Priority delivery recharge"},
            {"station_id": st_id_list[1 % len(st_id_list)], "port_id": port_ids[min(5, len(port_ids)-1)], "booking_code": "BK-941830", "booking_date": "2026-10-09", "start_time": "14:30", "duration_minutes": 45, "status": "CONFIRMED", "estimated_cost": 16.80, "notes": "Route change stop"}
        ]
        for b in bookings:
            requests.post(f"{SUPABASE_URL}/rest/v1/bookings", headers=HEADERS, json=b)
        print("Bookings seeded.")

    # 10. System Settings
    r_ss = requests.get(f"{SUPABASE_URL}/rest/v1/system_settings?select=key", headers=HEADERS)
    if r_ss.status_code == 200 and len(r_ss.json()) == 0:
        settings_defaults = [
            {"key": "organization_name", "value": "GridVolt Fleet Enterprise", "category": "GENERAL"},
            {"key": "max_grid_load_threshold_kw", "value": "4500", "category": "GRID"},
            {"key": "auto_optimize_charging", "value": "true", "category": "OPTIMIZATION"},
            {"key": "currency", "value": "USD ($)", "category": "GENERAL"}
        ]
        for s in settings_defaults:
            requests.post(f"{SUPABASE_URL}/rest/v1/system_settings", headers=HEADERS, json=s)
        print("System settings seeded.")

    print("Supabase database seeding completed successfully!")

if __name__ == "__main__":
    seed_supabase()
