import express from 'express';
import { createServer } from 'http';
import { spawn, ChildProcess } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';
import { createProxyMiddleware } from 'http-proxy-middleware';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const httpServer = createServer(app);
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const FASTAPI_PORT = 8000;
const FASTAPI_URL = `http://127.0.0.1:${FASTAPI_PORT}`;

// Launch FastAPI backend process
let fastApiProcess: ChildProcess | null = null;

function startFastApiBackend() {
  console.log(`[Backend] Spawning Python FastAPI server on port ${FASTAPI_PORT}...`);
  fastApiProcess = spawn('uvicorn', ['backend.app.main:app', '--host', '127.0.0.1', '--port', `${FASTAPI_PORT}`, '--log-level', 'info'], {
    cwd: __dirname,
    env: {
      ...process.env,
      PYTHONPATH: '.',
      PATH: `/root/.local/bin:${process.env.PATH}`
    },
    stdio: 'inherit'
  });

  fastApiProcess.on('error', (err) => {
    console.error('[Backend] Failed to start FastAPI process:', err);
  });

  fastApiProcess.on('exit', (code, signal) => {
    console.log(`[Backend] FastAPI process exited with code ${code}, signal ${signal}`);
  });
}

// Start FastAPI
startFastApiBackend();

// Proxy /api to FastAPI
const apiProxy = createProxyMiddleware({
  target: FASTAPI_URL,
  changeOrigin: true,
  on: {
    error: (err: any, _req: any, res: any) => {
      console.error('[Proxy Error /api]:', err?.message);
      if (!res.headersSent && res.writeHead) {
        res.writeHead(502, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'FastAPI backend unavailable', detail: err?.message }));
      }
    }
  }
} as any);
app.use('/api', apiProxy);

// Proxy /ws to FastAPI with WebSocket upgrade support
const wsProxy = createProxyMiddleware({
  target: FASTAPI_URL,
  changeOrigin: true,
  ws: true,
} as any);
app.use('/ws', wsProxy);

async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true'
      },
      appType: 'spa'
    });
    app.use(vite.middlewares);
    console.log('[Frontend] Vite dev middleware attached.');
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  // Handle WebSocket upgrades through HTTP server
  httpServer.on('upgrade', (req, socket, head) => {
    if (req.url?.startsWith('/ws')) {
      (wsProxy as any).upgrade(req, socket, head);
    }
  });

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`[Gateway] EV Fleet Management System ready on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[Gateway] Failed to start server:', err);
  process.exit(1);
});

// Clean up child process on exit
process.on('SIGINT', () => {
  if (fastApiProcess) fastApiProcess.kill();
  process.exit(0);
});
process.on('SIGTERM', () => {
  if (fastApiProcess) fastApiProcess.kill();
  process.exit(0);
});
